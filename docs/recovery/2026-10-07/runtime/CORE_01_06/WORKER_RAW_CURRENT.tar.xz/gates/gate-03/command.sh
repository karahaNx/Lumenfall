rm -rf mobile/www
mkdir -p mobile/www/fonts mobile/www/branding
cp index.html mobile/www/index.html
cp -r fonts/. mobile/www/fonts/
cp -r branding/. mobile/www/branding/
