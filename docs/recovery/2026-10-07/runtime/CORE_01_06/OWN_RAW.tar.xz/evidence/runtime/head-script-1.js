
if(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()){
  var StatusBar = window.Capacitor.Plugins && window.Capacitor.Plugins.StatusBar;
  if(StatusBar){
    StatusBar.setBackgroundColor({color:'#0d0a16'}).catch(function(){});
    StatusBar.setStyle({style:'LIGHT'}).catch(function(){});
  }
}
