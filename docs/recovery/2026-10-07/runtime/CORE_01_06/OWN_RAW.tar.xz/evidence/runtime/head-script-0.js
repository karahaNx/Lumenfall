
(function(){
"use strict";

// ---------------------------------------------------------------
// Data
// ---------------------------------------------------------------
var SPIRITS = [
  {id:'ember',  name:'Ember Wisp',      shortName:'Ember',  shape:'shape-triangle', color:'#e08a2e', unlockDepth:1,  baseCost:10,      basePower:1,     heroClass:'Starcaller',  role:'Burst',         resource:'mana',    abilityType:'dps',     abilityName:'Nova Burst'},
  {id:'tide',   name:'Tide Sprite',     shortName:'Tide',   shape:'shape-droplet',  color:'#3aa0c9', unlockDepth:3,  baseCost:60,      basePower:5,     heroClass:'Dawnpriest',  role:'Amplifier',     resource:'harmony', abilityType:'support', abilityName:'Blessing'},
  {id:'stone',  name:'Stoneheart Golem',shortName:'Stone',  shape:'shape-hex',      color:'#7a8f6a', unlockDepth:6,  baseCost:360,     basePower:26,    heroClass:'Duskguard',   role:'Breaker',       resource:'rage',    abilityType:'breaker', abilityName:'Bulwark Slam'},
  {id:'gale',   name:'Gale Dancer',     shortName:'Gale',   shape:'shape-diamond',  color:'#79c7d1', unlockDepth:9,  baseCost:2100,    basePower:130,   heroClass:'Windrunner',  role:'Shard Utility', resource:'focus',   abilityType:'ranged',  abilityName:'Piercing Volley'},
  {id:'thorn',  name:'Thornback',       shortName:'Thorn',  shape:'shape-pentagon', color:'#4f8f5b', unlockDepth:12, baseCost:12000,   basePower:680,   heroClass:'Thornshaper', role:'Lumen Utility', resource:'energy',  abilityType:'druid',   abilityName:'Bloom Surge'},
  {id:'void',   name:'Voidling',        shortName:'Void',   shape:'shape-star',     color:'#8a5fd6', unlockDepth:18, baseCost:70000,   basePower:3400,  heroClass:'Starcaller',  role:'Burst',         resource:'mana',    abilityType:'dps',     abilityName:'Void Nova'},
  {id:'aurora', name:'Aurora Seer',     shortName:'Aurora', shape:'shape-ring',     color:'#d16fa8', unlockDepth:24, baseCost:400000,  basePower:17000, heroClass:'Dawnpriest',  role:'Amplifier',     resource:'harmony', abilityType:'support', abilityName:'Radiant Blessing'},
  {id:'titan',  name:'Starforged Titan',shortName:'Titan',  shape:'shape-octagon',  color:'#d1a72e', unlockDepth:32, baseCost:2200000, basePower:88000, heroClass:'Duskguard',   role:'Breaker',       resource:'rage',    abilityType:'breaker', abilityName:'Titanic Slam'}
];

var ABILITY_DESC = {
  breaker: 'Heavy ability damage. Stone + Titan together activate the Duskguard boss-damage Bond; its Module boosts the hit and its Ultimate doubles it.',
  dps: 'Focused burst ability damage. Its Module boosts the hit; its Ultimate doubles it.',
  ranged: 'Ability damage + Shards. Module boosts the Shards; Ultimate doubles both.',
  druid: 'Ability damage + Lumen. Module boosts the Lumen; Ultimate doubles both.',
  support: 'Boosts passive Wisp damage and Guardian Tap (your damage per tap) by +25% for 4s. Ultimate: +50% for 8s.'
};

var FORMATION_BONDS = [
  {id:'starcaller', name:'Starcaller Bond', ids:['ember','void'], req:'Ember + Void', effect:'+18% passive & ability damage', tag:'Push'},
  {id:'dawnpriest', name:'Dawnpriest Bond', ids:['tide','aurora'], req:'Tide + Aurora', effect:'+25% Lumen, Shards & Motes', tag:'Farm'},
  {id:'duskguard', name:'Duskguard Bond', ids:['stone','titan'], req:'Stone + Titan', effect:'+35% passive & ability damage vs Bosses', tag:'Boss'},
  {id:'pathfinder', name:'Pathfinder Bond', ids:['gale','thorn'], req:'Gale + Thorn', effect:'+20% passive & ability damage vs non-Bosses', tag:'Push / Farm'}
];
// Presentation identities stay stable across formations; shapes supplement color.
var BOND_VISUALS = {
  starcaller:{color:'#c4adff',mark:'◆'},
  dawnpriest:{color:'#ffd079',mark:'●'},
  duskguard:{color:'#7edbed',mark:'■'},
  pathfinder:{color:'#abe58d',mark:'▲'}
};
var FORMATION_PRESET_IDS = ['push','farm','boss'];
var FORMATION_PRESET_LABELS = {push:'Push',farm:'Farm',boss:'Boss'};

var RESOURCE_COLORS = {mana:'#4f8fe0', rage:'#e0524f', harmony:'#e0b34f', focus:'#4fe0c9', energy:'#7fe04f'};
var MODULE_MAX_LEVEL = 20;
var MODULE_LATE_GROWTH = 1.18;
var MODULE_LATE_GROWTH_START = 5;
var RARITY_LEVEL_REQUIREMENTS = [8,18,30,45,65];
var RARITY_SHARD_COSTS = [15,90,900,15000,500000];
var RARITY_LUMEN_BASE_MULTS = [8,20,80,400,2400];
var MODULE_INFO = {
  dps:     {name:'Overcharge Core',  effect:function(lvl){ return '+'+Math.round(lvl*5)+'% ability burst damage'; }},
  breaker: {name:'Impact Core',      effect:function(lvl){ return '+'+Math.round(lvl*5)+'% ability burst damage'; }},
  ranged:  {name:'Piercing Lens',    effect:function(lvl){ return '+'+Math.round(lvl*5)+'% bonus Shards from its ability'; }},
  druid:   {name:'Bloom Catalyst',   effect:function(lvl){ return '+'+Math.round(lvl*5)+'% bonus Lumen from its ability'; }},
  support: {name:'Resonant Focus',   effect:function(lvl){ return '+'+Math.round(lvl*5)+'% Motes from Luminous kills while Active'; }}
};
var RARITY_NAMES  = ['Common','Uncommon','Rare','Epic','Legendary','Mythic'];
var RARITY_COLORS = ['#9aa0b4','#4fae5e','#3d8fd6','#a860e0','#e0a730','#e0475f'];
var RARITY_MULT   = [1, 1.5, 2.25, 3.5, 5.5, 9];

var LEGACY_RESEARCH_IDS = ['focus','sense','formation','resolve','charge'];
function legacyResearchLevels(s){
  return LEGACY_RESEARCH_IDS.reduce(function(sum,id){return sum+(s.research[id]||0);},0);
}
var RESEARCH = [
  {id:'focus', effectPerLevel:0.08,     name:'Battle Focus',       desc:'+8% Lumen from every kill, per level.',                  lumenBase:200, lumenGrowth:1.5,  shardBase:0,  shardGrowth:1},
  {id:'sense', effectPerLevel:0.08,     name:'Shard Sense',        desc:'+8% Shards from every kill, per level.',                 lumenBase:150, lumenGrowth:1.5,  shardBase:20, shardGrowth:1.5},
  {id:'formation', effectPerLevel:0.05, name:'Formation Training', desc:'+5% passive Wisp damage per level; also raises the Wisp-powered part of your tap damage.', lumenBase:0, lumenGrowth:1, shardBase:40, shardGrowth:1.6},
  {id:'resolve', effectPerLevel:0.1,   name:"Guardian's Resolve", desc:'+10% tap damage, per level.',                   lumenBase:150, lumenGrowth:1.45, shardBase:0,  shardGrowth:1},
  {id:'charge', effectPerLevel:0.08,    name:'Swift Recovery',     desc:'+8% faster Wisp ability charge, per level.',              lumenBase:0,   lumenGrowth:1,    shardBase:30, shardGrowth:1.55},
  {id:'arcanecal', name:'Arcane Calibration', desc:'+3 percentage points to the damaging Wisp ability factor per level. Burst, Breaker, Gale and Thorn only; no passive or Tap bonus.', unlockDepth:12, levelCap:10, effectPerLevel:0.03, lumenBase:15000, lumenGrowth:1.60, shardBase:120, shardGrowth:1.60},
  {id:'conduction', name:'Resource Conduction', desc:'+4 percentage points to the ability resource factor per level. Gale Shards and Thorn Lumen only; rounded per cast, not kill rewards.', unlockDepth:18, levelCap:10, effectPerLevel:0.04, lumenBase:90000, lumenGrowth:1.60, shardBase:280, shardGrowth:1.60},
  {id:'luminoustracking', name:'Luminous Tracking', desc:'+0.5 percentage points Luminous chance per level for future eligible encounters; total chance at most 35%. No extra Motes per kill.', unlockDepth:32, levelCap:10, effectPerLevel:0.005, lumenBase:2500000, lumenGrowth:1.60, shardBase:1500, shardGrowth:1.60}
];

var NODES = [
  {id:'starlight', name:'Starlight Affinity', desc:'+10% Lumen from every kill, per level.', baseCost:1, growth:1.35},
  {id:'steady',    name:'Steady Hands',        desc:'+8% tap damage, per level.',              baseCost:1, growth:1.30},
  {id:'echo',      name:'Echoing Rest',        desc:'+5% offline earning rate, per level (caps at 100%).', baseCost:2, growth:1.40},
  {id:'bonds',     name:'Cheaper Bonds',       desc:'−3% Wisp recruiting cost, per level (floor 40%).',  baseCost:2, growth:1.45},
  {id:'swift',     name:'Swift Ascension',     desc:'+4% Prisms earned per Ascend, per level.', baseCost:3, growth:1.50},
  {id:'momentum',  name:'Eternal Momentum',    desc:'+6% passive Wisp damage per level; also raises the Wisp-powered part of your tap damage.', baseCost:5, growth:1.55, requiresAchievement:'asc5'},
  {id:'reserves',  name:'Deep Reserves',       desc:'+2 hours to your offline cap, per level.', baseCost:6, growth:1.60, requiresAchievement:'d100'}
];

// Existing slot, Deed and v0 automation contracts are independent of additions.
var LEGACY_STUDY_IDS = Object.freeze(['wispascend','guardmastery','riftattune','shardstudy','lumenstudy','formationstudy','motestudy','prismstudy']);
var LONG_STUDIES = [
  {id:'wispascend',   name:'Wisp Ascendancy',     desc:'+15% passive Wisp damage permanently; also raises the Wisp-powered part of your tap damage.', unlockDepth:1, baseDurationSec:180, durationGrowth:1.6, lumenBase:800, lumenGrowth:1.8, shardBase:80, shardGrowth:1.8},
  {id:'guardmastery', name:"Guardian's Mastery",  desc:'+20% tap damage, permanently.',                           unlockDepth:1,  baseDurationSec:150, durationGrowth:1.6, lumenBase:600,  lumenGrowth:1.8, shardBase:40,  shardGrowth:1.8},
  {id:'riftattune',   name:'Rift Attunement',     desc:'+10% offline earning rate, permanently (stacks past 100%).',      unlockDepth:1,  baseDurationSec:240, durationGrowth:1.6, lumenBase:500,  lumenGrowth:1.8, shardBase:100, shardGrowth:1.8},
  {id:'shardstudy',   name:'Shard Attunement',    desc:'+8% Shards earned per kill, permanently.',                        unlockDepth:15, baseDurationSec:200, durationGrowth:1.6, lumenBase:400,  lumenGrowth:1.8, shardBase:150, shardGrowth:1.8},
  {id:'lumenstudy',   name:'Lumen Wellspring',    desc:'+8% Lumen earned per kill, permanently.',                         unlockDepth:25, baseDurationSec:260, durationGrowth:1.6, lumenBase:1400, lumenGrowth:1.8, shardBase:120, shardGrowth:1.8},
  {id:'formationstudy',name:'Formation Insight',  desc:'+5% passive Wisp damage permanently; also raises the Wisp-powered part of your tap damage.', unlockDepth:40, baseDurationSec:320, durationGrowth:1.6, lumenBase:2200, lumenGrowth:1.8, shardBase:220, shardGrowth:1.8},
  {id:'motestudy',     name:'Luminous Sense',     desc:'+10% Motes gained from Luminous enemies, permanently.',           unlockDepth:60, baseDurationSec:380, durationGrowth:1.6, lumenBase:3200, lumenGrowth:1.8, shardBase:320, shardGrowth:1.8},
  {id:'prismstudy',    name:'Ascendant Clarity',  desc:'+5% Prisms earned per Ascend, permanently.',                      unlockDepth:90, baseDurationSec:450, durationGrowth:1.6, lumenBase:4800, lumenGrowth:1.8, shardBase:480, shardGrowth:1.8},
  {id:'measuredinquiry', name:'Measured Inquiry', desc:'2% less work per completed level, up to 20%, for future starts of Wisp Ascendancy, Guardian’s Mastery, Rift Attunement, Shard Attunement, Lumen Wellspring, Formation Insight, Luminous Sense and Ascendant Clarity. Running Studies and Measured Inquiry itself are unchanged.', unlockDepth:60, levelCap:10, baseDurationSec:600, durationGrowth:1.6, lumenBase:30000, lumenGrowth:1.8, shardBase:1200, shardGrowth:1.8}
];

var LAB_SPEED_TIERS = [1.5, 2, 3, 4, 5, 6, 7, 8];
function speedTierCost(mult){
  return Math.round(6 * Math.pow(mult, 2.1));
}

var ACHIEVEMENTS = [
  {id:'d10',   name:'Reach Rift 10',        reward:5,  check:function(s){return s.maxDepthEver>=10;}},
  {id:'d25',   name:'Reach Rift 25',        reward:10, check:function(s){return s.maxDepthEver>=25;}},
  {id:'d50',   name:'Reach Rift 50',        reward:20, check:function(s){return s.maxDepthEver>=50;}},
  {id:'d100',  name:'Reach Rift 100',       reward:50, unlocks:'Ascension Tree: Deep Reserves', check:function(s){return s.maxDepthEver>=100;}},
  {id:'d250',  name:'Reach Rift 250',       reward:100, check:function(s){return s.maxDepthEver>=250;}},
  {id:'tap100',  name:'Strike 100 times',    reward:3,  check:function(s){return s.totalTaps>=100;}},
  {id:'tap1000', name:'Strike 1,000 times',  reward:8,  check:function(s){return s.totalTaps>=1000;}},
  {id:'tap10000',name:'Strike 10,000 times', reward:20, check:function(s){return s.totalTaps>=10000;}},
  {id:'fullparty', name:'Full Formation',    reward:12, check:function(s){return s.activeParty.length>=5;}},
  {id:'asc1',  name:'Ascend once',          reward:10, check:function(s){return s.ascendCount>=1;}},
  {id:'asc5',  name:'Ascend 5 times',       reward:25, unlocks:'Ascension Tree: Eternal Momentum', check:function(s){return s.ascendCount>=5;}},
  {id:'asc10', name:'Ascend 10 times',      reward:50, check:function(s){return s.ascendCount>=10;}},
  {id:'all',   name:'Recruit every Wisp',   reward:30, check:function(s){return SPIRITS.every(function(sp){return (s.spirits[sp.id]||0)>0;});}},
  {id:'mythic',name:'Raise a Wisp to Mythic', reward:40, check:function(s){return SPIRITS.some(function(sp){return (s.heroRarity[sp.id]||0)>=5;});}},
  {id:'idle8', name:'Rest 8 hours offline', reward:15, check:function(s){return s.totalOfflineSeconds>=8*3600;}},
  {id:'autotap',   name:'Tireless Vigil',      reward:25, unlocks:'Auto-Tap — your Guardian strikes on its own, once a second', check:function(s){return s.ascendCount>=12;}},
  {id:'labmaster', name:'The Forge Never Sleeps', reward:30, unlocks:'Auto-Empower — spare Lumen levels up your party for you, live or while you\'re offline', check:function(s){return legacyResearchLevels(s)>=20;}},
  {id:'study1',    name:'First Discovery',     reward:15, check:function(s){return totalStudyLevels(s)>=1;}},
  {id:'study25',   name:'Devoted Scholar',     reward:50, check:function(s){return totalStudyLevels(s)>=25;}},
  {id:'allstudies',name:'Every Path Studied',  reward:35, check:function(s){return LEGACY_STUDY_IDS.every(function(id){return (s.longStudyLevels[id]||0)>=1;});}},
  {id:'labqueue',  name:'Endless Curiosity',   reward:40, check:function(s){return legacyResearchLevels(s)>=60;}},
  {id:'firstultimate', name:'Awakened Power',  reward:45, check:function(s){return SPIRITS.some(function(sp){return !!(s.wispUltimate && s.wispUltimate[sp.id]);});}},
  {id:'modulemax', name:'Perfect Synergy',     reward:45, unlocks:'Cosmetics: Radiant Rift aura', check:function(s){return SPIRITS.some(function(sp){return (s.wispModules[sp.id]||0)>=MODULE_MAX_LEVEL;});}}
];

// Every current Deed has an authoritative counter. Completed one-time Deeds
// display their reached target even if a later Ascend resets the underlying run.
function deedProgress(a,s){
  var researchLevels = function(){ return legacyResearchLevels(s); };
  var config = {
    d10:[s.maxDepthEver,10],d25:[s.maxDepthEver,25],d50:[s.maxDepthEver,50],d100:[s.maxDepthEver,100],d250:[s.maxDepthEver,250],
    tap100:[s.totalTaps,100],tap1000:[s.totalTaps,1000],tap10000:[s.totalTaps,10000],
    fullparty:[s.activeParty.length,5],
    asc1:[s.ascendCount,1],asc5:[s.ascendCount,5],asc10:[s.ascendCount,10],
    all:[SPIRITS.filter(function(sp){return (s.spirits[sp.id]||0)>0;}).length,SPIRITS.length],
    mythic:[Math.max.apply(null,SPIRITS.map(function(sp){return s.heroRarity[sp.id]||0;})),5],
    idle8:[s.totalOfflineSeconds,8*3600],
    autotap:[s.ascendCount,12],
    labmaster:[researchLevels(),20],
    study1:[totalStudyLevels(s),1],study25:[totalStudyLevels(s),25],
    allstudies:[LEGACY_STUDY_IDS.filter(function(id){return (s.longStudyLevels[id]||0)>=1;}).length,LEGACY_STUDY_IDS.length],
    labqueue:[researchLevels(),60],
    firstultimate:[SPIRITS.some(function(sp){return !!(s.wispUltimate&&s.wispUltimate[sp.id]);})?1:0,1],
    modulemax:[Math.max.apply(null,SPIRITS.map(function(sp){return (s.wispModules&&s.wispModules[sp.id])||0;})),MODULE_MAX_LEVEL]
  };
  var pair = config[a.id];
  if(!pair) return null;
  return {current:Math.max(0,Number(pair[0])||0),target:pair[1],duration:a.id==='idle8'};
}
function deedProgressText(a,done){
  var progress = deedProgress(a,state);
  if(!progress) return '';
  var current = done ? progress.target : Math.min(progress.current,progress.target);
  if(progress.duration) return String(Math.floor(current/3600*100)/100)+' / 8 offline hours';
  return current.toLocaleString('en-US')+' / '+progress.target.toLocaleString('en-US')+' '+deedPresentation(a).unit;
}

// Presentation metadata never participates in eligibility or one-time rewards.
function deedPresentation(a){
  var scope='Counts Battle Focus, Shard Sense, Formation Training, Guardian’s Resolve and Swift Recovery only. Other Forge upgrades do not count.';
  var studyScope='Counts Wisp Ascendancy, Guardian’s Mastery, Rift Attunement, Shard Attunement, Lumen Wellspring, Formation Insight, Luminous Sense and Ascendant Clarity only. Measured Inquiry does not count.';
  var rows={
    d10:['Reach Rift 10.','Rifts reached'],d25:['Reach Rift 25.','Rifts reached'],
    d50:['Reach Rift 50.','Rifts reached'],d100:['Reach Rift 100.','Rifts reached'],d250:['Reach Rift 250.','Rifts reached'],
    tap100:['Strike 100 times.','strikes'],tap1000:['Strike 1,000 times.','strikes'],tap10000:['Strike 10,000 times.','strikes'],
    fullparty:['Place 5 Wisps in your Formation.','Formation slots'],
    asc1:['Ascend once.','Ascensions'],asc5:['Ascend 5 times.','Ascensions'],asc10:['Ascend 10 times.','Ascensions'],
    all:['Recruit every Wisp in one run.','recruited Wisps'],
    mythic:['Raise one Wisp to Mythic.','rarity upgrades on one Wisp'],
    idle8:['Accumulate 8 hours offline.','offline hours'],
    autotap:['Ascend 12 times.','Ascensions'],
    labmaster:['Gain 20 total levels in the 5 original Forge upgrades.','original Forge levels',scope],
    study1:['Complete one level in the 8 listed Research Projects.','completed Project levels',studyScope],
    study25:['Complete 25 levels in total in the 8 listed Research Projects.','completed Project levels',studyScope],
    allstudies:['Complete at least one level in each of the 8 listed Research Projects.','Projects completed',studyScope],
    labqueue:['Gain 60 total levels in the 5 original Forge upgrades.','original Forge levels',scope],
    firstultimate:['Unlock one Wisp Ultimate.','Ultimate unlocked'],
    modulemax:['Raise one Wisp Module to level 20.','levels on one Module','Uses your highest single Module level. Levels on different Wisps are not added together.']
  };
  var row=rows[a.id];
  return {requirement:row[0],unit:row[1],scope:row[2]||''};
}

function earnedPercent(value){ return formatNum(Math.round(value*1000000)/10000); }
// Isolated node contributions mirror the existing production operands. They
// deliberately exclude other systems, which combine multiplicatively/additively.
function nodeEarnedEffect(id){
  var level=nodeLevel(id);
  if(id==='starlight') return '+'+earnedPercent(level*0.10)+'% Lumen per kill';
  if(id==='steady') return '+'+earnedPercent(level*0.08)+'% tap damage';
  if(id==='swift') return '+'+earnedPercent(level*0.04)+'% Prisms per Ascend';
  if(id==='momentum') return '+'+earnedPercent(momentumMult()-1)+'% passive Wisp damage and Wisp-powered tap base';
  if(id==='reserves') return '+'+formatNum(level*2)+' hours to the offline cap';
  if(id==='echo'){
    var rate=Math.min(1,0.70+level*0.05);
    return '+'+earnedPercent(rate-0.70)+' percentage points offline rate · '+earnedPercent(rate)+'% before Projects'+(rate>=1?' (node cap reached)':'');
  }
  var discount=costReduction();
  return earnedPercent(discount)+'% Wisp recruiting discount · '+earnedPercent(1-discount)+'% cost'+(discount>=0.6?' (cost floor reached)':'');
}
function projectEarnedEffect(id){
  if(id==='measuredinquiry') return earnedPercent(measuredInquiryReduction())+'% less work for future starts of the 8 listed Studies';
  var rows={
    wispascend:[longStudyPowerMult()-1,'passive Wisp damage and Wisp-powered tap base'],
    guardmastery:[longStudyTapMult()-1,'tap damage'],
    riftattune:[longStudyOfflineBonus(),'percentage points offline rate'],
    shardstudy:[longStudyShardMult()-1,'Shards per kill'],
    lumenstudy:[longStudyLumenMult()-1,'Lumen per kill'],
    formationstudy:[longStudyFormationMult()-1,'passive Wisp damage and Wisp-powered tap base'],
    motestudy:[longStudyMoteMult()-1,'Motes from Luminous enemies'],
    prismstudy:[longStudyPrismMult()-1,'Prisms per Ascend']
  };
  var row=rows[id];
  return '+'+earnedPercent(row[0])+(id==='riftattune'?' ':'% ')+row[1];
}
function projectEarnedMarkup(id){
  var level=longStudyLevel(id);
  var node=LONG_STUDIES.find(function(n){return n.id===id;});
  var preserved=node.levelCap!==undefined && level>node.levelCap ? ' · Preserved; effect capped at level '+node.levelCap : '';
  return '<div class="earned-effect" data-project-effect="'+id+'"><strong>Completed level '+level+preserved+'</strong><br>Current Project bonus: '+projectEarnedEffect(id)+(level===0?' · No earned bonus':'')+'</div>';
}

var RIFT_THEMES = [
  {id:'default', name:'Starlight',    desc:'The Rift as it always looked.', unlockAchievement:null,     accent:null},
  {id:'ember',   name:'Ember Veil',   desc:'A warm ember aura around the Rift.', unlockAchievement:'d50',    accent:'#e08a2e'},
  {id:'void',    name:'Void Bloom',   desc:'A deep violet aura around the Rift.', unlockAchievement:'asc5',   accent:'#8a5fd6'},
  {id:'aurora',  name:'Aurora Pulse', desc:'A rose-teal aura around the Rift.', unlockAchievement:'mythic', accent:'#d16fa8'},
  {id:'solar',   name:'Solar Crown',  desc:'A golden aura around the Rift.', unlockAchievement:'d250',   accent:'#d1a72e'},
  {id:'radiant', name:'Radiant',      desc:'A prismatic aura cycling through every currency color.', unlockAchievement:'modulemax', accent:null}
];

var SHOP = [
  {id:'autoascend', name:'Auto-Ascend Ritual', desc:'Choose which Rift to defeat before automatic Ascension. Toggle it on or off anytime. Your chosen target persists across Ascensions.', cost:100},
  {id:'offline24',  name:'Extended Rest',      desc:'Raise the offline earnings cap from 12 hours to 24 hours.', cost:140},
  {id:'offline48',  name:'Deep Rest',          desc:'Raise the offline earnings cap by another 24 hours, stacking with Extended Rest.', cost:160},
  {id:'rememberbulk',name:'Loadout Memory',    desc:'The Rift Forge remembers your last bulk-buy multiplier between visits, instead of resetting to 1x.', cost:50}
];

var MANIFESTO = [
  {eyebrow:'Our promise', title:'No pay-to-win, ever', body:'Lumenfall has nothing to buy with real money — every currency, from Lumen to Sigils, is earned by playing. Every upgrade you see is something you can reach yourself.'},
  {eyebrow:'The "zone 80 wall"', title:'Progress never fully stalls', body:'Many idle RPGs stretch their upgrade paths thin enough that progress plateaus for days at a time. Every Ascend here guarantees Prisms the moment you qualify, and Rarity plus Rift Forge upgrades never get wiped — so a reset is always a net gain.'},
  {eyebrow:'"Present every few minutes"', title:'Actually idle', body:'Some idle games expect hours of daily babysitting or you hit a hard stop. Your Wisps keep fighting while you’re away, with generous, transparent offline earnings shown the moment you return.'},
  {eyebrow:'"24 heroes at once"', title:'A roster that unfolds', body:'Wisps unlock gradually as you go deeper, instead of dumping a full cast on a brand-new player.'},
  {eyebrow:'Gear rarity RNG', title:'No loot boxes, no gacha', body:'Every upgrade — leveling, Rarity, Rift Forge upgrades — is a visible, deterministic purchase, and even a Luminous enemy always drops the same fixed amount of Motes. What you see is what you get, never a random range.'},
  {eyebrow:'What actually makes an idle RPG feel like one', title:'A real party, with real roles', body:'Up to five Wisps — each with a class, a resource bar, and an active ability — fight beside your Guardian. Their Rarity tier and Forge investment matter, not just one flat number going up.'},
  {eyebrow:'Real taps only', title:'Autoclickers earn nothing extra', body:'Manual tapping is capped to what a genuinely fast human can do, and only real touch or click input counts toward damage — a script mashing the Rift in the background gets no more than your Wisps were already earning on their own.'}
];

var QUEST_POOL = [
  {id:'q_tap_small',  metric:'taps',          name:'Strike the Rift',     desc:'Land taps on the Rift',   goal:200, reward:{comets:8}},
  {id:'q_tap_big',    metric:'taps',          name:'Relentless Guardian', desc:'Land taps on the Rift',   goal:600, reward:{comets:15}},
  {id:'q_kill_small', metric:'kills',         name:'Clear the Rift',      desc:'Defeat enemies',          goal:40,  reward:{comets:10}},
  {id:'q_kill_big',   metric:'kills',         name:'Deep Delve',          desc:'Defeat enemies',          goal:120, reward:{comets:18}},
  {id:'q_empower',    metric:'empowers',      name:'Grow Stronger',       desc:'Empower your Wisps',      goal:15,  reward:{comets:10}},
  {id:'q_research',   metric:'research',      name:'Fund the Forge',      desc:'Buy Rift Forge upgrade levels', goal:5,   reward:{comets:10}},
  {id:'q_boss',       metric:'bossKills',     name:'Boss Slayer',         desc:'Defeat a Rift boss',      goal:1,   reward:{comets:20}},
  {id:'q_luminous',   metric:'luminousKills', name:'Chase the Light',     desc:'Defeat a Luminous enemy', goal:1,   reward:{comets:15}},
  {id:'q_ascend',     metric:'ascends',       name:'Begin Again',         desc:'Ascend the Rift',         goal:1,   reward:{comets:25}}
];

var DAILY_LOGIN_REWARDS = [
  {comets:5},
  {comets:8},
  {comets:12},
  {comets:16},
  {comets:20},
  {comets:25},
  {comets:40, prisms:3}
];

var ENEMY_ADJ = ['Hollow','Dusk','Rift-Touched','Withering','Umbral','Ashen','Fractured','Silent','Creeping','Starved'];
var ENEMY_NOUN = ['Wisp','Serpent','Stalker','Husk','Warden','Shade','Leech','Prowler','Effigy','Wraith','Arachnid','Scorpion','Mantis','Wyvern','Gargoyle','Behemoth','Revenant','Hydra','Watcher','Carapace','Basilisk','Crawler','Harrier'];

var RIFT_ZONE_SPAN = 25;
var RIFT_ZONES = [
  {name:'Starlit Verge', accent:'#d6b657'},
  {name:'Ashen Canopy', accent:'#c96f55'},
  {name:'Glass Wastes', accent:'#72b9cf'},
  {name:'Drowned Observatory', accent:'#557fd1'},
  {name:'Void Basilica', accent:'#8d65d4'},
  {name:'Crown of Night', accent:'#c0639c'}
];

var SAVE_KEY = 'lumenfall_save_v2';
var RECOVERY_SAVE_KEY = 'lumenfall_save_recovery_v1';
var RIFT_GUIDANCE_HIDDEN_KEY = 'lumenfall_rift_guidance_hidden_v1';
var riftGuidanceHidden = false;
var SAVE_SCHEMA_VERSION = 1;
var RESET_PENDING_KEY = 'lumenfall_reset_pending_v1';
var TICK_MS = 100;
var ABILITY_BASE_CYCLE_SEC = 6;
var ASCEND_REPEAT_REWARD_RATE = 0.20;
var OFFLINE_BOSS_RETREAT_GRACE_SEC = 5 * 60;
var SIGIL_RESONANCE_COST = 25;
var SIGIL_RESONANCE_RUN_LIMIT = 3;
var COMET_QUEST_REFRESH_BASE_COST = 25;

// ---------------------------------------------------------------
// State
// ---------------------------------------------------------------
function freshState(){
  var spirits = {}, nodes = {}, research = {}, researchQueue = {}, heroRarity = {}, heroResource = {}, wispModules = {}, wispUltimate = {}, empowerQueue = {}, achieved = {}, owned = {}, longStudyLevels = {}, studyQueue = {}, studyUseMotes = {}, studySpeedTargets = {};
  SPIRITS.forEach(function(sp){ spirits[sp.id] = 0; heroRarity[sp.id] = 0; heroResource[sp.id] = 0; wispModules[sp.id] = 0; wispUltimate[sp.id] = false; empowerQueue[sp.id] = true; });
  spirits['ember'] = 1;
  NODES.forEach(function(n){ nodes[n.id] = 0; });
  RESEARCH.forEach(function(r){ research[r.id] = 0; researchQueue[r.id] = false; });
  LONG_STUDIES.forEach(function(l){ longStudyLevels[l.id] = 0; studyQueue[l.id] = false; studyUseMotes[l.id] = false; studySpeedTargets[l.id] = 1.5; });
  return {
    schemaVersion:SAVE_SCHEMA_VERSION,
    lumen:0, shards:0, prisms:0, comets:0, motes:0, sigils:0,
    depth:1, maxDepthEver:1,
    riftMode:'push', farmDepth:0, farmReturnDepth:0,
    enemyDepth:0, enemyHp:0, enemyMaxHp:0, enemyIsLuminous:false,
    spirits:spirits, heroRarity:heroRarity, heroResource:heroResource, wispModules:wispModules, wispUltimate:wispUltimate, empowerQueue:empowerQueue, activeParty:['ember'],
    formationPresets:{push:['ember'],farm:['ember'],boss:['ember']}, activeFormationPreset:'push',
    formationRebuild:null,
    nodes:nodes, research:research, researchQueue:researchQueue,
    longStudyLevels:longStudyLevels, activeStudies:[], studyQueue:studyQueue, studyUseMotes:studyUseMotes, studySpeedTargets:studySpeedTargets,
    achieved:achieved, owned:owned, riftTheme:'default',
    buffUntil:0, buffMult:1, supportBuffs:null,
    ascendCount:0, ascendRewardedDepth:0, sigilResonanceUses:0, totalTaps:0, totalKills:0, totalOfflineSeconds:0, luminousAccum:0,
    savedLabMultiplier:1,
    autoAscendEnabled:false, autoAscendTargetDepth:16,
    loginStreak:0, questDay:'', questIds:[], questClaimed:{}, dailyQuestRefreshes:0, dailyStats:{},
    lastSeen:Date.now()
  };
}
function totalStudyLevels(s){
  return LEGACY_STUDY_IDS.reduce(function(sum,id){ return sum + (s.longStudyLevels[id]||0); }, 0);
}
function todayStr(){
  var d = new Date();
  return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
}
function daysBetweenStr(a,b){
  return Math.round((new Date(b+'T00:00:00') - new Date(a+'T00:00:00'))/86400000);
}
function dateSeed(str){
  var h = 0;
  for(var i=0;i<str.length;i++){ h = (h*31 + str.charCodeAt(i))|0; }
  return Math.abs(h);
}
function dailyQuestEligible(q,s){
  var depth = (s && s.maxDepthEver)||1;
  if(q.metric==='research') return depth>=5;
  if(q.metric==='bossKills') return depth>=8;
  if(q.metric==='luminousKills') return depth>=10;
  if(q.metric==='ascends') return depth>=16 || ((s && s.ascendCount)||0)>0;
  return true;
}
function pickDailyQuests(dayStr,s){
  var seed = dateSeed(dayStr);
  var pool = QUEST_POOL.filter(function(q){ return dailyQuestEligible(q,s); });
  var picked = [];
  for(var i=0;i<3 && pool.length;i++){
    var idx = (seed + i*17) % pool.length;
    picked.push(pool[idx].id);
    pool.splice(idx,1);
  }
  return picked;
}
function loginRewardFor(streak){
  return DAILY_LOGIN_REWARDS[(streak-1) % DAILY_LOGIN_REWARDS.length];
}
function restStopComplete(){
  return SHOP.every(function(item){ return !!state.owned[item.id]; });
}
function maxDailyQuestCometReward(){
  return QUEST_POOL.reduce(function(max,q){ return Math.max(max,(q.reward && q.reward.comets)||0); },0);
}
function dailyQuestRefreshCost(){
  // A refresh may inherit already-earned daily progress. Keeping its cost at
  // least the richest quest reward prevents Comet-positive reroll arbitrage.
  return Math.max(COMET_QUEST_REFRESH_BASE_COST,maxDailyQuestCometReward());
}
function dailyQuestRefreshCandidates(replacedId){
  var current = state.questIds||[];
  return QUEST_POOL.filter(function(q){
    return q.id!==replacedId &&
      current.indexOf(q.id)===-1 &&
      !(state.questClaimed && state.questClaimed[q.id]) &&
      dailyQuestEligible(q,state);
  });
}
function refreshDailyQuest(id){
  if(!restStopComplete() || !id || state.questClaimed[id]) return false;
  var index=(state.questIds||[]).indexOf(id);
  if(index<0) return false;
  var cost=dailyQuestRefreshCost();
  if(state.comets<cost) return false;
  var candidates=dailyQuestRefreshCandidates(id);
  if(!candidates.length) return false;

  // No RNG or hidden server state: current date + persisted refresh count +
  // selected slot choose the same replacement from the same save.
  var seed=dateSeed(state.questDay||todayStr()) + (state.dailyQuestRefreshes||0)*31 + index*17;
  var replacement=candidates[Math.abs(seed)%candidates.length];
  state.comets-=cost;
  state.dailyQuestRefreshes=(state.dailyQuestRefreshes||0)+1;
  state.questIds[index]=replacement.id;
  saveState();
  renderDaily(true);
  renderHud();
  showToast('Daily Quest refreshed — '+replacement.name+'.');
  return true;
}
function trackDaily(metric, n){
  if(!state.dailyStats) state.dailyStats = {};
  state.dailyStats[metric] = (state.dailyStats[metric]||0) + (n||1);
}
var pendingDailyReward = null;
function ensureDaily(){
  var today = todayStr();
  if(state.questDay === today) return false;
  var hadPriorDay = !!state.questDay;
  state.loginStreak = hadPriorDay ? (daysBetweenStr(state.questDay, today)===1 ? state.loginStreak+1 : 1) : 1;
  state.questDay = today;
  state.questIds = pickDailyQuests(today,state);
  state.questClaimed = {};
  state.dailyQuestRefreshes = 0;
  state.dailyStats = {};
  var reward = loginRewardFor(state.loginStreak);
  state.comets += reward.comets||0;
  if(reward.prisms) state.prisms += reward.prisms;
  pendingDailyReward = {streak: state.loginStreak, reward: reward};
  return true;
}

var state = null;
var isNewGame = false;
var resetInProgress = false;
var resetBootPending = false;
var reloadInProgress = false;

function persistenceError(code,message){
  var error = new Error(message);
  error.code = code;
  return error;
}
function isPlainObject(value){
  return !!value && typeof value==='object' && !Array.isArray(value);
}
function clonePersistedValue(value){
  return JSON.parse(JSON.stringify(value));
}
function finiteNonNegative(value,fallback){
  var n = Number(value);
  return Number.isFinite(n) && n>=0 ? n : fallback;
}
function nonNegativeInt(value,fallback){
  return Math.max(0,Math.floor(finiteNonNegative(value,fallback)));
}
function boundedInt(value,fallback,min,max){
  var n = Math.floor(Number(value));
  if(!Number.isFinite(n)) return fallback;
  return Math.max(min,Math.min(max,n));
}
function strictBool(value,fallback){
  return typeof value==='boolean' ? value : fallback;
}
function assertPersistedRootShape(value){
  if(!isPlainObject(value) || value.depth===undefined || !isPlainObject(value.spirits)){
    throw persistenceError('invalid-root','Save data is missing required progression fields');
  }
}
function identifySaveSchemaVersion(value){
  assertPersistedRootShape(value);
  if(value.schemaVersion===undefined) return 0;
  if(!Number.isInteger(value.schemaVersion) || value.schemaVersion<0){
    throw persistenceError('invalid-schema','Save schema version is invalid');
  }
  if(value.schemaVersion>SAVE_SCHEMA_VERSION){
    throw persistenceError('unsupported-future-schema','Save was created by a newer Lumenfall schema');
  }
  return value.schemaVersion;
}
function migrateSaveV0ToV1(input){
  var migrated = clonePersistedValue(input);
  var researchQueueWasMissing = migrated.researchQueue===undefined;
  var studyQueueWasMissing = migrated.studyQueue===undefined;
  var autoAscendEnabledWasMissing = migrated.autoAscendEnabled===undefined;
  var autoAscendTargetWasMissing = migrated.autoAscendTargetDepth===undefined;
  var legacyOwned = isPlainObject(migrated.owned) ? migrated.owned : {};

  if(researchQueueWasMissing){
    migrated.researchQueue = {};
    LEGACY_RESEARCH_IDS.forEach(function(id){ migrated.researchQueue[id] = !!migrated.labQueueOn; });
  }
  delete migrated.labQueueOn;

  if(studyQueueWasMissing){
    migrated.studyQueue = {};
    LEGACY_STUDY_IDS.forEach(function(id){ migrated.studyQueue[id] = !!legacyOwned.autostudy; });
  }

  if(!Array.isArray(migrated.activeStudies)) migrated.activeStudies = [];
  if(isPlainObject(migrated.activeStudy)) migrated.activeStudies.push(migrated.activeStudy);
  delete migrated.activeStudy;

  if(autoAscendEnabledWasMissing) migrated.autoAscendEnabled = !!legacyOwned.autoascend;
  if(autoAscendTargetWasMissing) migrated.autoAscendTargetDepth = Math.max(16,Number(migrated.maxDepthEver)||1);

  if(isPlainObject(migrated.owned)) delete migrated.owned.autostudy;
  migrated.schemaVersion = 1;
  return migrated;
}
var SAVE_MIGRATIONS = {
  0: migrateSaveV0ToV1
};
function migratePersistedState(input){
  var migrated = clonePersistedValue(input);
  var version = identifySaveSchemaVersion(migrated);
  while(version<SAVE_SCHEMA_VERSION){
    var migrate = SAVE_MIGRATIONS[version];
    if(typeof migrate!=='function'){
      throw persistenceError('unsupported-old-schema','No migration exists for save schema '+version);
    }
    migrated = migrate(migrated);
    var nextVersion = identifySaveSchemaVersion(migrated);
    if(nextVersion!==version+1){
      throw persistenceError('invalid-migration','Save migration did not advance exactly one schema version');
    }
    version = nextVersion;
  }
  return migrated;
}
// Schema-v1 additive, cast-time records. Do not prune by wall time here:
// an expired-now record may still contribute during lastSeen offline catch-up.
function normalizeSupportBuffs(raw){
  if(!isPlainObject(raw) || raw.version!==1 || !isPlainObject(raw.sources)) return null;
  var sources = {};
  ['tide','aurora'].forEach(function(id){
    var entry = raw.sources[id];
    if(!isPlainObject(entry)) return;
    if(!Number.isFinite(entry.until) || entry.until<=0) return;
    if(entry.mult!==1.25 && entry.mult!==1.5) return;
    sources[id] = {until:entry.until,mult:entry.mult};
  });
  return {version:1,sources:sources};
}
// Optional schema-v1 intent: never stores levels, resources or combat benefits.
function normalizeFormationRebuild(raw,snapshot){
  if(!isPlainObject(raw) || !Array.isArray(raw.members)) return null;
  var members = raw.members.filter(function(id,index){
    if(typeof id!=='string' || raw.members.indexOf(id)!==index) return false;
    return SPIRITS.some(function(sp){return sp.id===id && snapshot.maxDepthEver>=sp.unlockDepth;});
  }).slice(0,5);
  if(!members.length) return null;
  var preset = FORMATION_PRESET_IDS.indexOf(raw.preset)!==-1 &&
    snapshot.formationPresets[raw.preset].join(',')===members.join(',') ? raw.preset : '';
  return {members:members,preset:preset};
}
function reconcileFormationRebuild(snapshot){
  var intent = snapshot.formationRebuild;
  if(!intent) return;
  var powered = intent.members.filter(function(id){return (snapshot.spirits[id]||0)>0;});
  // Ember is startup support only. Remove it once an intended member can fight.
  // This projection never recruits or raises a level, including on save loading.
  if(powered.length) snapshot.activeParty = powered;
  else if((snapshot.spirits.ember||0)>0) snapshot.activeParty = ['ember'];
  else snapshot.activeParty = [];
  snapshot.activeFormationPreset = '';
  if(powered.length===intent.members.length){
    if(intent.preset && snapshot.formationPresets[intent.preset].join(',')===intent.members.join(',')){
      snapshot.activeFormationPreset = intent.preset;
    }
    snapshot.formationRebuild = null;
  }
}
function intendedFormationIds(){
  return state.formationRebuild ? state.formationRebuild.members : [];
}
function autoEmpowerCandidateIds(){
  return state.activeParty.concat(intendedFormationIds()).filter(function(id,index,ids){
    return ids.indexOf(id)===index && SPIRITS.some(function(sp){return sp.id===id && state.maxDepthEver>=sp.unlockDepth;});
  });
}
function normalizeCurrentSave(input){
  var fresh = freshState();
  var out = freshState();
  var source = isPlainObject(input) ? input : {};

  out.schemaVersion = SAVE_SCHEMA_VERSION;

  ['lumen','shards','prisms','comets','motes','sigils'].forEach(function(key){
    out[key] = finiteNonNegative(source[key],fresh[key]);
  });

  out.depth = Math.max(1,nonNegativeInt(source.depth,1));
  out.maxDepthEver = Math.max(1,nonNegativeInt(source.maxDepthEver,out.depth));

  out.riftMode = source.riftMode==='farm' ? 'farm' : 'push';
  out.farmDepth = nonNegativeInt(source.farmDepth,0);
  out.farmReturnDepth = nonNegativeInt(source.farmReturnDepth,0);
  if(out.riftMode==='farm' && out.farmReturnDepth>1){
    out.farmDepth = highestFarmableDepth(out.farmReturnDepth);
    out.depth = out.farmDepth;
    out.maxDepthEver = Math.max(out.maxDepthEver,out.farmReturnDepth);
  } else {
    out.riftMode = 'push';
    out.farmDepth = 0;
    out.farmReturnDepth = 0;
    out.maxDepthEver = Math.max(out.maxDepthEver,out.depth);
  }

  var spirits = isPlainObject(source.spirits) ? source.spirits : {};
  var heroRarity = isPlainObject(source.heroRarity) ? source.heroRarity : {};
  var heroResource = isPlainObject(source.heroResource) ? source.heroResource : {};
  var wispModules = isPlainObject(source.wispModules) ? source.wispModules : {};
  var wispUltimate = isPlainObject(source.wispUltimate) ? source.wispUltimate : {};
  var empowerQueue = isPlainObject(source.empowerQueue) ? source.empowerQueue : {};
  SPIRITS.forEach(function(sp){
    out.spirits[sp.id] = nonNegativeInt(spirits[sp.id],fresh.spirits[sp.id]);
    out.heroRarity[sp.id] = boundedInt(heroRarity[sp.id],fresh.heroRarity[sp.id],0,RARITY_NAMES.length-1);
    out.heroResource[sp.id] = Math.max(0,Math.min(100,finiteNonNegative(heroResource[sp.id],fresh.heroResource[sp.id])));
    out.wispModules[sp.id] = boundedInt(wispModules[sp.id],fresh.wispModules[sp.id],0,MODULE_MAX_LEVEL);
    out.wispUltimate[sp.id] = strictBool(wispUltimate[sp.id],fresh.wispUltimate[sp.id]);
    if(out.heroRarity[sp.id]<RARITY_NAMES.length-1) out.wispUltimate[sp.id] = false;
    out.empowerQueue[sp.id] = strictBool(empowerQueue[sp.id],fresh.empowerQueue[sp.id]);
  });

  var party = Array.isArray(source.activeParty) ? source.activeParty : [];
  var seenParty = {};
  out.activeParty = party.filter(function(id){
    if(typeof id!=='string' || seenParty[id]) return false;
    if(!SPIRITS.some(function(sp){ return sp.id===id; })) return false;
    if((out.spirits[id]||0)<=0) return false;
    seenParty[id] = true;
    return true;
  }).slice(0,5);
  if(!out.activeParty.length){
    out.spirits.ember = Math.max(1,out.spirits.ember||0);
    out.activeParty = ['ember'];
  }

  var sourcePresets = isPlainObject(source.formationPresets) ? source.formationPresets : null;
  out.formationPresets = {};
  FORMATION_PRESET_IDS.forEach(function(name){
    var raw = sourcePresets && Array.isArray(sourcePresets[name]) ? sourcePresets[name] : out.activeParty;
    var seen = {};
    var normalized = raw.filter(function(id){
      if(typeof id!=='string' || seen[id]) return false;
      if(!SPIRITS.some(function(sp){return sp.id===id;})) return false;
      seen[id]=true;
      return true;
    }).slice(0,5);
    out.formationPresets[name] = normalized.length ? normalized : out.activeParty.slice();
  });
  var requestedPreset = FORMATION_PRESET_IDS.indexOf(source.activeFormationPreset)!==-1
    ? source.activeFormationPreset
    : (sourcePresets ? '' : 'push');
  out.activeFormationPreset = requestedPreset &&
    out.activeParty.join(',')===out.formationPresets[requestedPreset].join(',') ? requestedPreset : '';

  out.formationRebuild = normalizeFormationRebuild(source.formationRebuild,out);
  reconcileFormationRebuild(out);
  if(!out.activeParty.length){
    // Intent can invalidate an otherwise powered but unrelated party. Apply the
    // existing empty-party recovery now, then project again (Ember may be intended).
    out.spirits.ember = Math.max(1,out.spirits.ember||0);
    out.activeParty = ['ember'];
    reconcileFormationRebuild(out);
  }

  var nodes = isPlainObject(source.nodes) ? source.nodes : {};
  NODES.forEach(function(node){ out.nodes[node.id] = nonNegativeInt(nodes[node.id],fresh.nodes[node.id]); });

  var research = isPlainObject(source.research) ? source.research : {};
  var researchQueue = isPlainObject(source.researchQueue) ? source.researchQueue : {};
  RESEARCH.forEach(function(node){
    out.research[node.id] = nonNegativeInt(research[node.id],fresh.research[node.id]);
    out.researchQueue[node.id] = strictBool(researchQueue[node.id],fresh.researchQueue[node.id]);
  });

  var studyLevels = isPlainObject(source.longStudyLevels) ? source.longStudyLevels : {};
  var studyQueue = isPlainObject(source.studyQueue) ? source.studyQueue : {};
  LONG_STUDIES.forEach(function(node){
    out.longStudyLevels[node.id] = nonNegativeInt(studyLevels[node.id],fresh.longStudyLevels[node.id]);
    out.studyQueue[node.id] = strictBool(studyQueue[node.id],fresh.studyQueue[node.id]);
  });

  var activeStudies = Array.isArray(source.activeStudies) ? source.activeStudies : [];
  var seenStudies = {};
  out.activeStudies = activeStudies.filter(function(active){
    if(!isPlainObject(active) || typeof active.id!=='string' || seenStudies[active.id]) return false;
    if(!LONG_STUDIES.some(function(node){ return node.id===active.id; })) return false;
    var remaining = Number(active.remainingSec);
    var total = Number(active.totalDurationSec);
    var speed = Number(active.speedMult);
    var validSpeed = speed===1 || LAB_SPEED_TIERS.indexOf(speed)!==-1;
    if(!Number.isFinite(remaining) || !Number.isFinite(total) || total<=0 || !validSpeed) return false;
    seenStudies[active.id] = true;
    return true;
  }).slice(0,5).map(function(active){
    var total=Number(active.totalDurationSec);
    return {id:active.id,remainingSec:Math.max(0,Math.min(total,Number(active.remainingSec))),totalDurationSec:total,speedMult:Number(active.speedMult)};
  });

  var useMotes = isPlainObject(source.studyUseMotes) ? source.studyUseMotes : {};
  var speedTargets = isPlainObject(source.studySpeedTargets) ? source.studySpeedTargets : {};
  LONG_STUDIES.forEach(function(node){
    var validTarget=LAB_SPEED_TIERS.indexOf(speedTargets[node.id])!==-1;
    var paid=out.activeStudies.find(function(active){return active.id===node.id;});
    out.studySpeedTargets[node.id]=validTarget ? speedTargets[node.id] : paid && paid.speedMult>1 ? paid.speedMult : fresh.studySpeedTargets[node.id];
    // Malformed or missing targets cannot turn an ON value into spending intent.
    out.studyUseMotes[node.id]=validTarget && useMotes[node.id]===true;
  });

  var achieved = isPlainObject(source.achieved) ? source.achieved : {};
  ACHIEVEMENTS.forEach(function(a){ if(achieved[a.id]===true) out.achieved[a.id] = true; });

  var owned = isPlainObject(source.owned) ? source.owned : {};
  SHOP.forEach(function(item){ if(owned[item.id]===true) out.owned[item.id] = true; });

  var themeId = typeof source.riftTheme==='string' ? source.riftTheme : fresh.riftTheme;
  out.riftTheme = RIFT_THEMES.some(function(theme){ return theme.id===themeId; }) ? themeId : fresh.riftTheme;

  out.buffUntil = finiteNonNegative(source.buffUntil,fresh.buffUntil);
  out.buffMult = Math.max(1,finiteNonNegative(source.buffMult,fresh.buffMult));
  out.supportBuffs = normalizeSupportBuffs(source.supportBuffs);
  out.ascendCount = nonNegativeInt(source.ascendCount,fresh.ascendCount);
  out.sigilResonanceUses = boundedInt(source.sigilResonanceUses,fresh.sigilResonanceUses,0,SIGIL_RESONANCE_RUN_LIMIT);
  // Schema v1 remains compatible: older saves simply have no reward benchmark
  // and receive one final full first reward before future repeats diminish.
  out.ascendRewardedDepth = Math.min(
    Math.max(0,out.maxDepthEver-1),
    nonNegativeInt(source.ascendRewardedDepth,fresh.ascendRewardedDepth)
  );
  out.totalTaps = nonNegativeInt(source.totalTaps,fresh.totalTaps);
  out.totalKills = nonNegativeInt(source.totalKills,fresh.totalKills);
  out.totalOfflineSeconds = finiteNonNegative(source.totalOfflineSeconds,fresh.totalOfflineSeconds);
  out.luminousAccum = Math.max(0,Math.min(0.999999,finiteNonNegative(source.luminousAccum,fresh.luminousAccum)));
  out._autoTapAccum = Math.max(0,Math.min(999.999,finiteNonNegative(source._autoTapAccum,0)));
  out._autoEmpowerAccum = Math.max(0,Math.min(999.999,finiteNonNegative(source._autoEmpowerAccum,0)));

  var allowedMultipliers = [1,5,10,25,50,100,'max'];
  out.savedLabMultiplier = allowedMultipliers.indexOf(source.savedLabMultiplier)!==-1 ? source.savedLabMultiplier : fresh.savedLabMultiplier;

  out.autoAscendEnabled = strictBool(source.autoAscendEnabled,fresh.autoAscendEnabled);
  out.autoAscendTargetDepth = Math.max(16,nonNegativeInt(source.autoAscendTargetDepth,fresh.autoAscendTargetDepth));
  if(!out.owned.autoascend) out.autoAscendEnabled = false;

  out.enemyDepth = nonNegativeInt(source.enemyDepth,fresh.enemyDepth);
  out.enemyMaxHp = finiteNonNegative(source.enemyMaxHp,fresh.enemyMaxHp);
  out.enemyHp = finiteNonNegative(source.enemyHp,fresh.enemyHp);
  if(out.enemyMaxHp>0) out.enemyHp = Math.min(out.enemyHp,out.enemyMaxHp);
  else out.enemyHp = 0;
  out.enemyIsLuminous = strictBool(source.enemyIsLuminous,fresh.enemyIsLuminous);
  if(isBoss(out.enemyDepth)) out.enemyIsLuminous = false;

  out.loginStreak = nonNegativeInt(source.loginStreak,fresh.loginStreak);
  out.questDay = typeof source.questDay==='string' && (source.questDay==='' || /^\d{4}-\d{2}-\d{2}$/.test(source.questDay)) ? source.questDay : '';
  var knownQuestIds = {};
  QUEST_POOL.forEach(function(q){ knownQuestIds[q.id] = true; });
  var seenQuestIds = {};
  out.questIds = (Array.isArray(source.questIds) ? source.questIds : []).filter(function(id){
    if(typeof id!=='string' || !knownQuestIds[id] || seenQuestIds[id]) return false;
    seenQuestIds[id] = true;
    return true;
  }).slice(0,3);

  var questClaimed = isPlainObject(source.questClaimed) ? source.questClaimed : {};
  QUEST_POOL.forEach(function(q){ if(questClaimed[q.id]===true) out.questClaimed[q.id] = true; });
  out.dailyQuestRefreshes = nonNegativeInt(source.dailyQuestRefreshes,fresh.dailyQuestRefreshes);

  var dailyStats = isPlainObject(source.dailyStats) ? source.dailyStats : {};
  var metrics = {};
  QUEST_POOL.forEach(function(q){ metrics[q.metric] = true; });
  Object.keys(metrics).forEach(function(metric){ out.dailyStats[metric] = finiteNonNegative(dailyStats[metric],0); });

  out.lastSeen = finiteNonNegative(source.lastSeen,Date.now());
  if(out.lastSeen<=0) out.lastSeen = Date.now();
  return out;
}
function acceptPersistedState(input,sourceName){
  assertPersistedRootShape(input);
  var migrated = migratePersistedState(input);
  if(identifySaveSchemaVersion(migrated)!==SAVE_SCHEMA_VERSION){
    throw persistenceError('unsupported-schema','Save schema is not supported');
  }
  var normalized = normalizeCurrentSave(migrated);
  normalized.schemaVersion = SAVE_SCHEMA_VERSION;
  return normalized;
}
function parsePersistedState(raw,sourceName){
  if(typeof raw!=='string' || !raw.length) throw persistenceError('missing-save','Save data is missing');
  var parsed;
  try{ parsed = JSON.parse(raw); }
  catch(e){ throw persistenceError('invalid-json','Save data is not valid JSON'); }
  return acceptPersistedState(parsed,sourceName||'save');
}

var persistenceFailureCount = 0;
var persistenceWarningShown = false;
var persistenceLastError = '';
var persistenceBlocked = false;
var persistenceBlockedReason = '';
var recoveredFromRecovery = false;

function recordPersistenceFailure(error){
  persistenceFailureCount++;
  persistenceLastError = error && error.message ? error.message : String(error||'Unknown persistence error');
  if(persistenceFailureCount>=2 && !persistenceWarningShown){
    persistenceWarningShown = true;
    if(els && els['toast']) showToast('Saving is failing — recent progress may not persist.');
  }
}
function recordPersistenceSuccess(){
  persistenceFailureCount = 0;
  persistenceLastError = '';
  persistenceWarningShown = false;
}
function setPersistenceBlocked(reason){
  persistenceBlocked = true;
  persistenceBlockedReason = reason || 'Stored save data could not be accepted safely.';
}
function persistenceStatus(){
  return {
    failureCount:persistenceFailureCount,
    warningShown:persistenceWarningShown,
    lastError:persistenceLastError,
    blocked:persistenceBlocked,
    blockedReason:persistenceBlockedReason,
    recovered:recoveredFromRecovery
  };
}
function announcePersistenceStatus(){
  if(persistenceBlocked){
    if(!persistenceWarningShown){
      persistenceWarningShown = true;
      showToast('Save data needs recovery — Reset or restore a valid backup before progress can be saved.');
    }
    return;
  }
  if(recoveredFromRecovery) showToast('Recovered your last known-good save.');
}
function readPersistedSlot(key){
  var raw;
  try{ raw = localStorage.getItem(key); }
  catch(e){ return {raw:null,state:null,error:persistenceError('storage-read-failed','Stored save data could not be read')}; }
  if(!raw) return {raw:null,state:null,error:null};
  try{ return {raw:raw,state:parsePersistedState(raw,key),error:null}; }
  catch(e){ return {raw:raw,state:null,error:e}; }
}
function repairPrimaryFromRecovery(recovered){
  try{
    localStorage.setItem(SAVE_KEY,JSON.stringify(recovered));
    return true;
  }catch(e){
    recordPersistenceFailure(e);
    return false;
  }
}
function loadState(){
  var resetMarker = null;
  try{ resetMarker = localStorage.getItem(RESET_PENDING_KEY); }
  catch(e){
    setPersistenceBlocked('Browser storage is unavailable.');
    isNewGame = true;
    return freshState();
  }

  if(resetMarker==='1'){
    try{
      localStorage.removeItem(SAVE_KEY);
      localStorage.removeItem(RECOVERY_SAVE_KEY);
    }catch(e){ recordPersistenceFailure(e); }
    resetBootPending = true;
    isNewGame = true;
    return freshState();
  }

  var primary = readPersistedSlot(SAVE_KEY);
  if(primary.state) return primary.state;

  var recovery = readPersistedSlot(RECOVERY_SAVE_KEY);
  if(recovery.state){
    recoveredFromRecovery = true;
    if(primary.error && primary.error.code==='unsupported-future-schema'){
      setPersistenceBlocked('Primary save uses a newer unsupported schema. It has been preserved.');
      return recovery.state;
    }
    repairPrimaryFromRecovery(recovery.state);
    return recovery.state;
  }

  if(!primary.raw && !recovery.raw){
    isNewGame = true;
    return freshState();
  }

  if(primary.error && primary.error.code==='unsupported-future-schema'){
    setPersistenceBlocked('Primary save uses a newer unsupported schema. It has been preserved.');
  } else {
    setPersistenceBlocked('Stored save data is invalid and no valid recovery copy is available.');
  }
  isNewGame = true;
  return freshState();
}

function saveState(){
  if(resetInProgress || reloadInProgress) return;
  if(persistenceBlocked) return false;
  try{
    var candidate = clonePersistedValue(state);
    candidate.schemaVersion = SAVE_SCHEMA_VERSION;
    candidate.lastSeen = Date.now();
    var canonical = acceptPersistedState(candidate,'runtime');
    var serialized = JSON.stringify(canonical);

    localStorage.setItem(SAVE_KEY,serialized);
    localStorage.setItem(RECOVERY_SAVE_KEY,serialized);

    state = canonical;
    if(resetBootPending){
      localStorage.removeItem(RESET_PENDING_KEY);
      resetBootPending = false;
    }
    recordPersistenceSuccess();
    return true;
  }catch(e){
    recordPersistenceFailure(e);
    return false;
  }
}

var SAVE_BACKUP_PREFIX = 'LUMENFALL1:';
function encodeSaveBackup(obj){
  return SAVE_BACKUP_PREFIX + encodeURIComponent(JSON.stringify(obj));
}
function decodeSaveBackup(code){
  var clean = String(code||'').trim();
  if(clean.indexOf(SAVE_BACKUP_PREFIX)!==0) throw persistenceError('invalid-backup-prefix','Not a Lumenfall backup code');
  var parsed;
  try{ parsed = JSON.parse(decodeURIComponent(clean.slice(SAVE_BACKUP_PREFIX.length))); }
  catch(e){ throw persistenceError('invalid-backup-json','Backup code does not contain valid JSON'); }
  return acceptPersistedState(parsed,'backup');
}
function currentSaveBackup(){
  saveState();
  return encodeSaveBackup(acceptPersistedState(state,'backup-export'));
}
function copyTextFallback(textarea){
  textarea.focus();
  textarea.select();
  try{ return document.execCommand('copy'); }catch(e){ return false; }
}
function copyCurrentSaveBackup(){
  var textarea = document.getElementById('save-backup-code');
  var code = currentSaveBackup();
  textarea.value = code;
  if(navigator.clipboard && navigator.clipboard.writeText){
    navigator.clipboard.writeText(code).then(function(){
      showToast('Save backup copied.');
    }).catch(function(){
      showToast(copyTextFallback(textarea) ? 'Save backup copied.' : 'Backup ready — copy the selected text.');
    });
  } else {
    showToast(copyTextFallback(textarea) ? 'Save backup copied.' : 'Backup ready — copy the selected text.');
  }
}
function restoreSaveBackup(){
  var textarea = document.getElementById('save-backup-code');
  var oldRecovery = null;
  var recoveryWritten = false;
  try{
    var restored = decodeSaveBackup(textarea.value);
    restored.lastSeen = Date.now();
    restored.schemaVersion = SAVE_SCHEMA_VERSION;
    restored = acceptPersistedState(restored,'backup');
    var serialized = JSON.stringify(restored);

    oldRecovery = localStorage.getItem(RECOVERY_SAVE_KEY);
    localStorage.setItem(RECOVERY_SAVE_KEY,serialized);
    recoveryWritten = true;
    try{
      localStorage.setItem(SAVE_KEY,serialized);
    }catch(primaryError){
      try{
        if(oldRecovery===null) localStorage.removeItem(RECOVERY_SAVE_KEY);
        else localStorage.setItem(RECOVERY_SAVE_KEY,oldRecovery);
      }catch(rollbackError){}
      throw primaryError;
    }

    persistenceBlocked = false;
    persistenceBlockedReason = '';
    recoveredFromRecovery = false;
    recordPersistenceSuccess();

    // From this point onward the validated restored backup on disk is authoritative.
    // Block autosave/beforeunload from writing the pre-restore in-memory state over it.
    reloadInProgress = true;
    document.body.classList.add('app-paused');
    var settingsOverlay = document.getElementById('settings-overlay');
    if(settingsOverlay) settingsOverlay.style.display = 'none';
    showToast('Save restored. Reloading…');
    setTimeout(function(){ location.reload(); }, 120);
  }catch(e){
    if(recoveryWritten && reloadInProgress===false && oldRecovery!==null){
      // Best-effort rollback is already attempted above when the primary write fails.
    }
    reloadInProgress = false;
    showToast('That backup code is not valid or supported.');
  }
}

// ---------------------------------------------------------------
// Math helpers
// ---------------------------------------------------------------
function formatNum(n){
  n = Math.max(0, n);
  if(n < 1000) return (Math.round(n*10)/10).toString();
  var units = ['','K','M','B','T','Qa','Qi','Sx','Sp','Oc'];
  var tier = Math.min(Math.floor(Math.log10(n)/3), units.length-1);
  var scaled = n / Math.pow(10, tier*3);
  return scaled.toFixed(2) + units[tier];
}

var COST_ICON_MAP = {
  lumen: {name:'Lumen', shape:'shape-triangle', color:'var(--lumen)'},
  shard: {name:'Shards', shape:'shape-hex', color:'var(--shard)'},
  mote:  {name:'Motes', shape:'shape-pentagon', color:'var(--mote)'},
  prism: {name:'Prisms', shape:'shape-diamond', color:'var(--prism)'},
  comet: {name:'Comets', shape:'shape-star', color:'var(--comet)'},
  sigil: {name:'Sigils', shape:'shape-octagon', color:'var(--sigil)'}
};
function costIcon(kind){
  var m = COST_ICON_MAP[kind];
  return '<span class="shape '+m.shape+' cost-icon" role="img" aria-label="'+m.name+'" style="background:'+m.color+'"></span>';
}

function isBoss(depth){ return depth>0 && depth%10===0; }

var BOSS_TRAITS = [
  {id:'regrowth', name:'Regrowth', regen:0.009, abilityMult:1, tapMult:1, hint:'High regeneration — sustained Wisp damage matters.'},
  {id:'fractured', name:'Fractured Core', regen:0.005, abilityMult:1.75, tapMult:1, hint:'Wisp abilities deal +75% damage.'},
  {id:'guardian', name:"Guardian's Mark", regen:0.006, abilityMult:1, tapMult:3, hint:'Your taps deal x3 damage.'}
];
function bossTraitFor(depth){
  if(!isBoss(depth)) return null;
  var bossIndex = Math.max(0, Math.floor(depth/10)-1);
  return BOSS_TRAITS[bossIndex % BOSS_TRAITS.length];
}
function bossRegenRate(depth){
  var trait = bossTraitFor(depth);
  return trait ? trait.regen : 0;
}
function bossAbilityDamageMult(depth){
  var trait = bossTraitFor(depth);
  return trait ? trait.abilityMult : 1;
}
function bossTapDamageMult(depth){
  var trait = bossTraitFor(depth);
  return trait ? trait.tapMult : 1;
}

function riftZoneFor(depth){
  var zoneIndex = Math.max(0, Math.floor((Math.max(1,depth)-1)/RIFT_ZONE_SPAN));
  var base = RIFT_ZONES[zoneIndex % RIFT_ZONES.length];
  var echo = Math.floor(zoneIndex / RIFT_ZONES.length) + 1;
  return {
    name: base.name + (echo>1 ? ' · Echo '+echo : ''),
    accent: base.accent,
    index: zoneIndex
  };
}
function applyRiftZoneVisual(depth){
  var stageEl = document.getElementById('enemy-stage');
  if(!stageEl) return;
  var battleStage = document.querySelector('#tab-battle .stage');
  var zone = riftZoneFor(depth);
  var themeIndex = zone.index % RIFT_ZONES.length;
  if(stageEl.getAttribute('data-zone-index')!==String(zone.index)){
    stageEl.setAttribute('data-zone-index', String(zone.index));
    stageEl.setAttribute('data-zone-theme', String(themeIndex));
    stageEl.style.setProperty('--zone-accent', zone.accent);
    if(battleStage){
      battleStage.setAttribute('data-zone-index', String(zone.index));
      battleStage.setAttribute('data-zone-theme', String(themeIndex));
      battleStage.style.setProperty('--zone-accent', zone.accent);
    }
  }
}

function highestFarmableDepth(pushDepth){
  var d = Math.max(1, Math.floor(pushDepth||1)-1);
  while(d>1 && isBoss(d)) d--;
  return d;
}
function progressionDepth(){
  return state.riftMode==='farm' && state.farmReturnDepth ? state.farmReturnDepth : state.depth;
}
function clearedProgressionRift(){
  return Math.max(0,progressionDepth()-1);
}
function ascendEligible(){
  return clearedProgressionRift()>=15;
}
function canFarmCurrentProgress(){
  return progressionDepth()>1;
}
function enterFarmMode(){
  if(state.riftMode==='farm' || !canFarmCurrentProgress()) return;
  state.farmReturnDepth = state.depth;
  state.farmDepth = highestFarmableDepth(state.farmReturnDepth);
  state.riftMode = 'farm';
  state.depth = state.farmDepth;
  spawnEnemy(false);
  renderAll();
  saveState();
}
function enterPushMode(){
  if(state.riftMode!=='farm') return;
  state.depth = Math.max(1, state.farmReturnDepth||state.depth);
  state.riftMode = 'push';
  state.farmDepth = 0;
  state.farmReturnDepth = 0;
  spawnEnemy(false);
  renderAll();
  saveState();
}

function nodeLevel(id){ return state.nodes[id]||0; }
function researchLevel(id){ return state.research[id]||0; }
function researchEffectiveLevel(node,level){
  level = nonNegativeInt(level,0);
  return node.levelCap===undefined ? level : Math.min(level,node.levelCap);
}
function researchBonus(id,level){
  var node = RESEARCH.find(function(n){return n.id===id;});
  return node.effectPerLevel * researchEffectiveLevel(node,level===undefined ? researchLevel(id) : level);
}
function researchFactor(id,level){ return 1 + researchBonus(id,level); }

function lumenMult(){ return (1 + nodeLevel('starlight')*0.10) * researchFactor('focus') * longStudyLumenMult(); }
function shardMult(){ return researchFactor('sense') * longStudyShardMult(); }
function longStudyLevel(id){ return (state.longStudyLevels && state.longStudyLevels[id]) || 0; }
function longStudyPowerMult(){ return 1 + longStudyLevel('wispascend')*0.15; }
function longStudyTapMult(){ return 1 + longStudyLevel('guardmastery')*0.20; }
function longStudyOfflineBonus(){ return longStudyLevel('riftattune')*0.10; }
function longStudyShardMult(){ return 1 + longStudyLevel('shardstudy')*0.08; }
function longStudyLumenMult(){ return 1 + longStudyLevel('lumenstudy')*0.08; }
function longStudyFormationMult(){ return 1 + longStudyLevel('formationstudy')*0.05; }
function longStudyMoteMult(){ return 1 + longStudyLevel('motestudy')*0.10; }
function longStudyPrismMult(){ return 1 + longStudyLevel('prismstudy')*0.05; }
function tapMult(){ return (1 + nodeLevel('steady')*0.08) * researchFactor('resolve') * longStudyTapMult(); }
function formationMult(){ return researchFactor('formation') * longStudyFormationMult(); }
function momentumMult(){ return 1 + nodeLevel('momentum')*0.06; }
function fillRateMult(level){ return researchFactor('charge',level); }
function abilityCycleSeconds(level){ return ABILITY_BASE_CYCLE_SEC / fillRateMult(level); }
function offlineRate(){ return Math.min(1, 0.70 + nodeLevel('echo')*0.05) + longStudyOfflineBonus(); }
function prismMult(){ return (1 + nodeLevel('swift')*0.04) * longStudyPrismMult(); }
function costReduction(){ return Math.min(0.6, nodeLevel('bonds')*0.03); }
function offlineCapHours(){ return 12 + (state.owned.offline24?12:0) + (state.owned.offline48?24:0) + nodeLevel('reserves')*2; }
function eliteChance(depth,level){ return Math.min(0.35, Math.min(0.30, 0.03 + Math.floor(depth/10)*0.02) + researchBonus('luminoustracking',level)); }
function motesDropFor(depth){ return Math.max(1, Math.round((1 + depth/8) * longStudyMoteMult() * formationRewardMult())); }
function sigilsFromBoss(depth){ return Math.max(1, Math.floor(depth/10)); }

function moduleLevel(id){ return (state.wispModules && state.wispModules[id]) || 0; }
function moduleMult(id){ return 1 + moduleLevel(id)*0.05; }
function modulePacingMult(level){
  return Math.pow(MODULE_LATE_GROWTH,Math.max(0,level-(MODULE_LATE_GROWTH_START-1)));
}
function moduleCost(sp, level){
  var pacing = modulePacingMult(level);
  return {
    lumen: Math.round(sp.baseCost*4 * Math.pow(1.35, level) * pacing),
    shard: Math.round(sp.baseCost*0.4 * Math.pow(1.35, level) * pacing)
  };
}
function supportMoteBonus(){
  var bonus = 0;
  state.activeParty.forEach(function(id){
    var sp = SPIRITS.find(function(s){ return s.id===id; });
    if(!sp || sp.abilityType!=='support') return;
    if((state.spirits[id]||0)<=0) return;
    bonus += moduleLevel(id)*0.05;
  });
  return bonus;
}
function ultimateUnlocked(id){ return !!(state.wispUltimate && state.wispUltimate[id]); }
function ultimateSigilCost(sp){ return Math.round(5 + sp.unlockDepth*2); }
function totalUltimateSigilCost(){
  return SPIRITS.reduce(function(sum,sp){ return sum+ultimateSigilCost(sp); },0);
}
function allUltimatesOwned(){
  return SPIRITS.every(function(sp){ return ultimateUnlocked(sp.id); });
}
function canSigilResonate(sp){
  if(!sp || !allUltimatesOwned() || !ultimateUnlocked(sp.id)) return false;
  if((state.spirits[sp.id]||0)<=0 || state.activeParty.indexOf(sp.id)===-1) return false;
  if((state.heroResource[sp.id]||0)>=100) return false;
  if((state.sigilResonanceUses||0)>=SIGIL_RESONANCE_RUN_LIMIT) return false;
  return state.sigils>=SIGIL_RESONANCE_COST;
}
function useSigilResonance(sp){
  if(!canSigilResonate(sp)) return false;
  state.sigils-=SIGIL_RESONANCE_COST;
  state.sigilResonanceUses=(state.sigilResonanceUses||0)+1;
  state.heroResource[sp.id]=100;
  saveState();
  renderSpirits();
  renderHud();
  showToast(sp.name+' resonates — '+sp.abilityName+' is ready.');
  return true;
}

function synergyMult(){
  // Preserve the original permanent Rarity collection bonus.
  var sum = 0;
  SPIRITS.forEach(function(sp){ sum += (state.heroRarity[sp.id]||0)*0.02; });
  return 1+sum;
}

function poweredActiveIds(){
  return state.activeParty.filter(function(id){ return (state.spirits[id]||0)>0; });
}
function bondActive(bondId){
  var bond = FORMATION_BONDS.find(function(b){ return b.id===bondId; });
  if(!bond) return false;
  var active = poweredActiveIds();
  return bond.ids.every(function(id){ return active.indexOf(id)!==-1; });
}
function activeFormationBonds(){
  return FORMATION_BONDS.filter(function(b){ return bondActive(b.id); });
}
function formationGeneralDamageMult(){
  return bondActive('starcaller') ? 1.18 : 1;
}
function formationContextDamageMult(depth){
  var mult = formationGeneralDamageMult();
  if(isBoss(depth) && bondActive('duskguard')) mult *= 1.35;
  if(!isBoss(depth) && bondActive('pathfinder')) mult *= 1.20;
  return mult;
}
function formationRewardMult(){
  return bondActive('dawnpriest') ? 1.25 : 1;
}
function currentFormationFocus(){
  if(state.riftMode==='farm') return {label:'Farm', bonds:['dawnpriest','pathfinder']};
  if(isBoss(state.depth)) return {label:'Boss', bonds:['starcaller','duskguard']};
  return {label:'Push', bonds:['starcaller','pathfinder']};
}
function formationRecommendationText(){
  var focus = currentFormationFocus();
  var names = focus.bonds.map(function(id){
    var b = FORMATION_BONDS.find(function(x){ return x.id===id; });
    return b ? b.name.replace(' Bond','') : '';
  }).filter(Boolean);
  return focus.label + ': ' + names.join(' + ');
}

/*
 * P1-03 Wisp power / gameplay-language contract
 * ------------------------------------------------
 * Wisp Power = level-scaled spiritPower() × that Wisp's Rarity multiplier.
 * It is the shared per-Wisp input for passive damage, damaging abilities and
 * Gale/Thorn ability rewards. It does NOT set Support buff strength.
 *
 * Passive Wisp Damage = Active Wisp Power × passive-only permanent multipliers
 * (Formation Training, Rarity collection synergy, Eternal Momentum,
 * Wisp Ascendancy, Formation Insight) × applicable damage Bonds × Support buff.
 * Modules and Ultimates do not modify passive damage.
 *
 * Ability Damage = Wisp Power × ability coefficient × the Burst/Breaker Module
 * where applicable × Ultimate × applicable Formation damage Bonds ×
 * bossAbilityDamageMult(). Passive-only permanent multipliers and Support buffs
 * do not modify ability hits.
 *
 * Ability Rewards = Wisp Power × reward coefficient × that Ranged/Druid Module
 * × Ultimate × Dawnpriest reward multiplier. Kill-only Lumen/Shard multipliers
 * do not modify ability-generated resources.
 *
 * Support Buff = fixed by the Support ability: +25% for 4s, or +50% for 8s
 * with its Ultimate. Wisp Power, Rarity and Modules do not change this buff.
 *
 * Guardian Tap = (5 + 2% of general Active-party passive power) × Tap-specific
 * upgrades × active Support buff × bossTapDamageMult(). Auto-Tap uses the exact
 * same hit formula. Context-only Duskguard/Pathfinder damage Bonds do not
 * directly multiply Guardian Tap.
 */
function spiritPower(sp, level){
  if(level<=0) return 0;
  return sp.basePower * level * (1 + 0.01*(level-1));
}
function wispPower(sp,level){
  if(!sp || level<=0) return 0;
  var tier = state.heroRarity[sp.id]||0;
  return spiritPower(sp,level) * RARITY_MULT[tier];
}
function totalActivePartyPower(){
  var sum = 0;
  state.activeParty.forEach(function(id){
    var sp = SPIRITS.find(function(s){ return s.id===id; });
    if(!sp) return;
    sum += wispPower(sp,state.spirits[id]||0);
  });
  return sum;
}
function spiritCost(sp){
  var level = state.spirits[sp.id];
  var base = sp.baseCost * Math.pow(1.13, level);
  return Math.round(base * (1-costReduction()));
}
function nodeCost(node){
  var level = state.nodes[node.id];
  return Math.ceil(node.baseCost * Math.pow(node.growth, level));
}
/*
 * P2-01B permanent Wisp pacing contract
 * --------------------------------------
 * Rarity keeps the first upgrade at its existing accessibility point, then
 * deliberately widens both the current-run level requirement and permanent
 * resource commitment. The five upgrade tiers are explicit rather than hidden
 * behind one exponential so players can see the real price in the existing UI.
 *
 * Module levels 1-5 keep the previous curve exactly. From level 6 onward an
 * additional 1.18x late-growth factor applies per level, preserving useful
 * early Modules while making the final third a serious permanent investment.
 * The cap remains 20 and every level keeps the existing +5% role-specific gain.
 *
 * Existing saves are never repriced retroactively: stored Rarity/Module levels
 * remain valid even if they exceed a new current-run level requirement.
 */
function rarityReq(tier){
  return RARITY_LEVEL_REQUIREMENTS[Math.max(0,Math.min(RARITY_LEVEL_REQUIREMENTS.length-1,tier))];
}
function rarityCost(sp, tier){
  tier = Math.max(0,Math.min(RARITY_SHARD_COSTS.length-1,tier));
  return {
    shard: RARITY_SHARD_COSTS[tier],
    lumen: Math.round(sp.baseCost*RARITY_LUMEN_BASE_MULTS[tier])
  };
}

function passiveGlobalPowerMult(){
  return formationMult() * synergyMult() * momentumMult() * longStudyPowerMult();
}
function effectivePartyPower(){
  // General Active-party passive power includes Starcaller, but not the
  // context-only Duskguard/Pathfinder damage Bonds.
  return totalActivePartyPower() * passiveGlobalPowerMult() * formationGeneralDamageMult();
}
function chipEffectivePower(id){
  var sp = SPIRITS.find(function(s){ return s.id===id; });
  if(!sp) return 0;
  var shareMult = passiveGlobalPowerMult() * formationGeneralDamageMult();
  return wispPower(sp,state.spirits[id]||0) * shareMult * simulationBuffMult(Date.now());
}
function guardianTapBaseDamage(){
  return 5 + effectivePartyPower()*0.02;
}
function guardianTapDamageAt(depth, partyBuffMult){
  return guardianTapBaseDamage() * tapMult() * (partyBuffMult||1) * bossTapDamageMult(depth);
}
function tapDamage(){
  return guardianTapDamageAt(state.depth, simulationBuffMult(Date.now()));
}
function passiveWispDpsAt(depth){
  var contextual = formationContextDamageMult(depth) / formationGeneralDamageMult();
  return effectivePartyPower() * contextual;
}
function idleDps(){
  return passiveWispDpsAt(state.depth) * simulationBuffMult(Date.now());
}
function supportAbilityProfile(sp){
  var ultimate = !!(sp && ultimateUnlocked(sp.id));
  return {
    strength:ultimate ? 1.5 : 1.25,
    durationMs:ultimate ? 8000 : 4000
  };
}
function averageSupportBuffMult(){
  var cycle = abilityCycleSeconds();
  var total = 1;
  state.activeParty.forEach(function(id){
    var sp = SPIRITS.find(function(s){ return s.id===id; });
    if(!sp || sp.abilityType!=='support' || (state.spirits[id]||0)<=0) return;
    var profile = supportAbilityProfile(sp);
    var uptime = Math.min(1, (profile.durationMs/1000) / cycle);
    total += (profile.strength-1)*uptime;
  });
  return total;
}
function abilityDamageCoefficient(sp){
  if(!sp) return 0;
  if(sp.abilityType==='breaker') return 4;
  if(sp.abilityType==='dps') return 5;
  if(sp.abilityType==='ranged' || sp.abilityType==='druid') return 3;
  return 0;
}
function abilityDamageModuleMult(sp){
  return sp && (sp.abilityType==='dps' || sp.abilityType==='breaker') ? moduleMult(sp.id) : 1;
}
function abilityUltimateMult(sp){
  return sp && ultimateUnlocked(sp.id) ? 2 : 1;
}
function abilityRawBurst(sp,level){
  return wispPower(sp,level) * abilityDamageCoefficient(sp) * abilityDamageModuleMult(sp) * abilityUltimateMult(sp) * researchFactor('arcanecal');
}
function abilityBurstDamage(sp, depth){
  var level = state.spirits[sp.id]||0;
  if(level<=0) return 0;
  return abilityRawBurst(sp,level) * formationContextDamageMult(depth) * bossAbilityDamageMult(depth);
}
function abilityRewardRaw(sp,level,conductionLevel){
  if(!sp || level<=0) return {lumen:0,shards:0};
  var power = wispPower(sp,level);
  var mult = moduleMult(sp.id) * abilityUltimateMult(sp) * formationRewardMult() * researchFactor('conduction',conductionLevel);
  return {
    lumen:sp.abilityType==='druid' ? power*0.10*mult : 0,
    shards:sp.abilityType==='ranged' ? power*0.05*mult : 0
  };
}
function abilityRewardPerCast(sp,level,conductionLevel){
  var raw = abilityRewardRaw(sp,level,conductionLevel);
  return {lumen:Math.round(raw.lumen),shards:Math.round(raw.shards)};
}
function ultimateEffectText(sp){
  if(!sp) return 'Ultimate unlocked';
  if(sp.abilityType==='support') return 'Support buff becomes +50% for 8s';
  if(sp.abilityType==='ranged') return 'Ability damage and Shards ×2';
  if(sp.abilityType==='druid') return 'Ability damage and Lumen ×2';
  return 'Ability damage ×2';
}
function averageAbilityDps(depth){
  var cycle = abilityCycleSeconds();
  if(cycle<=0) return 0;
  var total = 0;
  state.activeParty.forEach(function(id){
    var sp = SPIRITS.find(function(s){ return s.id===id; });
    if(!sp || (state.spirits[id]||0)<=0) return;
    total += abilityBurstDamage(sp, depth) / cycle;
  });
  return total;
}
function sustainedWispDps(depth){
  return passiveWispDpsAt(depth) * averageSupportBuffMult() + averageAbilityDps(depth);
}
function automatedGuardianDps(depth){
  if(!state.achieved.autotap) return 0;
  return guardianTapDamageAt(depth, averageSupportBuffMult());
}
function sustainedCombatDps(depth){
  return sustainedWispDps(depth) + automatedGuardianDps(depth);
}
function estimatedBossKillSeconds(depth){
  if(!isBoss(depth)) return 0;
  var maxHp = enemyHpFor(depth);
  var netDps = sustainedCombatDps(depth) - maxHp*bossRegenRate(depth);
  return netDps>0 ? maxHp/netDps : Infinity;
}
function abilityResourceRates(){
  var cycle = abilityCycleSeconds();
  var rates = {lumen:0, shards:0};
  if(cycle<=0) return rates;
  state.activeParty.forEach(function(id){
    var sp = SPIRITS.find(function(s){ return s.id===id; });
    var level = state.spirits[id]||0;
    if(!sp || level<=0) return;
    var rewards = abilityRewardRaw(sp,level);
    rates.lumen += rewards.lumen/cycle;
    rates.shards += rewards.shards/cycle;
  });
  return rates;
}
function enemyHpFor(depth){
  return Math.round(10 * Math.pow(1.145, depth) * (isBoss(depth)?6:1));
}
function enemyRewardFor(depth){
  return Math.round(5 * Math.pow(1.11, depth) * (isBoss(depth)?8:1) * lumenMult() * formationRewardMult());
}
function shardRewardFor(depth){
  return Math.round(1 * Math.pow(1.09, depth) * (isBoss(depth)?5:1) * shardMult() * formationRewardMult());
}
function enemyNameFor(depth){
  var adj = ENEMY_ADJ[depth % ENEMY_ADJ.length];
  var noun = ENEMY_NOUN[(depth*7) % ENEMY_NOUN.length];
  return isBoss(depth) ? ('The '+adj+' '+noun) : (adj+' '+noun);
}

function spawnEnemy(rollLuminous){
  state.enemyDepth = state.depth;
  state.enemyMaxHp = enemyHpFor(state.depth);
  state.enemyHp = state.enemyMaxHp;
  if(isBoss(state.depth)){
    state.enemyIsLuminous = false;
  } else if(rollLuminous===false){
    // UI mode changes must not advance the rare-enemy pity counter.
    state.enemyIsLuminous = false;
  } else {
    state.luminousAccum = (state.luminousAccum||0) + eliteChance(state.depth);
    if(state.luminousAccum >= 1){
      state.enemyIsLuminous = true;
      state.luminousAccum -= 1;
    } else {
      state.enemyIsLuminous = false;
    }
  }
}

function restoreEnemyOrSpawn(){
  var expectedMax = enemyHpFor(state.depth);
  var savedMax = Number(state.enemyMaxHp);
  var savedHp = Number(state.enemyHp);
  var sameDepth = state.enemyDepth===state.depth;
  if(sameDepth && Number.isFinite(savedMax) && savedMax>0 && Number.isFinite(savedHp) && savedHp>0){
    var hpRatio = Math.max(0,Math.min(1,savedHp/savedMax));
    state.enemyMaxHp = expectedMax;
    state.enemyHp = Math.max(0.0001,expectedMax*hpRatio);
    if(isBoss(state.depth)) state.enemyIsLuminous = false;
    return;
  }
  spawnEnemy(true);
}

function gainLumen(n){ state.lumen += n; }

function emitCombatVfx(type,color,wispId){
  var stageEl = els && els['enemy-stage'];
  if(!stageEl || document.hidden || !document.getElementById('tab-battle').classList.contains('active')) return;
  if(wispId){
    var card=document.querySelector('[data-rift-wisp="'+wispId+'"]');
    if(card && type!=='shot') card.setAttribute('data-cast-until',String(Date.now()+650));
  }
  if(window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  // Bound simultaneous decorative nodes even when five abilities fire together.
  if(stageEl.querySelectorAll('.combat-vfx').length>=8) return;
  var fx = document.createElement('span');
  fx.setAttribute('aria-hidden','true');
  fx.className = 'combat-vfx vfx-'+type;
  if(type!=='shot'){
    if(wispId)fx.classList.add('wisp-cast','cast-'+wispId);
    var glyph=els['enemy-glyph'].getBoundingClientRect(),bounds=stageEl.getBoundingClientRect();
    fx.style.top=(type==='support' ? stageEl.clientHeight-62 : glyph.y-bounds.y+glyph.height/2)+'px';
  }
  if(type==='shot' && card){
    fx.classList.add('shot-'+wispId);
    var from=card.getBoundingClientRect(),to=els['enemy-glyph'].getBoundingClientRect(),area=stageEl.getBoundingClientRect();
    fx.style.setProperty('--from-x',(from.x-area.x+from.width/2-5)+'px');
    // Formation cards sit below HP; project their shots from the arena's lower edge.
    fx.style.setProperty('--from-y',Math.min(stageEl.clientHeight-12,Math.max(24,from.y-area.y+14))+'px');
    fx.style.setProperty('--to-x',(to.x-area.x+to.width/2-5)+'px');
    fx.style.setProperty('--to-y',(to.y-area.y+to.height/2-5)+'px');
    card.setAttribute('data-shot-until',String(Date.now()+300));
  }
  if(color) fx.style.setProperty('--vfx-color',color);
  stageEl.appendChild(fx);
  setTimeout(function(){ if(fx.parentNode) fx.parentNode.removeChild(fx); },900);
}
// Sample the continuous passive-damage stream; this creates no damage event.
var passiveFxAt=-Infinity,passiveFxIndex=0;
function presentPassiveWispAttack(){
  if(document.hidden || !els['enemy-stage'] || !document.getElementById('tab-battle').classList.contains('active') || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  var now=Date.now();if(now-passiveFxAt<350)return;
  var ids=poweredActiveIds();if(!ids.length)return;
  var id=ids[passiveFxIndex%ids.length],sp=SPIRITS.find(function(x){return x.id===id;});
  passiveFxAt=now;passiveFxIndex=(passiveFxIndex+1)%ids.length;
  emitCombatVfx('shot',sp.color,id);
}
function flashBattleStage(kind){
  var stage = document.querySelector('#tab-battle .stage');
  if(!stage) return;
  var cls = 'impact-'+kind;
  stage.classList.remove(cls);
  void stage.offsetWidth;
  stage.classList.add(cls);
  setTimeout(function(){ stage.classList.remove(cls); },520);
}
function showRiftMilestone(kicker,title,subtitle,accent){
  var stage = document.querySelector('#tab-battle .stage');
  if(!stage) return;
  var old = stage.querySelector('.rift-milestone');
  if(old) old.remove();
  var banner = document.createElement('div');
  banner.className = 'rift-milestone';
  if(accent) banner.style.setProperty('--milestone-accent',accent);
  banner.innerHTML =
    '<span class="milestone-kicker">'+kicker+'</span>'+
    '<strong>'+title+'</strong>'+
    (subtitle ? '<small>'+subtitle+'</small>' : '');
  stage.appendChild(banner);
  setTimeout(function(){ banner.classList.add('leaving'); },1450);
  setTimeout(function(){ if(banner.parentNode) banner.parentNode.removeChild(banner); },1850);
}
function announceDepthMilestone(depth,previousMax){
  if(depth<=previousMax) return;
  var unlocked = SPIRITS.find(function(sp){ return sp.unlockDepth===depth; });
  if(unlocked){
    showRiftMilestone('WISP AWAKENED',unlocked.name,unlocked.heroClass+' · '+unlocked.role,unlocked.color);
    flashBattleStage('milestone');
    return;
  }
  if(isBoss(depth)){
    var trait = bossTraitFor(depth);
    showRiftMilestone('BOSS RIFT','Rift '+depth,trait ? trait.name : 'Boss encounter','#ef5b6b');
    flashBattleStage('boss');
    return;
  }
  if(depth===16 && state.ascendCount===0){
    showRiftMilestone('ASCENSION READY','Permanent power unlocked','Ascend whenever the wall wins','#b088f9');
    flashBattleStage('milestone');
    return;
  }
  if(depth>1 && (depth-1)%RIFT_ZONE_SPAN===0){
    var zone = riftZoneFor(depth);
    showRiftMilestone('NEW REGION',zone.name,'Rift '+depth,zone.accent);
    flashBattleStage('milestone');
  }
}

function dealDamage(amount){
  state.enemyHp -= amount;
  if(state.enemyHp <= 0){ defeatEnemy(); }
}

function defeatEnemy(){
  var defeatedDepth = state.depth;
  var previousMax = state.maxDepthEver;
  var reward = enemyRewardFor(state.depth);
  var shardGain = shardRewardFor(state.depth);
  var wasLuminous = state.enemyIsLuminous;
  var wasBoss = isBoss(state.depth);
  var defeatedName = enemyNameFor(state.depth);

  emitCombatVfx(wasBoss ? 'boss-death' : (wasLuminous ? 'luminous-death' : 'death'), wasBoss ? '#ef5b6b' : (wasLuminous ? '#ff8fae' : riftZoneFor(state.depth).accent));
  flashBattleStage(wasBoss ? 'victory' : 'kill');

  gainLumen(reward);
  state.shards += shardGain;
  spawnFloatNum('+'+formatNum(reward)+' Lumen', els['enemy-stage'],'lumen');

  var sigilGain = 0;
  if(wasLuminous){
    var moteGain = Math.max(1, Math.round(motesDropFor(state.depth) * (1+supportMoteBonus())));
    state.motes += moteGain;
    spawnFloatNum('+'+formatNum(moteGain)+' Motes', els['enemy-stage'],'mote');
    showToast('Luminous '+defeatedName+' defeated — +'+moteGain+' Motes');
    trackDaily('luminousKills');
  }
  if(wasBoss){
    sigilGain = sigilsFromBoss(state.depth);
    state.sigils += sigilGain;
    spawnFloatNum('+'+formatNum(sigilGain)+' Sigils', els['enemy-stage'],'sigil');
    trackDaily('bossKills');
    if(navigator.vibrate) navigator.vibrate(22);
  }

  state.totalKills++;
  trackDaily('kills');

  if(state.riftMode==='farm'){
    state.depth = state.farmDepth;
    spawnEnemy();
  } else {
    state.depth++;
    state.maxDepthEver = Math.max(state.maxDepthEver, state.depth);
    spawnEnemy();

    if(wasBoss){
      showRiftMilestone('BOSS DEFEATED','Rift '+defeatedDepth+' conquered','+'+sigilGain+' Sigils','#ff8552');
    } else {
      announceDepthMilestone(state.depth,previousMax);
    }

    if(checkAutoAscend()) return;
  }

  checkAchievements();
  renderDynamic();
  renderSideStats();
}

var MIN_AUTO_ASCEND_RIFT = 16;
// schema-v1 stores the legacy encounter threshold N, meaning clear N-1.
function autoAscendTarget(){
  return Math.max(MIN_AUTO_ASCEND_RIFT, Math.floor(state.autoAscendTargetDepth||MIN_AUTO_ASCEND_RIFT));
}
function autoAscendClearedTarget(){
  return Math.max(15,autoAscendTarget()-1);
}
function autoAscendReady(){
  return !!(state.riftMode!=='farm' && state.owned.autoascend && state.autoAscendEnabled && ascendEligible() && clearedProgressionRift()>=autoAscendClearedTarget());
}
// This ceiling is the existing safe-integer input boundary, never a save clamp.
function autoAscendHighestClearedTarget(){
  return Math.min(Number.MAX_SAFE_INTEGER,Math.max(15,Math.floor(state.maxDepthEver||1)-1));
}
var autoAscendWindowStart=null; // Local view only; never persisted.
function renderAutoAscendTarget(select){
  var highest=autoAscendHighestClearedTarget(),target=autoAscendClearedTarget();
  if(highest<=214) autoAscendWindowStart=15;
  else if(autoAscendWindowStart===null || !select.dataset.optionsKey)
    autoAscendWindowStart=Math.max(15,Math.min(target,highest)-99);
  else if(autoAscendWindowStart>highest) autoAscendWindowStart=Math.max(15,highest-199);
  var start=autoAscendWindowStart;
  var count=Math.min(200,highest-start+1);
  var end=start+count-1,pinned=target<start || target>end;
  var key=start+'|'+end+'|'+(pinned?target:'');
  if(select.dataset.optionsKey!==key){
    var options=document.createDocumentFragment();
    // Offset arithmetic stays exact even at the final safe-integer endpoint.
    for(var offset=0;offset<count;offset++){
      var cleared=start+offset;
      options.appendChild(new Option('Clear Rift '+cleared,String(cleared)));
    }
    if(pinned) options.appendChild(new Option('Clear Rift '+target+' (saved target)',String(target)));
    select.replaceChildren(options);
    select.dataset.optionsKey=key;
  }
  select.dataset.windowStart=String(start);select.dataset.windowEnd=String(end);
  select.value=String(target);
  var card=select.closest('[data-autoascend-card]'),nav=card.querySelector('[data-autoascend-nav]');
  nav.hidden=highest<=214;
  card.querySelector('[data-autoascend-earlier]').disabled=start===15;
  card.querySelector('[data-autoascend-later]').disabled=end===highest;
  card.querySelector('[data-autoascend-range]').textContent='Showing Rifts '+start+'–'+end+'. Find moves this list without changing your target.';
  presentControlStates(nav);
}
function findAutoAscendRift(value){
  var cleared=Number(value),select=els['shop-list'].querySelector('[data-autoascend-target]');
  if(!state.owned.autoascend || !select || typeof value!=='string' || String(cleared)!==value ||
    !Number.isSafeInteger(cleared) || cleared<15 || cleared>autoAscendHighestClearedTarget()) return false;
  autoAscendWindowStart=Math.max(15,cleared-99);
  renderAutoAscendTarget(select);
  return true;
}
function shiftAutoAscendWindow(direction){
  var select=els['shop-list'].querySelector('[data-autoascend-target]');
  if(!state.owned.autoascend || !select || (direction!==-1 && direction!==1)) return false;
  var start=Number(select.dataset.windowStart),end=Number(select.dataset.windowEnd);
  if(direction===-1){if(start===15) return false;autoAscendWindowStart=Math.max(15,start-200);}
  else {if(end===autoAscendHighestClearedTarget()) return false;autoAscendWindowStart=end+1;}
  renderAutoAscendTarget(select);
  return true;
}
function setAutoAscendClearedTarget(value){
  var cleared=Number(value);
  if(!state.owned.autoascend || typeof value!=='string' || String(cleared)!==value ||
    !Number.isSafeInteger(cleared) || cleared<15 ||
    (cleared>autoAscendHighestClearedTarget() && cleared!==autoAscendClearedTarget())) return false;
  var select=els['shop-list'].querySelector('[data-autoascend-target]');
  if(!select || !select.querySelector('option[value="'+value+'"]') || cleared+1===state.autoAscendTargetDepth) return false;
  state.autoAscendTargetDepth=cleared+1;
  saveState();
  return true;
}
function checkAutoAscend(){
  if(!autoAscendReady()) return false;
  doAscend(true);
  return true;
}

// ---------------------------------------------------------------
// Achievements
// ---------------------------------------------------------------
function applyAchievementChecks(){
  var changed = [];
  ACHIEVEMENTS.forEach(function(a){
    if(!state.achieved[a.id] && a.check(state)){
      state.achieved[a.id] = true;
      state.comets += a.reward;
      changed.push(a);
    }
  });
  return changed;
}
function checkAchievements(){
  var changed = applyAchievementChecks();
  if(changed.length){
    renderAchievements();
    renderNodes();
    var newest = changed[changed.length-1];
    showToast('Deed complete — '+newest.name+' · +'+newest.reward+' Comets');
  }
  return changed;
}

// ---------------------------------------------------------------
// Actions
// ---------------------------------------------------------------
function doTap(stageEl){
  var dmg = tapDamage();
  state.totalTaps++;
  trackDaily('taps');
  spawnFloatNum(formatNum(dmg), stageEl,'damage');
  emitCombatVfx('tap',riftZoneFor(state.depth).accent);
  stageEl.classList.add('hit');
  setTimeout(function(){ stageEl.classList.remove('hit'); }, 90);
  dealDamage(dmg);
  updateBattleFast();
  renderDaily();
}

function buySpirit(sp){
  if(!sp || state.maxDepthEver<sp.unlockDepth) return;
  var rebuilding = !!state.formationRebuild;
  var cost = spiritCost(sp);
  if(state.lumen < cost) return;
  var wasZero = state.spirits[sp.id]===0;
  state.lumen -= cost;
  state.spirits[sp.id]++;
  trackDaily('empowers');
  reconcileFormationRebuild(state);
  if(!rebuilding && wasZero && state.activeParty.length<5 && state.activeParty.indexOf(sp.id)===-1){
    state.activeParty.push(sp.id);
    state.activeFormationPreset = '';
  }
  checkAchievements();
  renderSpirits();
  if(wasZero){
    showToast(sp.name+' joined your roster.');
    pulseWispCard(sp.id,'recruit');
  }
  updateBattleFast();
  renderSideStats();
}

function buyRarity(sp){
  var tier = state.heroRarity[sp.id]||0;
  if(tier>=5) return;
  var level = state.spirits[sp.id];
  if(level < rarityReq(tier)) return;
  var cost = rarityCost(sp, tier);
  if(state.shards<cost.shard || state.lumen<cost.lumen) return;
  state.shards -= cost.shard;
  state.lumen -= cost.lumen;
  state.heroRarity[sp.id] = tier+1;
  checkAchievements();
  saveState();
  renderSpirits();
  showToast(sp.name+' reached '+RARITY_NAMES[tier+1]+'.');
  pulseWispCard(sp.id,'rarity');
  updateBattleFast();
}

function toggleActive(id){
  var idx = state.activeParty.indexOf(id);
  if(idx!==-1){
    if(state.activeParty.length<=1){ showToast('You need at least one Active Wisp.'); return; }
    state.activeParty.splice(idx,1);
  } else {
    if(state.spirits[id]<=0) return;
    if(state.activeParty.length>=5){ showToast('Bench a Wisp first — max 5 Active.'); return; }
    state.activeParty.push(id);
  }
  state.formationRebuild = null;
  state.activeFormationPreset = '';
  saveState();
  renderSpirits();
  updateBattleFast();
}

function formationPresetMembers(name){
  var raw = state.formationPresets && Array.isArray(state.formationPresets[name]) ? state.formationPresets[name] : [];
  return raw.filter(function(id,index){
    return SPIRITS.some(function(sp){return sp.id===id;}) && raw.indexOf(id)===index;
  }).slice(0,5);
}
function formationPresetUnavailable(name){
  return formationPresetMembers(name).filter(function(id){return (state.spirits[id]||0)<=0;});
}
function formationPresetIsActive(name){
  return state.activeFormationPreset===name && state.activeParty.join(',')===formationPresetMembers(name).join(',');
}
function applyFormationPreset(name){
  if(FORMATION_PRESET_IDS.indexOf(name)===-1) return false;
  var members = formationPresetMembers(name);
  var unavailable = formationPresetUnavailable(name);
  if(!members.length || unavailable.length){
    if(unavailable.length){
      var missing = unavailable.map(function(id){
        var sp=SPIRITS.find(function(item){return item.id===id;});
        return sp ? sp.shortName : id;
      });
      showToast('Recruit '+missing.join(', ')+' before using this formation.');
    } else {
      showToast('Save at least one Active Wisp to this formation.');
    }
    return false;
  }
  state.formationRebuild = null;
  state.activeParty = members.slice();
  state.activeFormationPreset = name;
  saveState();
  renderSpirits();
  updateBattleFast();
  showToast(FORMATION_PRESET_LABELS[name]+' formation active.');
  return true;
}
function saveFormationPreset(name){
  if(FORMATION_PRESET_IDS.indexOf(name)===-1 || !state.activeParty.length) return false;
  if(!state.formationPresets) state.formationPresets={};
  state.formationRebuild = null;
  state.formationPresets[name] = state.activeParty.slice(0,5);
  state.activeFormationPreset = name;
  saveState();
  renderSpirits();
  showToast(FORMATION_PRESET_LABELS[name]+' formation saved.');
  return true;
}
function applicableAutoEmpowerIds(){
  return SPIRITS.filter(function(sp){return (state.spirits[sp.id]||0)>0 || intendedFormationIds().indexOf(sp.id)!==-1;}).map(function(sp){return sp.id;});
}
function autoEmpowerAllState(){
  var ids=applicableAutoEmpowerIds();
  var enabled=ids.filter(function(id){return state.empowerQueue[id]!==false;}).length;
  return {ids:ids,enabled:enabled,value:enabled===0?'off':(enabled===ids.length?'on':'mixed')};
}
function setAutoEmpowerAll(enabled){
  var summary=autoEmpowerAllState();
  summary.ids.forEach(function(id){state.empowerQueue[id]=!!enabled;});
  saveState();
  renderSpirits();
  showToast('Auto-Empower All '+(enabled?'ON':'OFF')+'.');
}

function buyModule(sp){
  var level = moduleLevel(sp.id);
  if(level>=MODULE_MAX_LEVEL) return;
  var cost = moduleCost(sp, level);
  if(state.lumen<cost.lumen || state.shards<cost.shard) return;
  state.lumen -= cost.lumen;
  state.shards -= cost.shard;
  state.wispModules[sp.id] = level+1;
  saveState();
  renderSpirits();
  if(level+1>=MODULE_MAX_LEVEL){
    showToast(sp.name+' Module perfected.');
    pulseWispCard(sp.id,'rarity');
  }
  updateBattleFast();
}

function buyUltimate(sp){
  var tier = state.heroRarity[sp.id]||0;
  if(tier<5 || ultimateUnlocked(sp.id)) return;
  var cost = ultimateSigilCost(sp);
  if(state.sigils<cost) return;
  state.sigils -= cost;
  state.wispUltimate[sp.id] = true;
  checkAchievements();
  saveState();
  renderSpirits();
  showToast(sp.name+' Ultimate awakened — '+sp.abilityName+' doubled.');
  pulseWispCard(sp.id,'ultimate');
  updateBattleFast();
}

function themeUnlocked(theme){ return !theme.unlockAchievement || !!state.achieved[theme.unlockAchievement]; }
function selectRiftTheme(themeId){
  var theme = RIFT_THEMES.find(function(t){ return t.id===themeId; });
  if(!theme || !themeUnlocked(theme)) return;
  state.riftTheme = themeId;
  applyRiftTheme();
  renderCosmetics();
}
function applyRiftTheme(){
  var stageEl = document.getElementById('enemy-stage');
  if(!stageEl) return;
  var theme = RIFT_THEMES.find(function(t){ return t.id===state.riftTheme; }) || RIFT_THEMES[0];
  stageEl.classList.toggle('theme-radiant', theme.id==='radiant');
  if(theme.accent){ stageEl.style.setProperty('--theme-accent', theme.accent); }
  else { stageEl.style.removeProperty('--theme-accent'); }
}

function buyNode(node){
  var cost = nodeCost(node);
  if(state.prisms < cost) return;
  state.prisms -= cost;
  state.nodes[node.id]++;
  saveState();
  renderNodes();
  renderAscendSummary();
  updateBattleFast();
}

var labMultiplier = 1;
var MULT_OPTIONS = [1, 5, 10, 25, 50, 100, 'max'];

function geometricSum(base, growth, startLevel, count){
  if(base<=0 || count<=0) return 0;
  if(growth===1) return base*count;
  return base * Math.pow(growth, startLevel) * (Math.pow(growth, count)-1) / (growth-1);
}
function researchCostForLevels(node, level, count){
  return {
    lumen: Math.ceil(geometricSum(node.lumenBase, node.lumenGrowth, level, count)),
    shard: Math.ceil(geometricSum(node.shardBase, node.shardGrowth, level, count))
  };
}
function maxAffordableLevels(node, level, lumenBudget, shardBudget){
  var hi = 1;
  while(true){
    var c = researchCostForLevels(node, level, hi);
    if(c.lumen>lumenBudget || c.shard>shardBudget || hi>1000000) break;
    hi *= 2;
  }
  var lo = Math.floor(hi/2);
  hi = Math.max(hi, lo);
  while(lo<hi){
    var mid = Math.ceil((lo+hi+1)/2);
    var cm = researchCostForLevels(node, level, mid);
    if(cm.lumen<=lumenBudget && cm.shard<=shardBudget){ lo = mid; } else { hi = mid-1; }
  }
  return lo;
}
function researchEligibility(node){
  var level = researchLevel(node.id);
  return {level:level,unlocked:state.maxDepthEver>=(node.unlockDepth||1),
    maxed:node.levelCap!==undefined && level>=node.levelCap};
}
function getResearchBuyPlan(node,requested){
  var e = researchEligibility(node);
  requested = requested===undefined ? labMultiplier : requested;
  var validRequest = requested==='max' || (Number.isInteger(requested) && requested>0);
  var count = 0, cost = {lumen:0,shard:0};
  var reason = !e.unlocked ? 'locked' : e.maxed ? 'maxed' : !validRequest ? 'unavailable' : '';
  if(!reason){
    if(node.levelCap!==undefined){
      var limit = Math.min(node.levelCap-e.level,requested==='max' ? Infinity : requested);
      // At most ten candidates for this catalogue; price is the rounded total
      // geometric sum, never a sum of individually rounded level prices.
      while(count<limit){
        var next = researchCostForLevels(node,e.level,count+1);
        if(!Number.isFinite(next.lumen) || !Number.isFinite(next.shard) || next.lumen>state.lumen || next.shard>state.shards) break;
        count++;cost=next;
      }
    } else {
      var n = requested==='max' ? maxAffordableLevels(node,e.level,state.lumen,state.shards) : requested;
      var candidate = researchCostForLevels(node,e.level,n);
      if(n>0 && Number.isFinite(candidate.lumen) && Number.isFinite(candidate.shard) && candidate.lumen<=state.lumen && candidate.shard<=state.shards){count=n;cost=candidate;}
    }
    if(!count) reason='unaffordable';
  }
  var needed = reason==='unaffordable' ? researchCostForLevels(node,e.level,node.levelCap!==undefined || requested==='max' ? 1 : requested) : cost;
  return {count:count,buyCount:count,cost:cost,needed:needed,affordable:count>0,reason:reason,level:e.level,unlocked:e.unlocked,maxed:e.maxed};
}
function researchEffectPreview(node,level){
  var value = {factor:researchFactor(node.id,level),bonus:researchBonus(node.id,level)};
  if(node.id==='charge'){value.cycle=abilityCycleSeconds(level);}
  if(node.id==='conduction'){
    value.casts={};
    ['gale','thorn'].forEach(function(id){
      var sp=SPIRITS.find(function(sp){return sp.id===id;});
      value.casts[id]=abilityRewardPerCast(sp,state.spirits[id]||0,level);
    });
  }
  if(node.id==='luminoustracking'){value.chance=isBoss(state.depth)?0:eliteChance(state.depth,level);value.depth=state.depth;value.boss=isBoss(state.depth);}
  return value;
}
function researchPreview(node,requested){
  var plan=getResearchBuyPlan(node,requested),level=plan.level;
  return {plan:plan,current:researchEffectPreview(node,level),
    next:plan.maxed?null:researchEffectPreview(node,level+1),
    purchase:researchEffectPreview(node,level+plan.buyCount)};
}
function researchEffectText(node,value){
  function decimal(n){return Number(n.toFixed(4)).toString();}
  if(node.id==='luminoustracking') return '+'+decimal(value.bonus*100)+' percentage points; '+
    (value.boss ? 'Boss Rift '+value.depth+': never Luminous' : 'future eligible Rift '+value.depth+' encounter: '+decimal(value.chance*100)+'%');
  var text='×'+decimal(value.factor)+' source factor';
  if(node.id==='charge') text+=' fill; '+decimal(value.cycle)+'s ability cycle';
  if(node.id==='conduction') text+='; per cast at current Wisp levels: Gale '+value.casts.gale.shards.toLocaleString('en-US')+' Shards, Thorn '+value.casts.thorn.lumen.toLocaleString('en-US')+' Lumen';
  return text;
}
function researchPreviewText(node,preview){
  var p=preview.plan;
  var impact=p.buyCount ? researchEffectText(node,preview.purchase) : 'No purchase (0 levels)';
  if(p.buyCount && node.id!=='luminoustracking') impact+='; +'+Number(((preview.purchase.factor/preview.current.factor-1)*100).toFixed(2))+'% relative source improvement';
  if(p.buyCount && node.id==='conduction') impact+='; actual extra per cast: Gale +'+(preview.purchase.casts.gale.shards-preview.current.casts.gale.shards).toLocaleString('en-US')+' Shards, Thorn +'+(preview.purchase.casts.thorn.lumen-preview.current.casts.thorn.lumen).toLocaleString('en-US')+' Lumen';
  return 'Current: '+researchEffectText(node,preview.current)+'\nNext: '+(preview.next?researchEffectText(node,preview.next)+' (preview only)':'Maxed')+
    '\nPurchase impact: '+p.buyCount+' level(s) · '+impact+
    (node.id==='luminoustracking'?'\nExisting enemy unchanged; purchases do not reroll it.':'');
}
function updateResearchCard(node,card){
  var model=researchPreview(node),p=model.plan,btn=card.querySelector('[data-research]');
  var preview=card.querySelector('[data-forge-preview]'),text=researchPreviewText(node,model);
  if(preview.textContent!==text) preview.textContent=text;
  var label=p.reason==='locked'?'Reach Rift '+node.unlockDepth:p.maxed?'Maxed':p.buyCount?'Upgrade ×'+p.buyCount:'Upgrade';
  var displayed=p.buyCount?p.cost:p.needed;
  var html=(node.lumenBase && Number.isFinite(displayed.lumen)?'<span class="cost mono">'+costIcon('lumen')+formatNum(displayed.lumen)+'</span>':'')+
    (node.shardBase && Number.isFinite(displayed.shard)?'<span class="cost mono">'+costIcon('shard')+formatNum(displayed.shard)+'</span>':'')+'<span class="label">'+label+'</span>';
  if(btn.dataset.planHtml!==html){btn.innerHTML=html;btn.dataset.planHtml=html;}
  btn.disabled=!p.affordable;
}

function buyResearch(node){
  var plan = getResearchBuyPlan(node);
  if(!plan.affordable || plan.buyCount<1) return;
  state.lumen -= plan.cost.lumen;
  state.shards -= plan.cost.shard;
  state.research[node.id] += plan.buyCount;
  trackDaily('research', plan.buyCount);
  saveState();
  renderResearch();
  updateBattleFast();
  renderSideStats();
}

function autoLabQueueTick(){
  var boughtAny = false;
  for(var guard=0; guard<20; guard++){
    var cheapest = null, cheapestCost = null, cheapestTotal = Infinity;
    RESEARCH.forEach(function(node){
      if(!state.researchQueue[node.id]) return;
      var plan = getResearchBuyPlan(node,1);
      if(!plan.affordable) return;
      var cost = plan.cost;
      var total = cost.lumen + cost.shard;
      if(state.lumen>=cost.lumen && state.shards>=cost.shard && total<cheapestTotal){
        cheapestTotal = total; cheapest = node; cheapestCost = cost;
      }
    });
    if(!cheapest) break;
    state.lumen -= cheapestCost.lumen;
    state.shards -= cheapestCost.shard;
    state.research[cheapest.id] += 1;
    trackDaily('research');
    boughtAny = true;
  }
  return boughtAny;
}

function studyEffectiveLevel(node,level){
  level=nonNegativeInt(level,0);
  return node.levelCap===undefined ? level : Math.min(level,node.levelCap);
}
function measuredInquiryReduction(){
  var node=LONG_STUDIES.find(function(n){return n.id==='measuredinquiry';});
  return 0.02*studyEffectiveLevel(node,longStudyLevel(node.id));
}
function studyDuration(node, level){
  var work=Math.round(node.baseDurationSec * Math.pow(node.durationGrowth, level));
  return LEGACY_STUDY_IDS.indexOf(node.id)===-1 ? work : Math.round(work*(1-measuredInquiryReduction()));
}
function studyCost(node, level){
  return {
    lumen: Math.round(node.lumenBase * Math.pow(node.lumenGrowth, level)),
    shard: Math.round(node.shardBase * Math.pow(node.shardGrowth, level))
  };
}
function unlockedLongStudies(){
  return LONG_STUDIES.filter(function(l){ return state.maxDepthEver >= (l.unlockDepth||1); });
}
function studySlotCount(){
  var n = unlockedLongStudies().filter(function(node){return LEGACY_STUDY_IDS.indexOf(node.id)!==-1;}).length;
  if(n<=2) return 1;
  if(n<=5) return 2;
  if(n===6) return 3;
  if(n===7) return 4;
  return 5;
}
function renderLabCapacityBadge(){
  var badge=els['lab-capacity-badge'];
  var btn=document.getElementById('nav-research');
  var free=Math.max(0,studySlotCount()-state.activeStudies.length);
  var text=String(free);
  if(badge.textContent!==text) badge.textContent=text;
  badge.hidden=free===0;
  var label='Lab — '+free+' Study slot'+(free===1?'':'s')+' available';
  if(btn.getAttribute('aria-label')!==label) btn.setAttribute('aria-label',label);
  var secondary=document.getElementById('workshop-lab-badge');
  secondary.textContent=text; secondary.hidden=badge.hidden;
  document.querySelector('.tab-btn[data-tab="workshop"]').setAttribute('aria-label','Workshop — Forge and '+label);
}
function findActiveStudy(id){
  return state.activeStudies.find(function(a){ return a.id===id; });
}
function getStudyStartPlan(node){
  node=node && LONG_STUDIES.find(function(n){return n.id===node.id;});
  if(!node) return {node:null,eligible:false,affordable:false,reason:'unknown'};
  var level=longStudyLevel(node.id),cost=studyCost(node,level),duration=studyDuration(node,level);
  var unlocked=state.maxDepthEver>=(node.unlockDepth||1);
  var maxed=node.levelCap!==undefined && level>=node.levelCap;
  var valid=Number.isFinite(cost.lumen) && cost.lumen>=0 && Number.isFinite(cost.shard) && cost.shard>=0 && Number.isFinite(duration) && duration>0;
  var reason=!unlocked ? 'locked' : maxed ? 'maxed' : findActiveStudy(node.id) ? 'active' : state.activeStudies.length>=studySlotCount() ? 'slots' : !valid ? 'unavailable' : '';
  var eligible=!reason;
  if(eligible && (state.lumen<cost.lumen || state.shards<cost.shard)) reason='unaffordable';
  return {node:node,level:level,cost:cost,duration:duration,unlocked:unlocked,maxed:maxed,eligible:eligible,affordable:!reason,reason:reason};
}
function commitStudyStart(node){
  var plan=getStudyStartPlan(node);
  if(!plan.affordable) return false;
  state.lumen-=plan.cost.lumen;
  state.shards-=plan.cost.shard;
  state.activeStudies.push({id:plan.node.id,remainingSec:plan.duration,totalDurationSec:plan.duration,speedMult:1});
  return true;
}
function startStudy(node){
  if(!commitStudyStart(node)) return false;
  saveState();
  renderLongStudies();
  updateBattleFast();
  return true;
}
function applySpeedTier(studyId, mult){
  var active = findActiveStudy(studyId);
  var node=LONG_STUDIES.find(function(n){return n.id===studyId;});
  if(!node || !active || active.remainingSec<=SIM_EPS || state.maxDepthEver<(node.unlockDepth||1) || LAB_SPEED_TIERS.indexOf(mult)===-1) return false;
  if(node.levelCap!==undefined && longStudyLevel(studyId)>=node.levelCap) return false;
  if(mult<=active.speedMult) return false;
  var cost = speedTierCost(mult);
  if(state.motes<cost) return false;
  state.motes -= cost;
  active.speedMult = mult;
  state.studySpeedTargets[studyId] = mult;
  saveState();
  renderLongStudies();
  renderHud();
  return true;
}
function studyMotesPlan(node){
  var active=findActiveStudy(node.id),target=state.studySpeedTargets[node.id];
  if(state.studyUseMotes[node.id]!==true || LAB_SPEED_TIERS.indexOf(target)===-1 || !active || active.remainingSec<=SIM_EPS || state.maxDepthEver<(node.unlockDepth||1) || (node.levelCap!==undefined && longStudyLevel(node.id)>=node.levelCap) || active.speedMult>=target) return null;
  return {active:active,target:target,cost:speedTierCost(target)};
}
// Closing paid overcap work is progress, but is never an earned completion.
function finishStudyRecord(index){
  var active=state.activeStudies[index];
  var node=LONG_STUDIES.find(function(n){return n.id===active.id;});
  var level=longStudyLevel(active.id);
  var earned=!!node && (node.levelCap===undefined || level<node.levelCap);
  if(earned) state.longStudyLevels[active.id]=level+1;
  state.activeStudies.splice(index,1);
  return {earned:earned,name:node ? node.name : active.id};
}
function advanceActiveStudies(elapsedSec){
  var completed = [];
  for(var i=state.activeStudies.length-1; i>=0; i--){
    var active = state.activeStudies[i];
    active.remainingSec -= elapsedSec * active.speedMult;
    if(active.remainingSec <= SIM_EPS){
      var result=finishStudyRecord(i);
      if(result.earned) completed.push(result.name);
    }
  }
  return completed;
}
function autoFillStudySlots(){
  advanceActiveStudies(0);
  var openSlots = studySlotCount() - state.activeStudies.length;
  if(openSlots<=0) return false;
  var candidates = LONG_STUDIES.filter(function(l){ return state.studyQueue[l.id] && getStudyStartPlan(l).eligible; });
  candidates.sort(function(a,b){
    var ca = studyCost(a, state.longStudyLevels[a.id]||0);
    var cb = studyCost(b, state.longStudyLevels[b.id]||0);
    return (ca.lumen+ca.shard) - (cb.lumen+cb.shard);
  });
  var started = false;
  for(var i=0; i<candidates.length && state.activeStudies.length<studySlotCount(); i++){
    var lnode = candidates[i];
    if(startStudy(lnode)) started=true;
  }
  return started;
}

function buyShopItem(item){
  if(state.owned[item.id]) return;
  if(state.comets < item.cost) return;
  state.comets -= item.cost;
  state.owned[item.id] = true;
  if(item.id==='autoascend'){
    state.autoAscendTargetDepth = Math.max(MIN_AUTO_ASCEND_RIFT, state.maxDepthEver||1, state.depth||1);
    state.autoAscendEnabled = true;
  }
  renderShop();
  saveState();
}

function toggleAutoAscend(){
  if(!state.owned.autoascend) return;
  state.autoAscendEnabled = !state.autoAscendEnabled;
  renderShop();
  saveState();
  if(state.autoAscendEnabled) checkAutoAscend();
}

function ascendFullPrismGainForCleared(cleared){
  cleared = Math.max(0,Math.floor(cleared||0));
  return cleared>=15 ? Math.max(1,Math.floor(2*Math.sqrt(cleared)*prismMult())) : 0;
}
function ascendPrismBreakdown(depth){
  var cleared = Math.max(0,(depth===undefined ? progressionDepth() : depth)-1);
  var full = ascendFullPrismGainForCleared(cleared);
  var benchmark = Math.max(0,Math.floor(state.ascendRewardedDepth||0));
  if(full<=0){
    return {gain:0,full:0,reserve:0,progressBonus:0,cleared:cleared,benchmark:benchmark};
  }
  if(benchmark<=0){
    return {gain:full,full:full,reserve:0,progressBonus:full,cleared:cleared,benchmark:0};
  }

  // A wall must remain a viable prestige path, but repeating the same shallow
  // reset cannot keep paying the full curve forever. Repeats retain 20% of the
  // current full reward (minimum 1 Prism). Pushing beyond the best previously
  // rewarded cleared Rift adds only the newly unlocked part of the same Prism
  // curve. No new currency/layer is introduced.
  var reserve = Math.max(1,Math.floor(full*ASCEND_REPEAT_REWARD_RATE));
  var benchmarkFull = ascendFullPrismGainForCleared(benchmark);
  var progressBonus = cleared>benchmark ? Math.max(0,full-benchmarkFull) : 0;
  var gain = Math.max(1,Math.min(full,reserve+progressBonus));
  return {
    gain:gain,
    full:full,
    reserve:reserve,
    progressBonus:progressBonus,
    cleared:cleared,
    benchmark:benchmark
  };
}
function ascendPrismGain(depth){
  return ascendPrismBreakdown(depth).gain;
}
function applyAscendMutation(){
  // Capture before reset/temporary party mutation; repeated Ascension keeps intent.
  state.formationRebuild = normalizeFormationRebuild(state.formationRebuild || {
    members:state.activeParty.slice(),preset:state.activeFormationPreset
  },state);
  var cleared = progressionDepth() - 1;
  var gain = ascendPrismGain(progressionDepth());
  state.prisms += gain;
  state.ascendRewardedDepth = Math.max(state.ascendRewardedDepth||0,cleared);
  state.ascendCount++;
  trackDaily('ascends');
  state.depth = 1;
  state.riftMode = 'push';
  state.farmDepth = 0;
  state.farmReturnDepth = 0;
  state.lumen = 0;
  state.maxDepthEver = Math.max(state.maxDepthEver, cleared+1);
  state.buffUntil = 0;
  state.buffMult = 1;
  state.supportBuffs = null;
  state.sigilResonanceUses = 0;
  state._autoTapAccum = 0;
  state._autoEmpowerAccum = 0;
  SPIRITS.forEach(function(sp){
    state.spirits[sp.id] = 0;
    state.heroResource[sp.id] = 0;
  });
  state.spirits['ember'] = 1;
  state.activeParty = ['ember'];
  reconcileFormationRebuild(state);
  spawnEnemy();
  return gain;
}
function showAscendFlash(gain,auto){
  var old = document.querySelector('.ascend-flash');
  if(old) old.remove();
  var flash = document.createElement('div');
  flash.className = 'ascend-flash';
  flash.innerHTML =
    '<span>'+(auto?'AUTO ASCEND':'ASCENDED')+'</span>'+
    '<strong>+'+formatNum(gain)+' PRISMS</strong>'+
    '<small>The Rift begins again. You do not.</small>';
  document.body.appendChild(flash);
  if(navigator.vibrate && !auto) navigator.vibrate([18,35,24]);
  setTimeout(function(){ flash.classList.add('leaving'); },1250);
  setTimeout(function(){ if(flash.parentNode) flash.remove(); },1700);
}
function doAscend(auto){
  var cleared = clearedProgressionRift();
  if(!ascendEligible()) return;
  var gain = applyAscendMutation();
  checkAchievements();
  renderAll();
  saveState();
  showAscendFlash(gain,auto);
}

function performReset(){
  if(resetInProgress) return;
  resetInProgress = true;

  try{
    localStorage.setItem(RESET_PENDING_KEY,'1');
    localStorage.removeItem(SAVE_KEY);
    localStorage.removeItem(RECOVERY_SAVE_KEY);
    localStorage.removeItem(STARTUP_INTRO_KEY);
  }catch(e){}

  pendingDailyReward = null;

  // Stop the old session from progressing visually while the reload begins.
  document.body.classList.add('app-paused');
  var settingsOverlay = document.getElementById('settings-overlay');
  if(settingsOverlay) settingsOverlay.style.display = 'none';

  setTimeout(function(){
    location.reload();
  },80);
}

function triggerAbility(sp, level){
  var burst = abilityRawBurst(sp,level);
  var rewards = abilityRewardPerCast(sp,level);
  if(rewards.shards>0) state.shards += rewards.shards;
  if(rewards.lumen>0) gainLumen(rewards.lumen);
  if(sp.abilityType==='support'){
    applySupportCast(sp,Date.now());
  }
  emitCombatVfx(sp.abilityType==='support' ? 'support' : 'ability',sp.color,sp.id);
  flashBattleStage(sp.abilityType==='support' ? 'support' : 'ability');
  if(burst>0) dealDamage(burst * formationContextDamageMult(state.depth) * bossAbilityDamageMult(state.depth));
}


// ---------------------------------------------------------------
// Rendering
// ---------------------------------------------------------------
var els = {};
function controlText(node){
  if(node.nodeType===3) return node.textContent;
  if(node.nodeType!==1) return '';
  if(node.classList.contains('cost-icon')) return node.getAttribute('aria-label') || '';
  return Array.from(node.childNodes).map(controlText).join(' ');
}
// Shared presentation states read existing eligibility; they never grant or deny purchases.
function presentControlStates(root){
  var toggles = ['empower-queue','queue','study-queue','study-use-motes','autoascend-toggle'];
  root.querySelectorAll('button').forEach(function(btn){
    btn.querySelectorAll('.control-state').forEach(function(label){label.remove();});
    var reason='', kind=btn.disabled?'unavailable':'available', subject='';
    var spId=btn.getAttribute('data-empower') || btn.getAttribute('data-rarity') || btn.getAttribute('data-module') || btn.getAttribute('data-ultimate') || btn.getAttribute('data-sigil-resonate') || btn.getAttribute('data-empower-queue') || btn.getAttribute('data-toggle');
    var sp=spId && SPIRITS.find(function(item){return item.id===spId;});
    if(sp) subject=sp.name;
    if(btn.hasAttribute('data-study')){
      var studyNode=LONG_STUDIES.find(function(n){return n.id===btn.getAttribute('data-study');});
      if(studyNode) subject=studyNode.name;
    }
    var queueAttr=toggles.find(function(attr){return btn.hasAttribute('data-'+attr);});
    if(queueAttr){
      var id=btn.getAttribute('data-'+queueAttr);
      var on=queueAttr==='empower-queue' ? state.empowerQueue[id]!==false : queueAttr==='queue' ? !!state.researchQueue[id] : queueAttr==='study-queue' ? !!state.studyQueue[id] : queueAttr==='study-use-motes' ? state.studyUseMotes[id]===true : !!state.autoAscendEnabled;
      btn.setAttribute('aria-pressed',String(on));
      if(queueAttr==='queue') subject=RESEARCH.find(function(n){return n.id===id;}).name;
      if(queueAttr==='study-queue' || queueAttr==='study-use-motes') subject=LONG_STUDIES.find(function(n){return n.id===id;}).name;
      if(queueAttr==='autoascend-toggle') subject='Auto-Ascend';
    }
    if(btn.hasAttribute('data-mult')){btn.setAttribute('aria-pressed',String(btn.classList.contains('active')));subject='Forge multiplier';}
    if(btn.hasAttribute('data-speed-study')){
      var study=findActiveStudy(btn.getAttribute('data-speed-study'));
      var mult=Number(btn.getAttribute('data-speed'));
      subject='Study speed';
      btn.setAttribute('aria-pressed',String(!!study && study.speedMult===mult));
      if(!study){btn.disabled=true;kind='completed';reason='Completed';}
      else if(study.speedMult>=mult) kind='completed';
      else if(LONG_STUDIES.some(function(n){return n.id===study.id && n.levelCap!==undefined && longStudyLevel(n.id)>=n.levelCap;})){kind='maxed';reason='Maxed';}
      else if(btn.disabled){kind='unaffordable';reason='';}
    }
    if(btn.hasAttribute('data-theme-select')) kind=btn.getAttribute('aria-pressed')==='true'?'selected':'available';
    if(btn.disabled && btn.matches('[data-empower],[data-rarity],[data-module],[data-ultimate],[data-sigil-resonate],[data-quest-refresh],[data-research],[data-node],[data-study],[data-shop]')){
      var cost={};kind='unaffordable';
      if(btn.hasAttribute('data-empower')) cost.lumen=spiritCost(sp);
      if(btn.hasAttribute('data-rarity')){
        var tier=state.heroRarity[sp.id]||0, level=state.spirits[sp.id]||0;
        if(tier>=5) kind='maxed';
        else if(!level || level<rarityReq(tier)){kind='locked';reason=!level?'Recruit first':'';}
        else cost=rarityCost(sp,tier);
      }
      if(btn.hasAttribute('data-module')) cost=moduleCost(sp,moduleLevel(sp.id));
      if(btn.hasAttribute('data-ultimate')) cost.sigil=ultimateSigilCost(sp);
      if(btn.hasAttribute('data-sigil-resonate')){
        cost.sigil=SIGIL_RESONANCE_COST;
        if((state.sigilResonanceUses||0)>=SIGIL_RESONANCE_RUN_LIMIT){kind='unavailable';reason='Run limit reached';}
        else if((state.spirits[sp.id]||0)<=0 || state.activeParty.indexOf(sp.id)===-1){kind='unavailable';reason='Field this Wisp first';}
        else if((state.heroResource[sp.id]||0)>=100){kind='unavailable';reason='Ability already ready';}
      }
      if(btn.hasAttribute('data-quest-refresh')){
        subject='Daily Quest Refresh';
        cost.comet=dailyQuestRefreshCost();
        if(!dailyQuestRefreshCandidates(btn.getAttribute('data-quest-refresh')).length){kind='unavailable';reason='No alternate quest';}
      }
      if(btn.hasAttribute('data-research')){var node=RESEARCH.find(function(n){return n.id===btn.getAttribute('data-research');});subject=node.name;var plan=getResearchBuyPlan(node);cost=plan.needed;
        if(plan.maxed){kind='maxed';reason='Maxed';}
        else if(!plan.unlocked){kind='locked';reason='Reach Rift '+node.unlockDepth;}}
      if(btn.hasAttribute('data-node')){var node=NODES.find(function(n){return n.id===btn.getAttribute('data-node');});subject=node.name;cost.prism=nodeCost(node);}
      if(btn.hasAttribute('data-study')){
        var node=LONG_STUDIES.find(function(n){return n.id===btn.getAttribute('data-study');});subject=node.name;
        var plan=getStudyStartPlan(node);
        if(plan.maxed){kind='maxed';reason='Maxed';}
        else if(!plan.unlocked){kind='locked';reason='Reach Rift '+node.unlockDepth;}
        else if(plan.reason==='slots'){kind='unavailable';reason='No open slots';}
        else if(plan.reason==='unavailable'){kind='unavailable';reason='Price or time unavailable';}
        else cost=plan.cost;
      }
      if(btn.hasAttribute('data-shop')){
        var item=SHOP.find(function(n){return n.id===btn.getAttribute('data-shop');});subject=item.name;
        if(state.owned[item.id]) kind='completed';else cost.comet=item.cost;
      }
      if(kind==='unaffordable') reason='';
    }
    if(btn.hasAttribute('data-quest-claim')){
      var id=btn.getAttribute('data-quest-claim');
      kind=state.questClaimed[id]?'completed':btn.disabled?'unavailable':'available';
      if(kind==='unavailable') reason='In progress';
    }
    btn.setAttribute('data-state',kind);
    if(reason && !btn.hasAttribute('data-empower') && btn.textContent.toLowerCase().indexOf(reason.toLowerCase())===-1){
      var label=document.createElement('span');label.className='control-state';label.textContent=reason;btn.appendChild(label);
    }
    var name=(subject?subject+' — ':'')+controlText(btn).replace(/\s+/g,' ').trim();
    if(btn.hasAttribute('data-empower') && reason) name+=' — '+reason;
    if(btn.getAttribute('aria-label')!==name) btn.setAttribute('aria-label',name);
  });
}

// Live UI updates must not strand keyboard focus on a detached button.
function replaceControlMarkup(root,html,keepAutoAscend){
  var focused=document.activeElement;
  var previous=root.contains(focused) ? focused : null;
  var keys=previous ? Array.from(previous.attributes).filter(function(a){return a.name.startsWith('data-') && a.name!=='data-state';}) : [];
  var index=previous ? Array.from(root.querySelectorAll('button,select')).indexOf(previous) : -1;
  var stable=keepAutoAscend && root.querySelector('[data-autoascend-card]');
  if(stable){
    // Keep the real native select attached while unrelated shop cards refresh.
    var prepared=document.createElement('div');prepared.innerHTML=html;
    var children=Array.from(prepared.children),nextCard=prepared.querySelector('[data-autoascend-card]');
    if(nextCard && children.indexOf(nextCard)===Array.from(root.children).indexOf(stable)){
      var toggle=stable.querySelector('[data-autoascend-toggle]'),nextToggle=nextCard.querySelector('[data-autoascend-toggle]');
      toggle.className=nextToggle.className;toggle.textContent=nextToggle.textContent;
      children.forEach(function(child,i){
        if(child===nextCard) return;
        if(root.children[i]) root.children[i].replaceWith(child);else root.appendChild(child);
      });
      while(root.children.length>children.length) root.lastElementChild.remove();
    } else root.innerHTML=html;
  } else root.innerHTML=html;
  presentControlStates(root);
  if(previous && !previous.isConnected){
    var buttons=Array.from(root.querySelectorAll('button,select'));
    var replacement=keys.length && buttons.find(function(btn){return keys.every(function(a){return btn.getAttribute(a.name)===a.value;});});
    if(replacement && !replacement.disabled) replacement.focus({preventScroll:true});
    else {
      var next=buttons.slice(Math.max(0,index)).concat(buttons.slice(0,Math.max(0,index))).find(function(btn){return !btn.disabled;});
      if(next) next.focus({preventScroll:true});
      else { root.tabIndex=-1;root.focus({preventScroll:true}); }
    }
  }
}

// Custom overlays share one focus lifecycle.
var overlayFocus = null;
function overlayVisible(el){ return el && el.style.display!=='none' && getComputedStyle(el).visibility!=='hidden' && el.getClientRects().length>0; }
function overlayControls(modal){
  return Array.from(modal.querySelectorAll('button:not(:disabled),input:not(:disabled),textarea:not(:disabled),select:not(:disabled),a[href],[tabindex="0"]')).filter(function(el){return el.getClientRects().length && getComputedStyle(el).visibility!=='hidden';});
}
function setOverlayInert(active){
  document.querySelector('.shell').inert=!!active;
  document.querySelectorAll('.overlay').forEach(function(el){el.inert=!!active && el!==active;});
}
function focusOverlay(){
  if(!overlayFocus || !overlayVisible(overlayFocus.el)) return;
  var controls=overlayControls(overlayFocus.modal);
  (controls[0] || overlayFocus.modal).focus({preventScroll:true});
}
function openOverlay(el,dismiss,opener){
  var modal=el.matches('[role="dialog"]') ? el : el.querySelector('[role="dialog"]');
  var trigger=opener || document.activeElement;
  if(overlayFocus && overlayFocus.el!==el) closeOverlay(overlayFocus.el);
  overlayFocus={el:el,modal:modal,dismiss:dismiss,trigger:trigger};
  el.style.display='flex';
  setOverlayInert(el);
  focusOverlay();
}
function closeOverlay(el){
  el.style.display='none';
  if(overlayFocus && overlayFocus.el===el){
    var trigger=overlayFocus.trigger;
    overlayFocus=null;
    setOverlayInert(null);
    if(!trigger || !trigger.isConnected || trigger===document.body || !trigger.getClientRects().length) trigger=document.querySelector('nav.tabbar .active');
    if(trigger) trigger.focus({preventScroll:true});
  }
}
function setupOverlayFocus(){
  document.addEventListener('focusin',function(e){
    if(overlayFocus && overlayVisible(overlayFocus.el) && !overlayFocus.modal.contains(e.target)) focusOverlay();
  });
  document.addEventListener('keydown',function(e){
    if(!overlayFocus || !overlayVisible(overlayFocus.el)) return;
    if(e.key==='Escape'){
      e.preventDefault();e.stopImmediatePropagation();overlayFocus.dismiss();return;
    }
    if(e.key==='Tab'){
      var controls=overlayControls(overlayFocus.modal), first=controls[0], last=controls[controls.length-1];
      if(!controls.length){e.preventDefault();focusOverlay();return;}
      if(e.shiftKey && (document.activeElement===first || !controls.includes(document.activeElement))){e.preventDefault();last.focus();}
      else if(!e.shiftKey && (document.activeElement===last || !controls.includes(document.activeElement))){e.preventDefault();first.focus();}
    }
  },true);
}

function cacheEls(){
  ['hud-lumen','hud-shard','hud-mote','hud-prism','hud-comet','hud-sigil','depth-label','rift-push-btn','rift-farm-btn','rift-objective','lab-capacity-badge','enemy-name','buff-indicator','enemy-stage','enemy-glyph',
   'hp-fill','hp-text','stat-tap','stat-idle','spirit-list','formation-presets','bond-card','bond-summary','rift-bond-effects','rift-party','boss-combat','research-list','study-list',
   'prism-preview','ascend-btn','ascend-note','node-list','ach-list','roster-journey','shop-list','theme-list','manifesto','toast',
   'daily-streak-badge','daily-quest-list','settings-overlay','settings-home','settings-encyclopedia','settings-title','settings-back','encyclopedia-content'
  ].forEach(function(id){ els[id]=document.getElementById(id); });
}

// Presentation only: the shared formatter can outgrow compact rows above its suffix range.
// Keep authoritative numeric values intact; compact display does not change calculations.
function formatRiftNumber(value){
  var text = formatNum(value);
  return value>=1e30 || text.length>10 ? Number(value).toExponential(2) : text;
}
function renderHud(){
  els['hud-lumen'].textContent = formatRiftNumber(state.lumen);
  els['hud-shard'].textContent = formatRiftNumber(state.shards);
  els['hud-mote'].textContent = formatRiftNumber(state.motes);
  els['hud-prism'].textContent = formatRiftNumber(state.prisms);
  els['hud-comet'].textContent = formatRiftNumber(state.comets);
  els['hud-sigil'].textContent = formatRiftNumber(state.sigils);
}

function renderRiftMode(){
  var farming = state.riftMode==='farm';
  els['rift-push-btn'].classList.toggle('active', !farming);
  els['rift-push-btn'].setAttribute('aria-pressed',String(!farming));
  els['rift-farm-btn'].setAttribute('aria-pressed',String(farming));
  els['rift-farm-btn'].classList.toggle('active', farming);
  els['rift-farm-btn'].disabled = !farming && !canFarmCurrentProgress();
  els['rift-farm-btn'].textContent = farming ? ('Farm Rift '+state.farmDepth) : (canFarmCurrentProgress() ? ('Farm Rift '+highestFarmableDepth(progressionDepth())) : 'Farm');
  els['rift-farm-btn'].setAttribute('data-state',els['rift-farm-btn'].disabled ? 'locked' : 'available');
  els['rift-farm-btn'].setAttribute('aria-label',els['rift-farm-btn'].disabled ? 'Farm unavailable — clear Rift 1 to unlock' : els['rift-farm-btn'].textContent);
  els['rift-farm-btn'].title = els['rift-farm-btn'].disabled ? 'Clear Rift 1 to unlock Farm' : '';
  if(els['rift-farm-btn'].disabled) els['rift-farm-btn'].innerHTML='Farm<span class="control-state">Clear Rift 1</span>';
  else els['rift-farm-btn'].innerHTML='Farm<span class="farm-depth">Rift '+formatRiftNumber(farming ? state.farmDepth : highestFarmableDepth(progressionDepth()))+'</span>';
}
function nextRiftObjective(){
  var p = progressionDepth();

  if(state.riftMode==='farm'){
    return {
      kind:'FARM',
      title:'Build power for Rift '+state.farmReturnDepth,
      detail:'Farming Rift '+state.farmDepth,
      progress:isBoss(state.farmReturnDepth)
        ? Math.min(100,Math.round(sustainedCombatDps(state.farmReturnDepth)/Math.max(1,enemyHpFor(state.farmReturnDepth)*bossRegenRate(state.farmReturnDepth))*100))
        : 0
    };
  }

  var recruitReady = SPIRITS.find(function(sp){
    return state.maxDepthEver>=sp.unlockDepth && (state.spirits[sp.id]||0)<=0 && state.lumen>=spiritCost(sp);
  });
  if(recruitReady){
    return {
      kind:'WISP READY',
      title:'Recruit '+recruitReady.shortName,
      detail:recruitReady.heroClass+' · '+recruitReady.role,
      progress:100,
      tab:'spirits'
    };
  }

  if(isBoss(state.depth)){
    var trait = bossTraitFor(state.depth);
    return {
      kind:'BOSS',
      title:'Defeat Rift '+state.depth,
      detail:trait ? trait.name : 'Boss encounter',
      progress:100
    };
  }

  if(state.ascendCount===0 && p>=16){
    return {
      kind:'ASCEND READY',
      title:'Permanent power is waiting',
      detail:'+'+ascendPrismGain(p)+' Prisms now',
      progress:100,
      tab:'ascend'
    };
  }

  var candidates = [];
  if(state.ascendCount===0 && p<16){
    candidates.push({depth:16,kind:'ASCEND',title:'Unlock Ascend',detail:'Clear Rift 15'});
  }
  SPIRITS.forEach(function(sp){
    if(sp.unlockDepth>p) candidates.push({depth:sp.unlockDepth,kind:'WISP',title:'Awaken '+sp.shortName,detail:sp.heroClass+' · Rift '+sp.unlockDepth});
  });

  var nextBoss = Math.ceil((p+1)/10)*10;
  candidates.push({depth:nextBoss,kind:'BOSS',title:'Reach Rift '+nextBoss,detail:(bossTraitFor(nextBoss)||{}).name||'Boss'});

  var nextRegionDepth = (Math.floor((p-1)/RIFT_ZONE_SPAN)+1)*RIFT_ZONE_SPAN+1;
  var nextZone = riftZoneFor(nextRegionDepth);
  candidates.push({depth:nextRegionDepth,kind:'REGION',title:'Enter '+nextZone.name,detail:'Rift '+nextRegionDepth});

  candidates.sort(function(a,b){
    if(a.depth!==b.depth) return a.depth-b.depth;
    var order={ASCEND:0,WISP:1,BOSS:2,REGION:3};
    var aOrder = order[a.kind]!==undefined ? order[a.kind] : 9;
    var bOrder = order[b.kind]!==undefined ? order[b.kind] : 9;
    return aOrder-bOrder;
  });

  var goal = candidates[0];
  var previousBoss = Math.floor((p-1)/10)*10;
  goal.progress = Math.max(0,Math.min(100,Math.round((p-previousBoss)/10*100)));
  return goal;
}
function renderRiftGuidancePreference(){
  var row=document.getElementById('rift-objective-row');
  if(row) row.hidden=riftGuidanceHidden;
  var toggle=document.getElementById('rift-guidance-toggle');
  if(toggle){
    toggle.setAttribute('aria-pressed',String(!riftGuidanceHidden));
    toggle.querySelector('.rift-guidance-value').textContent=riftGuidanceHidden ? 'Hidden' : 'Shown';
  }
}
function setRiftGuidanceHidden(hidden){
  var row=document.getElementById('rift-objective-row');
  var returnFocus=hidden && row && row.contains(document.activeElement);
  riftGuidanceHidden=!!hidden;
  // Device presentation preference; never changes the canonical game save.
  try{
    if(riftGuidanceHidden) localStorage.setItem(RIFT_GUIDANCE_HIDDEN_KEY,'1');
    else localStorage.removeItem(RIFT_GUIDANCE_HIDDEN_KEY);
  }catch(e){}
  renderRiftGuidancePreference();
  if(returnFocus) els['enemy-stage'].focus({preventScroll:true});
}
function renderRiftObjective(){
  var el = els['rift-objective'];
  if(!el) return;
  renderRiftGuidancePreference();
  var goal = nextRiftObjective();
  el.style.setProperty('--objective-progress',(goal.progress||0)+'%');
  var actionable = !!goal.tab;
  el.innerHTML =
    '<span class="objective-kind">'+goal.kind+'</span>'+
    '<span class="objective-copy"><strong>'+goal.title+'</strong><small>'+goal.detail+'</small></span>'+
    '<span class="objective-arrow">'+(actionable?'›':'')+'</span>';
  el.className = 'rift-objective objective-'+goal.kind.toLowerCase().replace(/[^a-z]+/g,'-')+(actionable?' actionable':'');
  el.setAttribute('data-target-tab',goal.tab||'');
  if(actionable){ el.setAttribute('role','button'); el.tabIndex=0; el.setAttribute('aria-label',goal.title+' — '+goal.detail); }
  else { el.removeAttribute('role'); el.removeAttribute('tabindex'); el.removeAttribute('aria-label'); }
}

function updateBattleFast(){
  renderRiftMode();
  renderRiftObjective();
  renderBondSummary();
  renderRiftParty();
  renderLabCapacityBadge();
  els['hp-fill'].style.width = Math.max(0, (state.enemyHp/state.enemyMaxHp*100)) + '%';
  els['hp-text'].textContent = formatRiftNumber(Math.max(0,state.enemyHp)) + ' / ' + formatRiftNumber(state.enemyMaxHp);
  var zone = riftZoneFor(state.depth);
  applyRiftZoneVisual(state.depth);
  els['depth-label'].innerHTML = 'Rift ' + state.depth + (isBoss(state.depth) ? ' &mdash; <span class="boss-tag">BOSS</span>' : '') + '<span class="region-label" style="color:'+zone.accent+'">'+zone.name+'</span>';
  els['enemy-name'].textContent = (state.enemyIsLuminous ? 'Luminous ' : '') + enemyNameFor(state.depth);
  var creatureKind = ENEMY_NOUN[(state.depth*7) % ENEMY_NOUN.length].toLowerCase();
  var creatureEl = els['enemy-glyph'];
  if(creatureEl.getAttribute('data-creature')!==creatureKind){
    creatureEl.setAttribute('data-creature',creatureKind);
    creatureEl.querySelector('.creature-art use').setAttribute('href','#creature-'+creatureKind);
  }
  els['enemy-glyph'].classList.toggle('boss', isBoss(state.depth));
  els['enemy-glyph'].classList.toggle('luminous', !!state.enemyIsLuminous);
  var bossNow = isBoss(state.depth);
  var battleStage = document.querySelector('#tab-battle .stage');
  var trait = bossNow ? bossTraitFor(state.depth) : null;
  ['trait-regrowth','trait-fractured','trait-guardian','boss-ready','boss-wall'].forEach(function(cls){
    els['enemy-stage'].classList.remove(cls);
    if(battleStage) battleStage.classList.remove(cls);
  });
  if(trait){
    els['enemy-stage'].classList.add('trait-'+trait.id);
    if(battleStage) battleStage.classList.add('trait-'+trait.id);
  }
  els['boss-combat'].hidden=!bossNow;
  if(bossNow){
    var regenPerSec = state.enemyMaxHp*bossRegenRate(state.depth);
    var yourDps = sustainedCombatDps(state.depth);
    var netDps = yourDps - regenPerSec;
    var enough = netDps > 0;
    var bossStatus=els['boss-combat'];
    bossStatus.setAttribute('data-regen',String(regenPerSec));
    bossStatus.setAttribute('data-dps',String(yourDps));
    bossStatus.setAttribute('data-net',String(netDps));
    var bossText='<strong>Regen +'+formatRiftNumber(regenPerSec)+' HP/s</strong><span class="boss-net '+(enough?'positive':'negative')+'">Auto DPS ≈ '+formatRiftNumber(yourDps)+' · Net '+(netDps>0?'+':netDps<0?'−':'')+formatRiftNumber(Math.abs(netDps))+'/s</span>';
    if(bossStatus.innerHTML!==bossText)bossStatus.innerHTML=bossText;
    bossStatus.setAttribute('aria-label','Boss regeneration '+regenPerSec+' HP per second. Estimated sustained damage '+yourDps+' per second, including abilities and Auto-Tap, excluding manual taps. Net '+netDps+' HP per second. Burst timing can change the result.');
    els['enemy-stage'].classList.add(enough ? 'boss-ready' : 'boss-wall');
    if(battleStage) battleStage.classList.add(enough ? 'boss-ready' : 'boss-wall');
  }

  els['stat-tap'].textContent = formatRiftNumber(tapDamage());
  els['stat-idle'].textContent = formatRiftNumber(sustainedWispDps(state.depth));
  var buffNow = Date.now();
  var buffFactor = simulationBuffMult(buffNow);
  var buffText = 'Boost · passive Wisps + Tap · <strong>Inactive</strong>';
  if(buffFactor>1){
    var pct = Math.round((buffFactor-1)*100);
    var secLeft = Math.max(0, Math.ceil(simulationNextBuffSeconds(buffNow)));
    var expiryLabel = state.supportBuffs ? 'next expiry ' : '';
    buffText = 'Boost · passive Wisps + Tap · <strong>+'+pct+'% · '+expiryLabel+secLeft+'s</strong>';
  }
  if(els['buff-indicator'].innerHTML!==buffText) els['buff-indicator'].innerHTML=buffText;
  els['buff-indicator'].classList.toggle('is-active',buffFactor>1);
  renderHud();
}


function spawnFloatNum(text, stageEl, tone){
  var span = document.createElement('span');
  span.className = 'float-num'+(tone ? ' float-'+tone : '');
  span.textContent = text;
  span.style.left = (40 + Math.random()*20) + '%';
  stageEl.appendChild(span);
  setTimeout(function(){ span.remove(); }, 720);
}

function showToast(msg){
  var t = els['toast'];
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(showToast._t);
  showToast._t = setTimeout(function(){ t.classList.remove('show'); }, 2200);
}

var TUTORIAL_STEPS = [
  {title:'Fight & grow', body:'Wisps fight automatically. Tap the Rift as your Guardian for extra damage, then spend Lumen to Empower the Wisps you want in your Active party.'},
  {title:'Build for the wall', body:'Formation Bonds reward different Wisp pairs for Push, Farm and Boss fights. If a Boss stops you, Farm your best cleared Rift and return stronger.'},
  {title:'Ascend forever', body:'After enough progress you can Ascend for Prisms. Wisp Rarity, Modules, Ultimates, Rift Forge upgrades, Research Lab progress and other permanent systems stay with you — even while offline.'}
];

function showTutorial(onComplete){
  var overlay = document.getElementById('tutorial-overlay');
  var dotsEl = document.getElementById('tut-dots');
  var titleEl = document.getElementById('tut-title');
  var bodyEl = document.getElementById('tut-body');
  var nextBtn = document.getElementById('tut-next');
  var skipBtn = document.getElementById('tut-skip');
  var step = 0;

  dotsEl.innerHTML = TUTORIAL_STEPS.map(function(){ return '<span class="tut-dot"></span>'; }).join('');
  var dots = dotsEl.querySelectorAll('.tut-dot');

  function renderStep(){
    var s = TUTORIAL_STEPS[step];
    titleEl.textContent = s.title;
    bodyEl.textContent = s.body;
    dots.forEach(function(d,i){ d.classList.toggle('on', i===step); });
    nextBtn.textContent = (step===TUTORIAL_STEPS.length-1) ? 'Start Playing' : 'Next';
  }

  function finish(){
    closeOverlay(overlay);
    nextBtn.removeEventListener('click', onNext);
    skipBtn.removeEventListener('click', finish);
    if(onComplete) onComplete();
  }

  function onNext(){
    if(step===TUTORIAL_STEPS.length-1){ finish(); return; }
    step++;
    renderStep();
  }

  nextBtn.addEventListener('click', onNext);
  skipBtn.addEventListener('click', finish);
  step = 0;
  renderStep();
  openOverlay(overlay,finish);
}

function renderBondSummary(){
  if(!els['bond-summary']) return;
  var active = activeFormationBonds();
  var summary = active.length
    ? 'Active Bonds: ' + active.map(function(b){return '<span style="color:'+BOND_VISUALS[b.id].color+'">'+b.name.replace(' Bond','')+'</span>';}).join(' · ')
    : 'No Formation Bond active.';
  if(els['bond-summary'].innerHTML!==summary) els['bond-summary'].innerHTML = summary;
  var effects=els['rift-bond-effects'];
  var html=active.map(function(b){
    var visual=BOND_VISUALS[b.id];
    return '<div class="rift-bond-effect" data-bond-effect="'+b.id+'" style="--bond-color:'+visual.color+'" aria-label="'+b.name+': '+b.effect+'"><span class="rift-bond-mark" aria-hidden="true">'+visual.mark+'</span><span class="rift-bond-copy">'+b.effect+'</span></div>';
  }).join('');
  if(effects.innerHTML!==html) effects.innerHTML=html;
  effects.hidden=!active.length;
}
// Read the same resource and fill rate used by the authoritative simulation.
// The DOM is retained between ticks; these observers never mutate save state.
function renderRiftParty(){
  var root=els['rift-party'];
  var bonds=activeFormationBonds(),byId={},ordered=[];
  // Group each powered Bond visually without changing simulation/save order.
  bonds.forEach(function(bond){
    state.activeParty.filter(function(id){return bond.ids.indexOf(id)!==-1;}).forEach(function(id){byId[id]=bond;ordered.push(id);});
  });
  state.activeParty.forEach(function(id){if(!byId[id])ordered.push(id);});
  var key=state.activeParty.join(',')+'|'+bonds.map(function(b){return b.id;}).join(',');
  if(root.getAttribute('data-party')!==key){
    root.setAttribute('data-party',key);
    root.innerHTML=ordered.map(function(id,index){
      var sp=SPIRITS.find(function(x){return x.id===id;}),bond=byId[id],visual=bond&&BOND_VISUALS[bond.id];
      var position=bond ? (byId[ordered[index+1]]===bond?' bond-start':' bond-end') : '';
      var marker=visual ? '<span class="rift-bond-mark" aria-hidden="true">'+visual.mark+'</span>' : '';
      return '<div class="rift-wisp'+position+'" data-rift-wisp="'+id+'"'+(bond?' data-bond="'+bond.id+'"':'')+' role="group" aria-label="'+sp.name+(bond?' — '+bond.name:'')+'" style="--wisp-color:'+sp.color+(visual?';--bond-color:'+visual.color:'')+'">'+wispPortrait(sp)+
        '<span class="rift-wisp-name">'+marker+sp.shortName+'</span><span class="rift-wisp-state"></span><span class="rift-wisp-power" title="Passive Wisp power"></span>'+
        '<div class="rift-charge" role="progressbar" aria-label="'+sp.name+' — '+sp.abilityName+'" aria-valuemin="0" aria-valuemax="100"><span></span></div></div>';
    }).join('');
  }
  state.activeParty.forEach(function(id){
    var card=root.querySelector('[data-rift-wisp="'+id+'"]'),bar=card.querySelector('.rift-charge');
    var powered=(state.spirits[id]||0)>0,charge=powered ? Math.max(0,Math.min(100,state.heroResource[id]||0)) : 0;
    var seconds=Math.max(0,(1-charge/100)*abilityCycleSeconds());
    var casting=powered && Date.now()<Number(card.getAttribute('data-cast-until')||0);
    var label=!powered ? 'Lv 0' : casting ? 'CAST' : charge>=100 ? 'Ready' : '';
    card.classList.toggle('unpowered',!powered);card.classList.toggle('is-casting',casting);
    card.classList.toggle('is-attacking',powered && Date.now()<Number(card.getAttribute('data-shot-until')||0));
    var status=card.querySelector('.rift-wisp-state');if(status.textContent!==label)status.textContent=label;
    var power=card.querySelector('.rift-wisp-power'),powerText=formatNum(chipEffectivePower(id));
    if(power.textContent!==powerText)power.textContent=powerText;
    power.setAttribute('aria-label','Passive Wisp power: '+powerText);
    bar.querySelector('span').style.width=charge+'%';
    bar.setAttribute('aria-valuenow',String(Math.round(charge)));
    bar.setAttribute('aria-valuetext',!powered ? 'Unpowered — Empower this Wisp' : Math.round(charge)+'% charged; '+Math.ceil(seconds)+' seconds to next ability');
  });
}
function renderFormationPresets(){
  var root=els['formation-presets'];
  if(!root) return;
  var activeName=FORMATION_PRESET_IDS.find(formationPresetIsActive);
  var html='<div class="card formation-preset-card">' +
    '<div class="formation-preset-head"><div class="formation-preset-title">Current Formation · '+state.activeParty.length+'/5</div>' +
    '<div class="formation-preset-state">'+(activeName ? FORMATION_PRESET_LABELS[activeName]+' active' : 'Custom formation')+'</div></div>' +
    '<div class="formation-lineup">'+state.activeParty.map(function(id){
      var sp=SPIRITS.find(function(item){return item.id===id;});
      return sp ? '<span class="formation-member">'+wispPortrait(sp)+sp.shortName+'</span>' : '';
    }).join('')+'</div>' +
    (state.formationRebuild ? '<div class="formation-rebuild-note"><strong>Rebuilding chosen Formation</strong><div>'+intendedFormationIds().map(function(id){
      var sp=SPIRITS.find(function(item){return item.id===id;});
      return sp.shortName+': '+((state.spirits[id]||0)>0 ? 'Active' : 'Pending — no power or Bonds'+(state.achieved.labmaster ? (state.empowerQueue[id]===false ? ' · Auto-Empower OFF' : ' · Auto-Empower ON') : ' · Recruit manually'));
    }).join('<br>')+'</div>'+(!intendedFormationIds().includes('ember') && state.activeParty.includes('ember') ? '<div>Ember: temporary startup support</div>' : '')+'</div>' : '')+
    '<div class="formation-preset-grid">';
  FORMATION_PRESET_IDS.forEach(function(name){
    var members=formationPresetMembers(name);
    var unavailable=formationPresetUnavailable(name);
    var active=formationPresetIsActive(name);
    var detail=unavailable.length ? 'Needs '+unavailable.length+' Wisp'+(unavailable.length===1?'':'s') : members.length+'/5 Wisps';
    html += '<div class="formation-preset-slot">' +
      '<button class="formation-preset-btn'+(active?' active':'')+'" data-formation-preset="'+name+'" aria-pressed="'+active+'" '+(unavailable.length||!members.length?'disabled':'')+'>'+FORMATION_PRESET_LABELS[name]+'<span>'+(active?'Active · ':'')+detail+'</span></button>' +
      '<button class="formation-save-btn" data-save-formation="'+name+'" aria-label="Save current formation as '+FORMATION_PRESET_LABELS[name]+'">Save '+FORMATION_PRESET_LABELS[name]+'</button>' +
    '</div>';
  });
  html += '</div>';
  if(state.achieved.labmaster){
    var global=autoEmpowerAllState();
    var pressed=global.value==='mixed' ? 'mixed' : String(global.value==='on');
    html += '<button class="auto-empower-all" data-empower-all aria-pressed="'+pressed+'">Auto-Empower All: '+global.value.toUpperCase()+'</button>';
  }
  html += '</div>';
  replaceControlMarkup(root,html);
  root.querySelectorAll('[data-formation-preset]').forEach(function(btn){
    btn.addEventListener('click',function(){applyFormationPreset(btn.getAttribute('data-formation-preset'));});
  });
  root.querySelectorAll('[data-save-formation]').forEach(function(btn){
    btn.addEventListener('click',function(){saveFormationPreset(btn.getAttribute('data-save-formation'));});
  });
  var all=root.querySelector('[data-empower-all]');
  if(all) all.addEventListener('click',function(){setAutoEmpowerAll(autoEmpowerAllState().value!=='on');});
}
function renderFormationBonds(){
  renderFormationPresets();
  if(els['bond-card']){
    var focus = currentFormationFocus();
    var rows = FORMATION_BONDS.map(function(bond){
      var active = bondActive(bond.id);
      var recommended = focus.bonds.indexOf(bond.id)!==-1;
      return '<div class="bond-row '+(active?'active':'')+'">' +
        '<span class="bond-dot"></span>' +
        '<div class="bond-main"><div class="bond-name">'+bond.name+' · '+bond.tag+(recommended?' · Best now':'')+'</div><div class="bond-req">'+bond.req+'</div></div>' +
        '<div class="bond-effect">'+bond.effect+'</div>' +
      '</div>';
    }).join('');
    els['bond-card'].innerHTML =
      '<div class="bond-title">Formation Bonds</div>' +
      '<div class="bond-help"><strong>'+formationRecommendationText()+'</strong>. Both Wisps in a Bond must be Active and above Lv.0. You only have 5 slots, so builds naturally trade one bonus for another.</div>' +
      '<div class="bond-list">'+rows+'</div>';
  }
  renderBondSummary();
}

function wispPortrait(sp){
  return '<svg class="wisp-portrait" viewBox="0 0 64 64" style="--wisp-color:'+sp.color+'" aria-hidden="true"><use href="#wisp-'+sp.id+'"/></svg>';
}


function renderRosterJourney(){
  var el = els['roster-journey'];
  if(!el) return;
  var recruited = SPIRITS.filter(function(sp){ return (state.spirits[sp.id]||0)>0; }).length;
  var ready = SPIRITS.find(function(sp){ return state.maxDepthEver>=sp.unlockDepth && (state.spirits[sp.id]||0)<=0; });
  var next = SPIRITS.find(function(sp){ return state.maxDepthEver<sp.unlockDepth; });
  var pct = Math.round(recruited/SPIRITS.length*100);
  var target = ready
    ? (state.lumen>=spiritCost(ready)
      ? '<strong>'+ready.name+' is ready to recruit</strong><small>'+ready.heroClass+' · '+ready.role+'</small>'
      : '<strong>'+ready.name+' has awakened</strong><small>'+formatNum(spiritCost(ready))+' Lumen to recruit · '+ready.heroClass+'</small>')
    : (next
      ? '<strong>Next Wisp: '+next.name+'</strong><small>Reach Rift '+next.unlockDepth+' · '+next.heroClass+'</small>'
      : '<strong>Every Wisp awakened</strong><small>Build your strongest 5-Wisp formation</small>');
  el.style.setProperty('--roster-progress',pct+'%');
  el.innerHTML =
    '<span class="roster-count mono">'+recruited+'/'+SPIRITS.length+'</span>'+
    '<span class="roster-copy">'+target+'</span>'+
    '<span class="roster-label">ROSTER</span>';
}
function pulseWispCard(id,tone){
  var card = els['spirit-list'] && els['spirit-list'].querySelector('[data-wisp-card="'+id+'"]');
  if(!card) return;
  var cls = 'wisp-reward-'+(tone||'power');
  card.classList.add(cls);
  setTimeout(function(){ card.classList.remove(cls); },720);
}

function renderSpirits(){
  var openProgression=Array.from(els['spirit-list'].querySelectorAll('details[open]')).map(function(el){return el.dataset.wispProgression;});
  var focusedProgression=document.activeElement && document.activeElement.dataset.wispDetails;
  renderFormationBonds();
  renderRosterJourney();
  var html = '';
  // Sort a presentation-only copy; simulation and saved party order are unchanged.
  var roster=SPIRITS.slice().sort(function(a,b){
    return Number(state.activeParty.indexOf(b.id)!==-1)-Number(state.activeParty.indexOf(a.id)!==-1);
  });
  var previousGroup='';
  roster.forEach(function(sp){
    var group=state.activeParty.indexOf(sp.id)!==-1 ? 'Active Wisps' : 'Reserve & recruitment';
    if(group!==previousGroup){html+='<div class="roster-group-label">'+group+'</div>';previousGroup=group;}
    var level = state.spirits[sp.id];
    var unlocked = state.maxDepthEver >= sp.unlockDepth;
    if(!unlocked){
      html += '<div class="card hero-card locked" data-state="locked" aria-disabled="true" data-wisp-card="'+sp.id+'">' +
        '<div class="hero-top">'+
          wispPortrait(sp) +
          '<div class="hero-id"><div class="name">???</div><div class="class-tag lock-note">Unlocks at Rift '+sp.unlockDepth+'</div></div>' +
        '</div></div>';
      return;
    }
    var recruited = level>0;
    var tier = state.heroRarity[sp.id]||0;
    var power = wispPower(sp,level);
    var cost = spiritCost(sp);
    var active = state.activeParty.indexOf(sp.id)!==-1;
    var req = rarityReq(tier);
    var rc = rarityCost(sp, tier);
    var canRarity = recruited && tier<5 && level>=req && state.shards>=rc.shard && state.lumen>=rc.lumen;
    var rarityLabel = tier>=5 ? 'Maxed' : (level<req ? ('Lv.'+req+' req') :
      ('<span style="font-size:.6875rem;">Rarity Up</span>' +
       '<span style="font-size:.6875rem;">'+costIcon('lumen')+formatNum(rc.lumen)+'</span>' +
       '<span style="font-size:.6875rem;">'+costIcon('shard')+formatNum(rc.shard)+'</span>'));
    var modInfo = MODULE_INFO[sp.abilityType];
    var modLvl = moduleLevel(sp.id);
    var modMaxed = modLvl>=MODULE_MAX_LEVEL;
    var modCost = moduleCost(sp, modLvl);
    var canModule = !modMaxed && state.lumen>=modCost.lumen && state.shards>=modCost.shard;
    var moduleHtml = !recruited ? '' :
      '<div class="module-row">' +
        '<div class="module-name">'+modInfo.name+' <span style="color:var(--shard);">Lv.'+modLvl+'/'+MODULE_MAX_LEVEL+(modMaxed?' · Maxed':'')+'</span></div>' +
        '<div class="module-effect">'+modInfo.effect(modLvl)+'</div>' +
        (modMaxed ? '' :
          '<button class="mini-btn" data-module="'+sp.id+'" '+(canModule?'':'disabled')+'>Upgrade Module' +
            '<span style="font-size:.6875rem;">'+costIcon('lumen')+formatNum(modCost.lumen)+'</span>' +
            '<span style="font-size:.6875rem;">'+costIcon('shard')+formatNum(modCost.shard)+'</span>' +
          '</button>') +
      '</div>';
    var ultCost = ultimateSigilCost(sp);
    var resonanceOwned = allUltimatesOwned();
    var resonanceUses = state.sigilResonanceUses||0;
    var resonanceDisabled = !canSigilResonate(sp);
    var resonanceHtml = resonanceOwned && ultimateUnlocked(sp.id) ?
      '<button class="mini-btn sigil-resonance-btn" data-sigil-resonate="'+sp.id+'" '+(resonanceDisabled?'disabled':'')+'>Resonate '+resonanceUses+'/'+SIGIL_RESONANCE_RUN_LIMIT+
        '<span style="font-size:.6875rem;">'+costIcon('sigil')+SIGIL_RESONANCE_COST+'</span></button>' : '';
    var ultimateHtml = tier<5 ? '' :
      '<div class="ultimate-row">' +
        (ultimateUnlocked(sp.id) ?
          '<div class="ultimate-badge">Ultimate Unlocked — '+ultimateEffectText(sp)+'</div>'+resonanceHtml :
          '<button class="mini-btn ultimate-btn" data-ultimate="'+sp.id+'" '+(state.sigils<ultCost?'disabled':'')+'>Unlock Ultimate<span style="font-size:.6875rem;">'+costIcon('sigil')+ultCost+'</span></button>') +
      '</div>';
    var empowerOn = state.empowerQueue[sp.id]!==false;
    var pendingRebuild = intendedFormationIds().indexOf(sp.id)!==-1 && !recruited;
    var empowerHtml = ((recruited || pendingRebuild) && state.achieved.labmaster) ?
      ' <button class="node-queue-toggle '+(empowerOn?'active':'')+'" data-empower-queue="'+sp.id+'">Auto-Empower '+(empowerOn?'ON':'OFF')+'</button>' : '';
    html += '<div class="card hero-card rarity-'+tier+(pendingRebuild?' pending-rebuild':'')+(active?' active-wisp':'')+(ultimateUnlocked(sp.id)?' has-ultimate':'')+'" data-wisp-card="'+sp.id+'" style="--wisp-color:'+sp.color+';--rarity-color:'+RARITY_COLORS[tier]+';">' +
      '<div class="hero-top">'+
        wispPortrait(sp) +
        '<div class="hero-id">' +
          '<div class="name">'+sp.name+'</div>' +
          '<div class="class-tag" style="color:'+sp.color+'">'+sp.heroClass+' &middot; '+sp.role+'</div>' +
        '</div>' +
        (recruited ? '<button class="active-toggle '+(active?'is-active':'')+'" data-toggle="'+sp.id+'" aria-pressed="'+(active?'true':'false')+'">'+(active?'Bench':'Field')+'</button>' : '') +
      '</div>' +
      (pendingRebuild ? '<div class="formation-rebuild-note">Chosen Formation · Pending · No power or Bonds</div>' : '') +
      '<div class="hero-stats">' +
        '<span class="hero-stat-pill">Lv. '+level+'</span>' +
        '<span class="hero-stat-pill mono">'+formatNum(power)+' Wisp Power</span>' +
        '<span class="rarity-badge" style="--badge-color:'+RARITY_COLORS[tier]+';">'+RARITY_NAMES[tier]+'</span>' +
        empowerHtml +
      '</div>' +
      '<button class="mini-btn wisp-empower-action" data-empower="'+sp.id+'" '+(state.lumen<cost?'disabled':'')+'><strong>'+(recruited?'Empower':'Recruit')+'</strong><span class="mono">'+costIcon('lumen')+formatNum(cost)+'</span></button>' +
      '<details class="wisp-progression" data-wisp-progression="'+sp.id+'" '+(openProgression.indexOf(sp.id)!==-1?'open':'')+'><summary data-wisp-details="'+sp.id+'">'+sp.shortName+' · Ability, Rarity, Module &amp; Ultimate</summary>' +
      '<div class="hero-ability"><span class="ability-label">Ability</span><strong>'+sp.abilityName+'</strong><span class="ability-desc">'+ABILITY_DESC[sp.abilityType]+'</span></div>' +
      moduleHtml +
      '<div class="hero-actions">' +
        '<button class="mini-btn rarity-btn" data-rarity="'+sp.id+'" '+(canRarity?'':'disabled')+'>'+rarityLabel+'</button>' +
      '</div>' +
      ultimateHtml +
    '</details></div>';
  });
  replaceControlMarkup(els['spirit-list'],html);
  if(focusedProgression){
    var restoredSummary=els['spirit-list'].querySelector('[data-wisp-details="'+focusedProgression+'"]');
    if(restoredSummary) restoredSummary.focus({preventScroll:true});
  }
  els['spirit-list'].querySelectorAll('[data-empower]').forEach(function(btn){
    btn.addEventListener('click', function(){
      var sp = SPIRITS.find(function(s){ return s.id===btn.getAttribute('data-empower'); });
      buySpirit(sp);
    });
  });
  els['spirit-list'].querySelectorAll('[data-rarity]').forEach(function(btn){
    btn.addEventListener('click', function(){
      var sp = SPIRITS.find(function(s){ return s.id===btn.getAttribute('data-rarity'); });
      buyRarity(sp);
    });
  });
  els['spirit-list'].querySelectorAll('[data-toggle]').forEach(function(btn){
    btn.addEventListener('click', function(){ toggleActive(btn.getAttribute('data-toggle')); });
  });
  els['spirit-list'].querySelectorAll('[data-module]').forEach(function(btn){
    btn.addEventListener('click', function(){
      var sp = SPIRITS.find(function(s){ return s.id===btn.getAttribute('data-module'); });
      buyModule(sp);
    });
  });
  els['spirit-list'].querySelectorAll('[data-ultimate]').forEach(function(btn){
    btn.addEventListener('click', function(){
      var sp = SPIRITS.find(function(s){ return s.id===btn.getAttribute('data-ultimate'); });
      buyUltimate(sp);
    });
  });
  els['spirit-list'].querySelectorAll('[data-sigil-resonate]').forEach(function(btn){
    btn.addEventListener('click', function(){
      var sp = SPIRITS.find(function(s){ return s.id===btn.getAttribute('data-sigil-resonate'); });
      useSigilResonance(sp);
    });
  });
  els['spirit-list'].querySelectorAll('[data-empower-queue]').forEach(function(btn){
    btn.addEventListener('click', function(e){
      e.stopPropagation();
      var id = btn.getAttribute('data-empower-queue');
      state.empowerQueue[id] = state.empowerQueue[id]===false ? true : false;
      saveState();
      renderSpirits();
    });
  });
}

function renderResearch(){
  var multHtml = '<div class="section-sub" style="margin:0 2px 10px;">Queue ON buys the next affordable level automatically.</div>' +
    '<div class="mult-row" id="mult-row">' + MULT_OPTIONS.map(function(m){
    var label = m==='max' ? 'Max' : m+'x';
    var active = labMultiplier===m;
    return '<button class="mult-btn '+(active?'active':'')+'" data-mult="'+m+'">'+label+'</button>';
  }).join('') + '</div>';

  var html = '';
  RESEARCH.forEach(function(node){
    var level = state.research[node.id];
    var queueOn = !!state.researchQueue[node.id];
    html += '<div class="card node-card" data-forge-card="'+node.id+'">' +
      '<div class="forge-head"><svg class="upgrade-emblem" viewBox="0 0 32 38" aria-hidden="true" focusable="false"><use href="#upgrade-forge"/></svg>' +
        '<div class="node-info"><div class="name">'+node.name+'</div>' +
          '<div class="lvl">Level '+level+(node.levelCap===undefined?' · No level cap':' / '+node.levelCap)+'</div></div></div>' +
      '<div class="desc forge-description">'+node.desc+'</div>' +
      '<div class="desc" data-forge-preview></div>' +
      '<div class="forge-actions"><button class="node-queue-toggle '+(queueOn?'active':'')+'" data-queue="'+node.id+'">Queue '+(queueOn?'ON':'OFF')+'</button>' +
        '<button class="buy-btn" data-research="'+node.id+'"></button></div>' +
    '</div>';
  });
  var root=els['research-list'],main=document.querySelector('main');
  var focused=root.contains(document.activeElement) ? document.activeElement : null;
  var focusAttr=focused && ['data-mult','data-research','data-queue'].find(function(attr){return focused.hasAttribute(attr);});
  var focusId=focusAttr && focused.getAttribute(focusAttr);
  var scrollTop=main.scrollTop;
  // Build the authoritative previews and control states off-DOM. Restoring
  // focus on empty cards would clamp the scroll area before they reach full size.
  var prepared=document.createElement('div');
  prepared.innerHTML=multHtml + html;
  RESEARCH.forEach(function(node){updateResearchCard(node,prepared.querySelector('[data-forge-card="'+node.id+'"]'));});
  presentControlStates(prepared);
  replaceControlMarkup(root,prepared.innerHTML);
  main.scrollTop=scrollTop;
  if(focusAttr){
    var target=root.querySelector('['+focusAttr+'="'+focusId+'"]');
    // A completed/unaffordable purchase falls back to this upgrade's Queue,
    // rather than sending keyboard focus to a bulk control at the list's top.
    if(target && target.disabled) target=root.querySelector('[data-queue="'+focusId+'"]');
    if(target){
      target.focus({preventScroll:true});
      var rect=target.getBoundingClientRect(),viewport=main.getBoundingClientRect();
      var bottom=Math.min(viewport.bottom,document.querySelector('nav.tabbar').getBoundingClientRect().top);
      if(rect.top<viewport.top) main.scrollTop+=Math.floor(rect.top-viewport.top);
      else if(rect.bottom>bottom) main.scrollTop+=Math.ceil(rect.bottom-bottom);
    }
  }
  els['research-list'].querySelectorAll('[data-mult]').forEach(function(btn){
    btn.addEventListener('click', function(){
      var v = btn.getAttribute('data-mult');
      labMultiplier = v==='max' ? 'max' : parseInt(v,10);
      if(state.owned.rememberbulk){ state.savedLabMultiplier = labMultiplier; }
      renderResearch();
    });
  });
  els['research-list'].querySelectorAll('[data-research]').forEach(function(btn){
    btn.addEventListener('click', function(){
      var node = RESEARCH.find(function(n){ return n.id===btn.getAttribute('data-research'); });
      buyResearch(node);
    });
  });
  els['research-list'].querySelectorAll('[data-queue]').forEach(function(btn){
    btn.addEventListener('click', function(e){
      e.stopPropagation();
      var id = btn.getAttribute('data-queue');
      state.researchQueue[id] = !state.researchQueue[id];
      saveState();
      renderResearch();
    });
  });
}

function studyMotesMarkup(node){
  var on=state.studyUseMotes[node.id]===true,target=state.studySpeedTargets[node.id];
  return '<div class="study-motes-controls"><button class="node-queue-toggle '+(on?'active':'')+'" data-study-use-motes="'+node.id+'">Use Motes '+(on?'ON':'OFF')+'</button>'+
    '<label>Repeat speed<select data-study-speed-target="'+node.id+'" aria-label="'+node.name+' — Repeat speed">'+LAB_SPEED_TIERS.map(function(mult){
      return '<option value="'+mult+'" '+(mult===target?'selected':'')+'>'+mult+'x · '+speedTierCost(mult)+' Motes per level</option>';
    }).join('')+'</select></label></div>';
}
function renderLongStudies(){
  var openInspections=Array.from(els['study-list'].querySelectorAll('details[open]')).map(function(el){return el.dataset.studyInspection;});
  var focusedInspection=document.activeElement && document.activeElement.dataset.studyDetails;
  renderLabCapacityBadge();
  var slots = studySlotCount();
  var openSlots = slots - state.activeStudies.length;
  var html = '<div class="study-slot-summary'+(openSlots>0?' has-open':'')+'"><div><strong>Studies '+state.activeStudies.length+' / '+slots+'</strong><span>'+(openSlots>0?openSlots+' slot'+(openSlots===1?'':'s')+' available':'All slots occupied')+'</span></div>' +
    (openSlots>0?'<button class="study-choose-btn" data-study-choose>Choose Study</button>':'')+'</div>';

  if(state.activeStudies.length){
    // Presentation-only ordering uses the simulation's remaining-work / speed relationship.
    state.activeStudies.slice().sort(function(a,b){return a.remainingSec/a.speedMult-b.remainingSec/b.speedMult;}).forEach(function(active,index){
      var node = LONG_STUDIES.find(function(n){ return n.id===active.id; });
      var maxed=node && node.levelCap!==undefined && longStudyLevel(active.id)>=node.levelCap;
      var pct = Math.max(0, Math.min(100, 100-(active.remainingSec/active.totalDurationSec*100)));
      var queueOnActive = !!state.studyQueue[active.id];
      html += '<div class="card study-card study-running" data-running-study="'+active.id+'">' +
        '<div class="study-running-label">'+(maxed?'Finishing paid Study':index===0?'Next completion':'Running')+'</div>' +
        '<div class="name"><span>'+(node?node.name:'')+' <span style="color:var(--mote);">Lv.'+(longStudyLevel(active.id)+(maxed?0:1))+(maxed?' · Maxed':'')+'</span></span>' +
          ' <button class="node-queue-toggle '+(queueOnActive?'active':'')+'" data-study-queue="'+active.id+'">Queue '+(queueOnActive?'ON':'OFF')+'</button>' +
        '</div>' +
        (node ? projectEarnedMarkup(active.id) : '') +
        '<div class="effect-note">'+(maxed?'Level cap already reached. Paid work finishes without another level or bonus.':
          'In progress: level '+(longStudyLevel(active.id)+1)+' · bonus earned only on completion.'+(active.id==='measuredinquiry'?' Next: '+earnedPercent(0.02*studyEffectiveLevel(node,longStudyLevel(active.id)+1))+'% less work.':''))+'</div>' +
        '<div class="study-time" data-study-text="'+active.id+'">'+studyRemainingText(active)+'</div>' +
        '<div class="study-bar-track"><div class="study-bar-fill" data-study-bar="'+active.id+'" style="width:'+pct+'%;"></div></div>' +
        (node ? studyMotesMarkup(node) : '') +
        '<details class="study-inspection" data-study-inspection="'+active.id+'" '+(openInspections.indexOf(active.id)!==-1?'open':'')+'><summary data-study-details="'+active.id+'">'+(node?node.name:'Study')+' · Details &amp; speed</summary>' +
        (node ? '<div class="desc">'+node.desc+'</div>' : '') +
        '<div class="section-sub" style="margin:8px 0;">Spend Motes to speed this Study up:</div>' +
        '<div class="speed-row">' +
          LAB_SPEED_TIERS.map(function(mult){
            var mcost = speedTierCost(mult);
            var isActive = active.speedMult===mult;
            var acquired = active.speedMult>=mult;
            var affordable = state.motes>=mcost;
            return '<button class="speed-btn '+(isActive?'active':'')+'" data-speed="'+mult+'" data-speed-study="'+active.id+'" '+((acquired||!affordable||maxed)?'disabled':'')+'>'+mult+'x' +
              (acquired ? (isActive?' · Current':' · Unlocked') : maxed ? ' · Unavailable' : '<span class="speed-cost">'+costIcon('mote')+formatNum(mcost)+'</span>') +
              '</button>';
          }).join('') +
        '</div></details>' +
      '</div>';
    });
  }

  html += '<h3 class="study-choices-title" id="study-choices" tabindex="-1">'+(openSlots>0 ? 'Choose a Study to begin' : 'Study choices — no open slots')+'</h3>';
  LONG_STUDIES.forEach(function(lnode){
    if(findActiveStudy(lnode.id)) return;
    var plan=getStudyStartPlan(lnode);
    if(!plan.unlocked){
      html += '<div class="card study-card locked-node" data-state="locked" aria-disabled="true" style="margin-bottom:10px;">' +
        '<div class="name">???</div>' +
        '<div class="desc lock-note">Unlocks at Rift '+lnode.unlockDepth+'</div>' +
      '</div>';
      return;
    }
    var level=plan.level,cost=plan.cost,dur=plan.duration;
    var queueOn = !!state.studyQueue[lnode.id];
    html += '<div class="card study-card" data-study-card="'+lnode.id+'" data-state="'+(plan.maxed?'maxed':plan.affordable?'affordable':'unavailable')+'" style="margin-bottom:10px;">' +
      '<div class="name">'+lnode.name+' <span style="color:var(--mote);">Lv.'+level+'</span>' +
        ' <button class="node-queue-toggle '+(queueOn?'active':'')+'" data-study-queue="'+lnode.id+'">Queue '+(queueOn?'ON':'OFF')+'</button>' +
      '</div>' +
      '<div class="desc">'+lnode.desc+'</div>' +
      projectEarnedMarkup(lnode.id) +
      '<div class="effect-note">'+(plan.maxed?'Maxed at level '+lnode.levelCap+'. Queue '+(queueOn?'ON':'OFF')+' retained; no new starts.':
        'Next: level '+(level+1)+' · bonus earned only on completion.'+(lnode.id==='measuredinquiry'?' Next: '+earnedPercent(0.02*studyEffectiveLevel(lnode,level+1))+'% less work.':''))+'</div>' +
      (plan.maxed?'':'<div class="study-meta" id="study-price-'+lnode.id+'">Takes '+fmtStudyDuration(dur)+' &middot; '+costIcon('lumen')+formatNum(cost.lumen)+' '+costIcon('shard')+formatNum(cost.shard)+'</div>') +
      '<button class="mini-btn" data-study="'+lnode.id+'" '+(plan.maxed?'':'aria-describedby="study-price-'+lnode.id+'" ')+(plan.affordable?'':'disabled')+' style="margin-top:10px;width:100%;">'+(plan.maxed?'Maxed':plan.reason==='unavailable'?'Unavailable':openSlots>0?'Begin Study':'No open slots')+'</button>' +
      studyMotesMarkup(lnode) +
    '</div>';
  });

  html += '<div class="section-sub">Unlocking more Studies by pushing deeper raises the slot cap. Studies progress while you’re away. Study Queue begins the next paid level. Use Motes buys the selected repeat speed for each active level, including manual starts, as soon as its full price is available. OFF keeps speed already paid for.</div>';
  replaceControlMarkup(els['study-list'],html);
  if(focusedInspection){
    var restoredInspection=els['study-list'].querySelector('[data-study-details="'+focusedInspection+'"]');
    if(restoredInspection) restoredInspection.focus({preventScroll:true});
  }
  var choose=els['study-list'].querySelector('[data-study-choose]');
  if(choose) choose.addEventListener('click',function(){
    var target=document.getElementById('study-choices');
    target.focus({preventScroll:true});target.scrollIntoView({block:'start'});
  });
  els['study-list'].querySelectorAll('[data-study]').forEach(function(btn){
    btn.addEventListener('click', function(){
      var lnode = LONG_STUDIES.find(function(n){ return n.id===btn.getAttribute('data-study'); });
      startStudy(lnode);
    });
  });
  els['study-list'].querySelectorAll('[data-speed-study]').forEach(function(btn){
    btn.addEventListener('click', function(){
      applySpeedTier(btn.getAttribute('data-speed-study'), parseFloat(btn.getAttribute('data-speed')));
    });
  });
  els['study-list'].querySelectorAll('[data-study-queue]').forEach(function(btn){
    btn.addEventListener('click', function(e){
      e.stopPropagation();
      var id = btn.getAttribute('data-study-queue');
      state.studyQueue[id] = !state.studyQueue[id];
      saveState();
      renderLongStudies();
    });
  });
  els['study-list'].querySelectorAll('[data-study-use-motes]').forEach(function(btn){
    btn.addEventListener('click',function(){
      var id=btn.getAttribute('data-study-use-motes');
      state.studyUseMotes[id]=!state.studyUseMotes[id];
      saveState();renderLongStudies();
    });
  });
  els['study-list'].querySelectorAll('[data-study-speed-target]').forEach(function(select){
    select.addEventListener('change',function(){
      var target=Number(select.value);
      if(LAB_SPEED_TIERS.indexOf(target)===-1) return;
      state.studySpeedTargets[select.getAttribute('data-study-speed-target')]=target;
      saveState();renderLongStudies();
    });
  });
}

function renderAscendSummary(){
  var cleared = clearedProgressionRift();
  var eligible = ascendEligible();
  var breakdown = ascendPrismBreakdown(progressionDepth());
  var gain = eligible ? breakdown.gain : 0;
  els['prism-preview'].textContent = '+' + formatNum(gain) + ' Prisms';
  els['ascend-btn'].disabled = !eligible;
  els['ascend-btn'].setAttribute('data-state',eligible?'available':'locked');
  els['ascend-btn'].setAttribute('aria-describedby','ascend-note');
  var ascendTab = document.querySelector('.tab-btn[data-tab="ascend"]');
  if(ascendTab) ascendTab.classList.toggle('has-attention',eligible);
  if(!eligible){
    els['ascend-note'].textContent = 'Clear Rift 15 to unlock your first Ascend. (' + Math.max(0,15-cleared) + ' to go)';
  } else if(breakdown.benchmark<=0){
    els['ascend-note'].textContent = 'First reward benchmark — this Ascend receives the full depth reward.';
  } else if(cleared>breakdown.benchmark){
    els['ascend-note'].textContent = 'New progress: '+formatNum(breakdown.reserve)+' reserve + '+formatNum(breakdown.progressBonus)+' depth bonus. Benchmark becomes cleared Rift '+cleared+'.';
  } else {
    els['ascend-note'].textContent = 'Repeat reward: 20% reserve. Push beyond cleared Rift '+breakdown.benchmark+' to add a depth bonus.';
  }
}

function renderNodes(){
  var html = '';
  NODES.forEach(function(node){
    if(node.requiresAchievement && !state.achieved[node.requiresAchievement]){
      var reqAch = ACHIEVEMENTS.find(function(a){ return a.id===node.requiresAchievement; });
      html += '<div class="card node-card locked-node" data-state="locked" aria-disabled="true">' +
        '<span class="shape shape-diamond" style="width:30px;height:30px;background:var(--ink-dim);"></span>' +
        '<div class="node-info" style="flex:1;">' +
          '<div class="name">???</div>' +
          '<div class="desc lock-note">Unlocks with the Deed &ldquo;'+(reqAch?reqAch.name:'')+'&rdquo;</div>' +
        '</div>' +
      '</div>';
      return;
    }
    var level = state.nodes[node.id];
    var cost = nodeCost(node);
    html += '<div class="card node-card">' +
      '<span class="shape shape-diamond" style="width:30px;height:30px;background:var(--prism);"></span>' +
      '<div class="node-info" style="flex:1;">' +
        '<div class="name">'+node.name+'</div>' +
        '<div class="desc">'+node.desc+'</div>' +
        '<div class="lvl" style="color:var(--prism);">Level '+level+'</div>' +
        '<div class="earned-effect" data-node-effect="'+node.id+'"><strong>Current node contribution:</strong> '+nodeEarnedEffect(node.id)+'</div>' +
        '<div class="effect-note">From this node only; other upgrades contribute separately.</div>' +
      '</div>' +
      '<button class="buy-btn" data-node="'+node.id+'" '+(state.prisms<cost?'disabled':'')+' style="min-width:78px;">' +
        '<span class="cost mono">'+costIcon('prism')+formatNum(cost)+'</span><span class="label">Prisms</span>' +
      '</button>' +
    '</div>';
  });
  replaceControlMarkup(els['node-list'],html);
  els['node-list'].querySelectorAll('[data-node]').forEach(function(btn){
    btn.addEventListener('click', function(){
      var node = NODES.find(function(n){ return n.id===btn.getAttribute('data-node'); });
      buyNode(node);
    });
  });
}

function renderAchievements(){
  var html = '';
  ACHIEVEMENTS.forEach(function(a){
    var done = !!state.achieved[a.id];
    var presentation = deedPresentation(a);
    var progress = deedProgress(a,state);
    var progressCurrent = progress ? (done ? progress.target : Math.min(progress.current,progress.target)) : 0;
    html += '<div class="card ach-card '+(done?'done':'')+'" data-state="'+(done?'completed':'available')+'">' +
      '<span class="dot"></span>' +
      '<div class="info">' +
        '<div class="name">'+a.name+(done?' · Completed':'')+'</div>' +
        '<div class="deed-requirement" data-deed-requirement="'+a.id+'">'+presentation.requirement+'</div>' +
        '<div class="ach-progress mono" data-deed-progress="'+a.id+'" data-current="'+progressCurrent+'" data-target="'+(progress?progress.target:0)+'">'+deedProgressText(a,done)+'</div>' +
        (presentation.scope ? '<div class="deed-scope">'+presentation.scope+'</div>' : '') +
        (a.unlocks ? '<div class="ach-unlock">Unlocks: '+a.unlocks+'</div>' : '') +
      '</div>' +
      '<span class="reward mono" aria-label="Reward: '+a.reward+' Comets">+'+a.reward+' '+costIcon('comet')+'</span>' +
    '</div>';
  });
  els['ach-list'].innerHTML = html;

  var shopHtml = '';
  SHOP.forEach(function(item){
    var owned = !!state.owned[item.id];
    var extra = '';
    var buttonHtml = '';
    if(item.id==='autoascend' && owned){
      var enabled = !!state.autoAscendEnabled;
      extra = '<label class="auto-ascend-target-label">Auto-Ascend after clearing' +
        '<select class="auto-ascend-target" data-autoascend-target aria-describedby="auto-ascend-target-help"></select></label>' +
        '<div class="desc" id="auto-ascend-target-help">ON: automatically Ascend after the selected Rift is defeated. OFF: keep pushing. Manual Ascend keeps this target.</div>' +
        '<div class="auto-ascend-nav" data-autoascend-nav hidden>' +
          '<div class="nav-row"><button type="button" data-autoascend-earlier>Earlier Rifts</button><button type="button" data-autoascend-later>Later Rifts</button></div>' +
          '<label class="auto-ascend-find-label">Find Rift (move list)<span class="nav-row find-row"><input class="auto-ascend-find" data-autoascend-find type="text" inputmode="numeric" aria-describedby="auto-ascend-range"><button type="button" data-autoascend-find-go>Find</button></span></label>' +
          '<div class="auto-ascend-range" id="auto-ascend-range" data-autoascend-range aria-live="polite"></div>' +
        '</div>';
      buttonHtml = '<button data-autoascend-toggle class="'+(enabled?'owned':'')+'">'+(enabled?'ON':'OFF')+'</button>';
    } else {
      buttonHtml = '<button data-shop="'+item.id+'" class="'+(owned?'owned':'')+'" '+((owned||state.comets<item.cost)?'disabled':'')+'>' +
        (owned ? 'Owned' : formatNum(item.cost)+' '+costIcon('comet')) +
      '</button>';
    }
    shopHtml += '<div class="card shop-card'+(item.id==='autoascend' && owned?' auto-ascend-card':'')+'"'+(item.id==='autoascend' && owned?' data-autoascend-card':'')+'>' +
      '<div class="info"><div class="name">'+item.name+'</div><div class="desc">'+item.desc+'</div>'+extra+'</div>' +
      buttonHtml +
    '</div>';
  });
  if(restStopComplete()){
    shopHtml += '<div class="card shop-card">' +
      '<div class="info"><div class="name">Daily Quest Refresh</div>' +
      '<div class="desc">Rest Stop complete. Spend '+dailyQuestRefreshCost()+' Comets beside any unclaimed Daily Quest to replace it with another eligible quest. Refreshing never grants extra power or extra quest slots.</div></div>' +
    '</div>';
  }
  replaceControlMarkup(els['shop-list'],shopHtml,true);
  els['shop-list'].querySelectorAll('button[data-shop]').forEach(function(btn){
    btn.addEventListener('click', function(){
      var item = SHOP.find(function(i){ return i.id===btn.getAttribute('data-shop'); });
      buyShopItem(item);
    });
  });
  var autoToggle = els['shop-list'].querySelector('[data-autoascend-toggle]');
  if(autoToggle){ autoToggle.onclick=toggleAutoAscend; }
  var autoTarget=els['shop-list'].querySelector('[data-autoascend-target]');
  if(autoTarget){
    renderAutoAscendTarget(autoTarget);
    autoTarget.onchange=function(){if(setAutoAscendClearedTarget(autoTarget.value)) renderShop();};
    var card=autoTarget.closest('[data-autoascend-card]'),find=card.querySelector('[data-autoascend-find]');
    card.querySelector('[data-autoascend-earlier]').onclick=function(){shiftAutoAscendWindow(-1);};
    card.querySelector('[data-autoascend-later]').onclick=function(){shiftAutoAscendWindow(1);};
    var findGo=card.querySelector('[data-autoascend-find-go]');
    findGo.onclick=function(){find.setAttribute('aria-invalid',String(!findAutoAscendRift(find.value)));};
    find.onkeydown=function(event){if(event.key==='Enter'){event.preventDefault();findGo.click();}};
  }
}
function renderShop(){ renderAchievements(); }

function renderCosmetics(){
  var html = '';
  RIFT_THEMES.forEach(function(theme){
    var unlocked = themeUnlocked(theme);
    var active = state.riftTheme===theme.id;
    if(!unlocked){
      var reqAch = ACHIEVEMENTS.find(function(a){ return a.id===theme.unlockAchievement; });
      html += '<div class="card theme-card locked-node" data-state="locked" aria-disabled="true">' +
        '<div class="theme-swatch" style="background:var(--ink-dim);"></div>' +
        '<div class="theme-info"><div class="name">???</div><div class="desc lock-note">Unlocks with the Deed &ldquo;'+(reqAch?reqAch.name:'')+'&rdquo;</div></div>' +
      '</div>';
      return;
    }
    var swatch = theme.accent ? theme.accent : 'conic-gradient(from 0deg, var(--lumen), var(--shard), var(--mote), var(--prism), var(--comet), var(--sigil), var(--lumen))';
    html += '<button type="button" class="card theme-card '+(active?'active':'')+'" aria-pressed="'+active+'" data-theme-select="'+theme.id+'">' +
      '<div class="theme-swatch" style="background:'+swatch+';"></div>' +
      '<div class="theme-info"><div class="name">'+theme.name+'</div><div class="desc">'+theme.desc+'</div></div>' +
      '<span class="theme-active-tag">'+(active?'✓ Equipped':'Equip')+'</span>' +
    '</button>';
  });
  replaceControlMarkup(els['theme-list'],html);
  els['theme-list'].querySelectorAll('[data-theme-select]').forEach(function(card){
    card.addEventListener('click', function(){ selectRiftTheme(card.getAttribute('data-theme-select')); });
  });
}

var CURRENCIES = [
  {name:'Lumen', shape:'shape-triangle', color:'var(--lumen)', desc:'Earned from every kill. Spend it to recruit and empower Wisps, and to fund Rift Forge upgrades and Research Lab projects.'},
  {name:'Shards', shape:'shape-hex', color:'var(--shard)', desc:'Also earned from every kill, in smaller amounts. Spend it to raise a Wisp’s Rarity tier and to fund Rift Forge upgrades and Research Lab projects.'},
  {name:'Motes', shape:'shape-pentagon', color:'var(--mote)', desc:'Dropped only by rare Luminous enemies in the Rift, always a fixed amount. Spend it to speed up your active Research Project in the Research Lab.'},
  {name:'Prisms', shape:'shape-diamond', color:'var(--prism)', desc:'Earned only by Ascending — the deeper you clear first, the more you get. Spend it on the permanent Ascension Tree.'},
  {name:'Comets', shape:'shape-star', color:'var(--comet)', desc:'Earned from Deeds, Daily Quests and login streaks. Spend them on Rest Stop convenience; after all four purchases, they can refresh unclaimed Daily Quests without granting power.'},
  {name:'Sigils', shape:'shape-octagon', color:'var(--sigil)', desc:'Dropped by Rift bosses. First unlock Mythic Wisp Ultimates; after every Ultimate is owned, spend 25 to ready one Active Wisp ability, up to 3 times per Ascension run.'}
];

function renderCurrencies(){
  var html = '';
  CURRENCIES.forEach(function(c){
    html += '<div class="card currency-card">' +
      '<span class="shape '+c.shape+'" style="width:26px;height:26px;background:'+c.color+';"></span>' +
      '<div><div class="cname">'+c.name+'</div><div class="cdesc">'+c.desc+'</div></div>' +
    '</div>';
  });
  if(els['currency-list']) els['currency-list'].innerHTML = html;
}

function renderManifesto(){
  var html = '';
  MANIFESTO.forEach(function(m){
    html += '<div class="card man-card">' +
      '<div class="eyebrow">'+m.eyebrow+'</div>' +
      '<div class="title">'+m.title+'</div>' +
      '<div class="body">'+m.body+'</div>' +
    '</div>';
  });
  if(els['manifesto']) els['manifesto'].innerHTML = html;
}

var ENCYCLOPEDIA_MECHANICS = [
  {name:'Push', meta:'Rift mode', desc:'Climb toward new Rifts and bosses. Your saved Push point is preserved if you switch to Farm.'},
  {name:'Rift Regions', meta:'World progression', desc:'The Rift changes region every 25 levels, moving through the Starlit Verge, Ashen Canopy, Glass Wastes, Drowned Observatory, Void Basilica and Crown of Night before deeper echoes begin.'},
  {name:'Farm', meta:'Rift mode', desc:'Repeat your highest cleared non-boss Rift for steady resources, then return to the exact Push point when ready.'},
  {name:'Wisp Power', meta:'Combat stat', desc:'Level and Rarity set each Wisp’s Power. It feeds passive damage and that Wisp’s damaging or resource ability. Support buff strength is fixed by the ability and its Ultimate, not by Wisp Power.'},
  {name:'Passive Wisp Damage', meta:'Combat rule', desc:'Active Wisp Power is multiplied by passive-only permanent upgrades, applicable damage Bonds and active Support buffs. Modules and Ultimates do not increase passive damage.'},
  {name:'Ability Output', meta:'Combat / economy rule', desc:'Damaging abilities use Wisp Power, their relevant Module, Ultimate, damage Bonds and Boss ability modifiers. Gale/Thorn resource output uses Wisp Power, its Module, Ultimate and Dawnpriest; passive-only party upgrades and Support buffs do not increase ability output.'},
  {name:'Tap damage (Guardian Tap)', meta:'Damage from tapping the enemy', desc:'This is your damage per tap on the enemy. Tap starts at 5 damage plus 2% of your general Active-Wisp passive power, then Tap upgrades apply. Support buffs and Guardian’s Mark also multiply it. Auto-Tap uses the same hit once per second.'},
  {name:'Rarity', meta:'Wisp progression', desc:'Rarity multiplies that Wisp’s Power, so it affects passive damage plus damaging/resource abilities. Every Rarity tier owned across the roster also adds +2% general passive-party power. Rarity does not strengthen Support buffs.'},
  {name:'Modules & Ultimates', meta:'Wisp progression', desc:'Modules are role-specific: Burst/Breaker Modules boost ability damage, Shard/Lumen Utility Modules boost their ability-generated resource, and Amplifier Modules boost Motes while Active. Ultimates double damage/resource ability output; Amplifier Ultimates change the buff from +25% for 4s to +50% for 8s.'},
  {name:'Endgame Currency Utility', meta:'Economy rule', desc:'After all eight Ultimates are owned, Sigils can ready one Active Wisp ability for 25 Sigils, at most 3 times per Ascension run. After all four Rest Stop purchases are owned, Comets can replace an unclaimed Daily Quest for at least the richest quest reward, so refreshing cannot generate extra Comets.'},
  {name:'Wisp Roles', meta:'Build label', desc:'Roles describe authoritative ability output: Burst delivers the highest raw ability coefficient; Breaker delivers heavy ability hits and the Stone + Titan Duskguard pair specializes against bosses; Amplifier buffs passive Wisp damage and your tap damage; Shard Utility and Lumen Utility add their named resource to ability casts. These are output and utility roles, not defensive combat roles.'},
  {name:'Ascend', meta:'Permanent progression', desc:'After clearing at least 15 Rifts, restart the run for Prisms. Your first reward sets a cleared-Rift benchmark; repeats at or below it earn a 20% reserve reward, while pushing beyond it adds a new-depth bonus. Permanent systems stay.'},
  {name:'Luminous Enemies', meta:'Rare encounter', desc:'Rare non-boss enemies that drop Motes. Their appearance chance rises as you push deeper.'},
  {name:'Boss Traits', meta:'Boss mechanic', desc:'Regrowth regenerates 0.9% max HP/s. Fractured Core regenerates 0.5%/s and takes +75% from Wisp ability hits only. Guardian’s Mark regenerates 0.6%/s and makes your manual taps and Auto-Tap deal x3; passive Wisp damage is unchanged by those trait bonuses.'},
  {name:'Offline Progress', meta:'Idle system', desc:'Combat, Wisp abilities, Auto-Tap, Farm, Auto-Ascend, Long Studies and automation continue while you are away. If Auto-Empower makes you strong enough after a boss retreat, the game retries the saved Boss automatically.'}
];

function renderEncyclopedia(){
  var el = document.getElementById('encyclopedia-content');
  if(!el) return;

  var html = '<div class="settings-section-title" style="margin-top:0;">Wisps</div><div class="ency-grid">';
  SPIRITS.forEach(function(sp){
    var recruited = (state.spirits[sp.id]||0)>0;
    var unlocked = state.maxDepthEver>=sp.unlockDepth;
    html += '<div class="ency-card" data-ency-wisp="'+sp.id+'"><div class="ency-top">' +
      wispPortrait(sp) +
      '<div class="ency-main"><div class="ency-name">'+sp.name+'</div><div class="ency-meta">'+sp.heroClass+' · '+sp.role+' · Unlock Rift '+sp.unlockDepth+'</div></div>' +
      '<span class="ency-status '+(recruited?'on':'')+'">'+(recruited?'Recruited':(unlocked?'Available':'Locked'))+'</span>' +
      '</div><div class="ency-desc"><strong>'+sp.abilityName+':</strong> '+ABILITY_DESC[sp.abilityType]+'</div></div>';
  });
  html += '</div>';

  html += '<div class="settings-section-title">Formation Bonds</div><div class="ency-grid">';
  FORMATION_BONDS.forEach(function(bond){
    var active = bondActive(bond.id);
    html += '<div class="ency-card"><div class="ency-top"><div class="ency-main"><div class="ency-name">'+bond.name+'</div><div class="ency-meta">'+bond.req+' · '+bond.tag+'</div></div>' +
      '<span class="ency-status '+(active?'on':'')+'">'+(active?'Active':'Inactive')+'</span></div>' +
      '<div class="ency-desc">'+bond.effect+'. Both listed Wisps must be Active and above Lv.0.</div></div>';
  });
  html += '</div>';

  html += '<div class="settings-section-title">Currencies</div><div class="ency-grid">';
  CURRENCIES.forEach(function(c){
    html += '<div class="ency-card"><div class="ency-top"><span class="shape '+c.shape+'" style="width:22px;height:22px;background:'+c.color+';"></span>' +
      '<div class="ency-main"><div class="ency-name">'+c.name+'</div></div></div><div class="ency-desc">'+c.desc+'</div></div>';
  });
  html += '</div>';

  html += '<div class="settings-section-title">Core Mechanics</div><div class="ency-grid">';
  ENCYCLOPEDIA_MECHANICS.forEach(function(m){
    html += '<div class="ency-card"><div class="ency-name">'+m.name+'</div><div class="ency-meta">'+m.meta+'</div><div class="ency-desc">'+m.desc+'</div></div>';
  });
  html += '</div>';

  el.innerHTML = html;
}

function renderDynamic(){
  renderSpirits();
  renderAscendSummary();
  updateBattleFast();
}

function renderAll(){
  if(overlayFocus && !overlayVisible(overlayFocus.el)) closeOverlay(overlayFocus.el);
  renderHud();
  updateBattleFast();
  renderSpirits();
  renderResearch();
  renderLongStudies();
  renderAscendSummary();
  renderNodes();
  renderAchievements();
  renderCosmetics();
  renderManifesto();
  renderEncyclopedia();
  renderSideStats(true);
}

var DAILY_RENDER_INTERVAL_MS = 250;
var lastDailyRenderAt = 0;
var dailyRenderTimer = null;
function renderDaily(force){
  if(!els['daily-quest-list']) return;
  var now = Date.now();
  var elapsed = now-lastDailyRenderAt;
  if(!force && elapsed<DAILY_RENDER_INTERVAL_MS){
    if(!dailyRenderTimer){
      dailyRenderTimer = setTimeout(function(){
        dailyRenderTimer = null;
        renderDaily(true);
      }, DAILY_RENDER_INTERVAL_MS-elapsed);
    }
    return;
  }
  if(dailyRenderTimer){ clearTimeout(dailyRenderTimer); dailyRenderTimer=null; }
  lastDailyRenderAt = now;
  els['daily-streak-badge'].textContent = 'Day ' + (state.loginStreak||1) + ' streak';
  var html = '';
  var hasReadyQuest = false;
  (state.questIds||[]).forEach(function(id){
    var q = QUEST_POOL.find(function(x){ return x.id===id; });
    if(!q) return;
    var progress = Math.min((state.dailyStats && state.dailyStats[q.metric])||0, q.goal);
    var pct = Math.round(progress/q.goal*100);
    var claimed = !!(state.questClaimed && state.questClaimed[id]);
    var ready = progress>=q.goal && !claimed;
    if(ready) hasReadyQuest = true;
    var rewardText = '+'+formatNum(q.reward.comets||0)+' '+costIcon('comet')+(q.reward.prisms ? ' +'+q.reward.prisms+' '+costIcon('prism') : '');
    var refreshCost = dailyQuestRefreshCost();
    var refreshCandidates = !claimed && restStopComplete() ? dailyQuestRefreshCandidates(id) : [];
    var refreshHtml = !claimed && restStopComplete() ?
      '<button class="quest-claim-btn quest-refresh-btn" data-quest-refresh="'+id+'" '+((state.comets>=refreshCost && refreshCandidates.length)?'':'disabled')+'>Refresh '+costIcon('comet')+refreshCost+'</button>' : '';
    html += '<div class="quest-row">' +
      '<div class="quest-row-head"><span class="quest-name">'+q.name+'</span><span class="quest-reward mono">'+rewardText+'</span></div>' +
      '<div class="quest-bar-track"><div class="quest-bar-fill" style="width:'+pct+'%;"></div></div>' +
      '<div class="quest-foot">' +
        '<span class="quest-progress-text">'+q.desc+' ('+formatNum(progress)+' / '+formatNum(q.goal)+')</span>' +
        '<span class="quest-actions">'+refreshHtml+
          '<button class="quest-claim-btn '+(claimed?'done':'')+'" data-quest-claim="'+id+'" '+(ready?'':'disabled')+'>'+(claimed?'Claimed':'Claim')+'</button>' +
        '</span>' +
      '</div>' +
    '</div>';
  });
  replaceControlMarkup(els['daily-quest-list'],html);
  var deedsTab = document.querySelector('.tab-btn[data-tab="deeds"]');
  if(deedsTab) deedsTab.classList.toggle('has-attention',hasReadyQuest);
  els['daily-quest-list'].querySelectorAll('[data-quest-claim]').forEach(function(btn){
    btn.addEventListener('click', function(){ claimQuest(btn.getAttribute('data-quest-claim')); });
  });
  els['daily-quest-list'].querySelectorAll('[data-quest-refresh]').forEach(function(btn){
    btn.addEventListener('click', function(){ refreshDailyQuest(btn.getAttribute('data-quest-refresh')); });
  });
}

function claimQuest(id){
  var q = QUEST_POOL.find(function(x){ return x.id===id; });
  if(!q || (state.questIds||[]).indexOf(id)===-1) return;
  if(state.questClaimed[id]) return;
  var progress = (state.dailyStats && state.dailyStats[q.metric])||0;
  if(progress < q.goal) return;
  state.questClaimed[id] = true;
  state.comets += q.reward.comets||0;
  if(q.reward.prisms) state.prisms += q.reward.prisms;
  showToast('Quest complete — '+'+'+formatNum(q.reward.comets||0)+' Comets'+(q.reward.prisms ? ' & +'+q.reward.prisms+' Prisms' : ''));
  renderDaily(true);
  renderHud();
}

function renderSideStats(force){
  renderDaily(!!force);
}

function showDailyOverlay(info){
  var overlay = document.getElementById('daily-overlay');
  if(!overlay) return;
  var reward = info.reward;
  var rewardText = '+'+formatNum(reward.comets||0)+' Comets'+(reward.prisms ? ' and +'+reward.prisms+' Prisms' : '');
  document.getElementById('daily-title').textContent = 'Day ' + info.streak + ' streak';
  document.getElementById('daily-text').textContent = 'Welcome back — you earned ' + rewardText + ' for returning today. Keep the streak alive by coming back tomorrow, and check Deeds for today\'s fresh Daily Quests.';
  var claimBtn = document.getElementById('daily-claim');
  function handler(){
    closeOverlay(overlay);
    claimBtn.removeEventListener('click', handler);
    renderDaily(true);
  }
  claimBtn.addEventListener('click', handler);
  openOverlay(overlay,handler);
}

// ---------------------------------------------------------------
// Tabs
// ---------------------------------------------------------------
function showSettingsView(view){
  var home = document.getElementById('settings-home');
  var encyclopedia = document.getElementById('settings-encyclopedia');
  var backup = document.getElementById('settings-backup');
  var title = document.getElementById('settings-title');
  var back = document.getElementById('settings-back');
  var isHome = view==='home';
  home.style.display = isHome ? 'block' : 'none';
  encyclopedia.style.display = view==='encyclopedia' ? 'block' : 'none';
  backup.style.display = view==='backup' ? 'block' : 'none';
  title.textContent = view==='encyclopedia' ? 'Encyclopedia' : (view==='backup' ? 'Save Backup' : 'Settings');
  back.style.visibility = isHome ? 'hidden' : 'visible';
  if(view==='encyclopedia') renderEncyclopedia();
  if(view==='backup') document.getElementById('save-backup-code').value = currentSaveBackup();
  if(document.getElementById('settings-overlay').style.display!=='none'){
    (isHome ? document.getElementById('encyclopedia-btn') : back).focus();
  }
}
function openSettings(){
  showSettingsView('home');
  openOverlay(document.getElementById('settings-overlay'),closeSettings,document.getElementById('settings-btn'));
}
function closeSettings(){
  closeOverlay(document.getElementById('settings-overlay'));
  document.getElementById('reset-confirm-row').style.display = 'none';
  document.getElementById('reset-row').style.display = 'block';
}

function syncMainScrollMode(tabName){
  var main = document.querySelector('main');
  if(!main) return;
  var battlePanel = document.getElementById('tab-battle');
  var battleActive = typeof tabName==='string' ? tabName==='battle' : !!(battlePanel && battlePanel.classList.contains('active'));
  if(main.classList.contains('rift-scroll-locked')!==battleActive){
    main.classList.toggle('rift-scroll-locked', battleActive);
  }
  if(battleActive && main.scrollTop!==0) main.scrollTop = 0;
}
var workshopSection='forge';
function activateTab(tabName){
  if(tabName==='workshop') tabName=workshopSection;
  var inWorkshop=tabName==='forge' || tabName==='research';
  var destination=inWorkshop ? 'workshop' : tabName;
  var btn=document.querySelector('.tab-btn[data-tab="'+destination+'"]');
  var panel=document.getElementById('tab-'+tabName);
  if(!btn || !panel) return;
  document.querySelectorAll('.tab-btn').forEach(function(b){b.classList.remove('active');b.setAttribute('aria-current','false');});
  document.querySelectorAll('.tab-panel').forEach(function(p){p.classList.remove('active');});
  btn.classList.add('active'); btn.setAttribute('aria-current','page'); panel.classList.add('active');
  document.getElementById('workshop-head').hidden=!inWorkshop;
  if(inWorkshop){
    workshopSection=tabName;
    document.querySelectorAll('.workshop-btn').forEach(function(b){var chosen=b.dataset.tab===tabName;b.setAttribute('aria-selected',String(chosen));b.tabIndex=chosen ? 0 : -1;});
  }
  if(tabName==='spirits'){renderFormationBonds();renderRosterJourney();}
  if(tabName==='forge') renderResearch();
  if(tabName==='research') renderLongStudies();
  if(tabName==='ascend') renderAscendSummary();
  if(tabName==='deeds') renderAchievements();
  var main=document.querySelector('main'); if(main) main.scrollTop=0;
  syncMainScrollMode(tabName);
}
function setupTabs(){
  function playNavFeedback(btn){
    btn.classList.remove('nav-feedback');
    if(matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    void btn.offsetWidth;
    btn.classList.add('nav-feedback');
  }
  function wire(group, workshop){
    group.forEach(function(btn,index){
      var name=btn.dataset.tab;
      if(!workshop){
        btn.id='nav-'+name;
        if(name==='workshop') btn.setAttribute('aria-controls','tab-forge tab-research');
        else{btn.setAttribute('aria-controls','tab-'+name);document.getElementById('tab-'+name).setAttribute('aria-labelledby',btn.id);}
        btn.setAttribute('aria-current',btn.classList.contains('active') ? 'page' : 'false');
        btn.setAttribute('aria-label',btn.querySelector('.lb').textContent);
      } else {
        var panel=document.getElementById('tab-'+name);
        panel.setAttribute('role','tabpanel');panel.setAttribute('aria-labelledby',btn.id);
      }
      btn.addEventListener('click',function(){activateTab(name);if(!workshop) playNavFeedback(btn);});
      if(!workshop){
        var finishFeedback=function(e){if(e.animationName==='navHalo') btn.classList.remove('nav-feedback');};
        btn.addEventListener('animationend',finishFeedback);
      }
      btn.addEventListener('keydown',function(e){
        var next=index;
        if(e.key==='ArrowRight') next=(index+1)%group.length;
        else if(e.key==='ArrowLeft') next=(index+group.length-1)%group.length;
        else if(e.key==='Home') next=0;
        else if(e.key==='End') next=group.length-1;
        else return;
        e.preventDefault();activateTab(group[next].dataset.tab);group[next].focus({preventScroll:true});if(!workshop) playNavFeedback(group[next]);
      });
    });
  }
  wire(Array.from(document.querySelectorAll('.tab-btn')),false);
  wire(Array.from(document.querySelectorAll('.workshop-btn')),true);
}

// ---------------------------------------------------------------
// Game loop
// ---------------------------------------------------------------
function autoEmpowerTick(){
  if(!state.achieved.labmaster) return false;
  var cheapest = null, cheapestCost = Infinity;
  autoEmpowerCandidateIds().forEach(function(id){
    if(state.empowerQueue[id]===false) return;
    var sp = SPIRITS.find(function(s){ return s.id===id; });
    if(!sp) return;
    var cost = spiritCost(sp);
    if(cost<cheapestCost){ cheapestCost=cost; cheapest=sp; }
  });
  if(cheapest && state.lumen>=cheapestCost){
    state.lumen -= cheapestCost;
    state.spirits[cheapest.id]++;
    reconcileFormationRebuild(state);
    trackDaily('empowers');
    return true;
  }
  return false;
}

/*
 * P0-05 authoritative elapsed-time simulation contract
 * ----------------------------------------------------
 * Rendering cadence is not gameplay cadence. Combat, abilities, automated
 * taps, automated purchases, Studies, boss regeneration and Rift transitions
 * advance against elapsed game time through this engine.
 *
 * Deliberate policy differences are explicit:
 *   - live rewards use a 1.0 earning scale;
 *   - offline Lumen/Shards use the existing offlineRate() progression rule;
 *   - only offline simulation may retreat from a genuinely unwinnable Boss.
 *
 * Passive Wisp damage is continuous and may carry elapsed time through more
 * than one enemy. Discrete Wisp bursts and Guardian/Auto-Taps remain
 * single-target events, so their overkill does not spill into the next enemy.
 * At equal timestamps the order is deterministic:
 *   1. elapsed passive damage/regeneration and enemy death/reward;
 *   2. current Auto-Ascend rule when a kill/arrival makes it ready;
 *   3. support-buff expiry;
 *   4. Wisp abilities (Active-party order);
 *   5. Auto-Tap;
 *   6. Auto-Empower;
 *   7. queued Research purchases;
 *   8. Long Study completion, then queued paid starts and repeat-speed buys;
 *   9. Boss retry, then Boss retreat if the current Boss is still unwinnable.
 *
 * Window/chunk boundaries are not a separate gameplay priority. The same
 * timestamp resolver runs at time zero, internal events and the requested end.
 *
 * This preserves existing formulas while making elapsed-time semantics
 * independent from the 100 ms UI tick and from offline loop chunk size.
 */
var SIM_EPS = 1e-9;
var SIM_EVENT_LIMIT = 250000;

function simulationPolicy(kind,options){
  options = options || {};
  var clockStartMs = Number.isFinite(options.clockStartMs) ? options.clockStartMs : Date.now();
  var offlineWindowStartMs = Number.isFinite(options.offlineWindowStartMs) ? options.offlineWindowStartMs : clockStartMs;
  return {
    kind:kind,
    offline:kind==='offline',
    visual:!!options.visual,
    allowBossRetreat:kind==='offline',
    offlineWindowStartMs:offlineWindowStartMs,
    bossRetreatNotBeforeMs:kind==='offline'
      ? offlineWindowStartMs + OFFLINE_BOSS_RETREAT_GRACE_SEC*1000
      : Infinity
  };
}
function simulationRewardScale(policy){
  return policy.offline ? offlineRate() : 1;
}
function simulationSummary(elapsedSec){
  return {
    elapsedSec:elapsedSec,
    lumenGained:0, shardGained:0, sigilsGained:0, motesGained:0,
    kills:0, bossKills:0, luminousKills:0, ascends:0, autoTaps:0,
    empowers:0, researchBought:0, studiesStarted:0, studySpeedPurchases:0, studyMotesSpent:0, completedStudies:[], closedStudies:[],
    achievements:[], retreated:false, retreats:0, retries:0,
    fastForwardedKills:0, iterations:0, ascendGains:[]
  };
}
function simulationTimelinePush(summary,elapsedSec,type,detail){
  if(!summary.timeline) return;
  if(summary.timeline.length>=2000) throw new Error('Authoritative simulation timeline guard exceeded');
  summary.timeline.push({
    elapsedSec:elapsedSec,
    type:type,
    detail:detail||null
  });
}
// Interpret the persisted deadline at its stored precision on the same
// whole-second/grid-phase clock as elapsed simulation. Never subtract a
// rounded epoch "now" to obtain an interval on that more precise clock.
function supportDeadlineSecondsRemaining(until,nowMs,clock){
  if(!until) return 0;
  if(!clock) return (until-nowMs)/1000;
  var deadlineWhole = Math.floor(until/1000);
  var deadlineRemaining = 1-(until-deadlineWhole*1000)/1000;
  return (deadlineWhole-clock.wholeSec)+(clock.remainingSec-deadlineRemaining);
}
function simulationBuffSecondsRemaining(nowMs,clock){
  return supportDeadlineSecondsRemaining(state.buffUntil,nowMs,clock);
}
function applySupportCast(sp,nowMs,clock){
  if(!sp || (sp.id!=='tide' && sp.id!=='aurora') || (state.spirits[sp.id]||0)<=0 || state.activeParty.indexOf(sp.id)===-1) return;
  var profile = supportAbilityProfile(sp);
  if(!state.supportBuffs) state.supportBuffs = {version:1,sources:{}};
  var sources = state.supportBuffs.sources;
  var old = sources[sp.id];
  // An expired cast cannot pass its strength into a later cast.
  if(old && supportDeadlineSecondsRemaining(old.until,nowMs,clock)<=0) old = null;
  sources[sp.id] = {
    until:Math.max(old ? old.until : 0,nowMs+profile.durationMs),
    mult:Math.max(old ? old.mult : 1,profile.strength)
  };
  // buffUntil/buffMult are an opaque legacy entitlement, never an aggregate.
}
function simulationExpireBuff(nowMs,clock){
  var changed = false;
  if(state.buffUntil && simulationBuffSecondsRemaining(nowMs,clock)<=0){
    state.buffUntil = 0;
    state.buffMult = 1;
    changed = true;
  }
  var sources = state.supportBuffs && state.supportBuffs.sources;
  if(sources) ['tide','aurora'].forEach(function(id){
    if(sources[id] && supportDeadlineSecondsRemaining(sources[id].until,nowMs,clock)<=0){
      delete sources[id];
      changed = true;
    }
  });
  return changed;
}
function simulationRecordAchievements(summary){
  var changed = applyAchievementChecks();
  changed.forEach(function(a){
    if(summary.achievements.indexOf(a.id)===-1) summary.achievements.push(a.id);
  });
  return changed.length;
}
function simulationBuffMult(nowMs,clock){
  var known = 1;
  var sources = state.supportBuffs && state.supportBuffs.sources;
  if(sources) ['tide','aurora'].forEach(function(id){
    var entry = sources[id];
    if(entry && supportDeadlineSecondsRemaining(entry.until,nowMs,clock)>0) known += entry.mult-1;
  });
  var legacy = simulationBuffSecondsRemaining(nowMs,clock)>0 ? state.buffMult : 1;
  return Math.max(legacy,known);
}
function simulationPassiveDps(nowMs,clock){
  return passiveWispDpsAt(state.depth) * simulationBuffMult(nowMs,clock);
}
function simulationNextBuffSeconds(nowMs,clock){
  var remaining = simulationBuffSecondsRemaining(nowMs,clock);
  var next = remaining>0 ? remaining : Infinity;
  var sources = state.supportBuffs && state.supportBuffs.sources;
  if(sources) ['tide','aurora'].forEach(function(id){
    if(!sources[id]) return;
    var seconds = supportDeadlineSecondsRemaining(sources[id].until,nowMs,clock);
    if(seconds>0) next = Math.min(next,seconds);
  });
  return next;
}
function simulationNextAbilitySeconds(){
  var fillPerSec = (100/ABILITY_BASE_CYCLE_SEC) * fillRateMult();
  if(fillPerSec<=0) return Infinity;
  var next = Infinity;
  state.activeParty.forEach(function(id){
    if((state.spirits[id]||0)<=0) return;
    var cur = Math.max(0,Math.min(100,state.heroResource[id]||0));
    next = Math.min(next,Math.max(0,(100-cur)/fillPerSec));
  });
  return next;
}
function simulationAdvanceAbilityResources(elapsedSec){
  if(elapsedSec<=0) return;
  var fill = (100/ABILITY_BASE_CYCLE_SEC) * fillRateMult() * elapsedSec;
  state.activeParty.forEach(function(id){
    if((state.spirits[id]||0)<=0) return;
    state.heroResource[id] = Math.min(100,(state.heroResource[id]||0)+fill);
  });
}
function simulationNextAutoTapSeconds(){
  if(!state.achieved.autotap) return Infinity;
  return Math.max(0,(1000-(state._autoTapAccum||0))/1000);
}
function simulationNextAutoEmpowerSeconds(){
  if(!state.achieved.labmaster) return Infinity;
  return Math.max(0,(1000-(state._autoEmpowerAccum||0))/1000);
}
function simulationAdvanceAutomationTimers(elapsedSec){
  if(state.achieved.autotap) state._autoTapAccum = (state._autoTapAccum||0) + elapsedSec*1000;
  if(state.achieved.labmaster) state._autoEmpowerAccum = (state._autoEmpowerAccum||0) + elapsedSec*1000;
}
function simulationNextStudySeconds(){
  var next = Infinity;
  state.activeStudies.forEach(function(active){
    if(active.speedMult>0) next = Math.min(next,Math.max(0,active.remainingSec/active.speedMult));
  });
  return next;
}
function simulationAdvanceStudyProgress(elapsedSec){
  if(elapsedSec<=0) return;
  state.activeStudies.forEach(function(active){
    active.remainingSec -= elapsedSec * active.speedMult;
  });
}
function simulationCompleteDueStudies(summary){
  var handled = 0,earned = 0;
  for(var i=state.activeStudies.length-1;i>=0;i--){
    var active = state.activeStudies[i];
    if(active.remainingSec>SIM_EPS) continue;
    var result=finishStudyRecord(i);
    if(result.earned){summary.completedStudies.push(result.name);earned++;}
    else summary.closedStudies.push(result.name);
    handled++;
  }
  if(earned) simulationRecordAchievements(summary);
  return handled;
}
function simulationStartQueuedStudies(summary){
  var started = 0;
  var candidates = LONG_STUDIES.filter(function(node){
    return state.studyQueue[node.id] && getStudyStartPlan(node).eligible;
  });
  candidates.sort(function(a,b){
    var ca = studyCost(a,state.longStudyLevels[a.id]||0);
    var cb = studyCost(b,state.longStudyLevels[b.id]||0);
    return (ca.lumen+ca.shard)-(cb.lumen+cb.shard);
  });
  for(var i=0;i<candidates.length && state.activeStudies.length<studySlotCount();i++){
    var node = candidates[i];
    if(!commitStudyStart(node)) continue;
    started++;
    summary.studiesStarted++;
  }
  return started;
}
function simulationResearchLevelTotal(){
  return RESEARCH.reduce(function(sum,node){ return sum+(state.research[node.id]||0); },0);
}
function simulationDrainResearchQueue(summary){
  var before = simulationResearchLevelTotal();
  var guard = 0;
  while(autoLabQueueTick()){
    guard++;
    if(guard>=1000) throw new Error('Authoritative simulation Research guard exceeded');
  }
  var bought = simulationResearchLevelTotal()-before;
  if(bought>0){
    summary.researchBought += bought;
    simulationRecordAchievements(summary);
  }
  return bought;
}
function simulationCurrencyKillsNeeded(cost,lumenPerKill,shardPerKill){
  var lumenDeficit = Math.max(0,cost.lumen-state.lumen);
  var shardDeficit = Math.max(0,cost.shard-state.shards);
  // Affordability itself is strict (budget >= cost), so any positive deficit
  // needs at least one real reward event. Never round a tiny deficit down to a
  // zero-time economy boundary.
  var lumenKills = lumenDeficit<=0 ? 0 : (lumenPerKill>0 ? Math.max(1,Math.ceil(lumenDeficit/lumenPerKill-1e-12)) : Infinity);
  var shardKills = shardDeficit<=0 ? 0 : (shardPerKill>0 ? Math.max(1,Math.ceil(shardDeficit/shardPerKill-1e-12)) : Infinity);
  return Math.max(lumenKills,shardKills);
}
function simulationBuyStudySpeeds(summary,elapsedSec){
  var bought=0;
  // Shared Motes follow catalogue order, independent of active/UI ordering.
  LONG_STUDIES.forEach(function(node){
    var plan=studyMotesPlan(node);
    if(!plan || state.motes<plan.cost) return;
    state.motes-=plan.cost;
    plan.active.speedMult=plan.target;
    summary.studySpeedPurchases++;
    summary.studyMotesSpent+=plan.cost;
    simulationTimelinePush(summary,elapsedSec,'studySpeed',{id:node.id,speed:plan.target,cost:plan.cost});
    bought++;
  });
  return bought;
}
function simulationKillsUntilStudyMotes(){
  var depth=state.farmDepth||state.depth;
  var reward=Math.max(1,Math.round(motesDropFor(depth)*(1+supportMoteBonus())));
  var chance=eliteChance(depth);
  var accum=Math.max(0,Math.min(0.999999999999,state.luminousAccum||0));
  var first=state.enemyIsLuminous ? 1 : 0,best=Infinity;
  LONG_STUDIES.forEach(function(node){
    var plan=studyMotesPlan(node);
    if(!plan) return;
    var deficit=plan.cost-state.motes;
    if(deficit<=0){best=0;return;}
    // Any positive deficit needs a real Luminous reward, however small it is.
    var luminousNeeded=Math.max(1,Math.ceil(deficit/reward));
    if(luminousNeeded<=first){best=Math.min(best,1);return;}
    if(chance<=0) return;
    var crossings=luminousNeeded-first;
    var kills=Math.max(2,Math.ceil((crossings-accum-1e-12)/chance)+1);
    if(!Number.isSafeInteger(kills)) return;
    // Match the actual batch/spawn crossing arithmetic, including its epsilon.
    if(Math.floor(accum+(kills-1)*chance+1e-12)<crossings) kills++;
    if(kills>2 && Math.floor(accum+(kills-2)*chance+1e-12)>=crossings) kills--;
    best=Math.min(best,kills);
  });
  return best;
}
function simulationKillsUntilEconomyMutation(rewardScale){
  var depth = state.farmDepth||state.depth;
  var lumenPerKill = enemyRewardFor(depth)*rewardScale;
  var shardPerKill = shardRewardFor(depth)*rewardScale;
  var best = simulationKillsUntilStudyMotes();

  RESEARCH.forEach(function(node){
    if(!state.researchQueue[node.id]) return;
    var eligibility = researchEligibility(node);
    if(!eligibility.unlocked || eligibility.maxed) return;
    var cost = researchCostForLevels(node,state.research[node.id],1);
    best = Math.min(best,simulationCurrencyKillsNeeded(cost,lumenPerKill,shardPerKill));
  });

  if(state.activeStudies.length<studySlotCount()){
    LONG_STUDIES.forEach(function(node){
      if(!state.studyQueue[node.id]) return;
      var plan=getStudyStartPlan(node);
      if(!plan.eligible) return;
      best = Math.min(best,simulationCurrencyKillsNeeded(plan.cost,lumenPerKill,shardPerKill));
    });
  }
  return best;
}
function simulationFarmEconomyBoundarySeconds(dps,rewardScale){
  if(dps<=0 || state.enemyMaxHp<=0) return Infinity;
  var killsNeeded = simulationKillsUntilEconomyMutation(rewardScale);
  if(!isFinite(killsNeeded)) return Infinity;
  if(killsNeeded<=0) return 0;
  return (state.enemyHp + Math.max(0,killsNeeded-1)*state.enemyMaxHp)/dps;
}
function simulationApplyAutoAscend(summary){
  if(!autoAscendReady()) return false;
  var gain = applyAscendMutation();
  summary.ascends++;
  summary.ascendGains.push(gain);
  // saveState() canonicalizes runtime state after a normal Auto-Ascend. Do the
  // same in-memory here so live and offline do not diverge before persistence.
  state = acceptPersistedState(state,'simulation-ascend');
  simulationRecordAchievements(summary);
  return true;
}
function simulationDefeatEnemy(policy,summary){
  var depth = state.depth;
  var wasBoss = isBoss(depth);
  var wasLuminous = !!state.enemyIsLuminous;
  var rewardScale = simulationRewardScale(policy);
  var lumenGain = enemyRewardFor(depth)*rewardScale;
  var shardGain = shardRewardFor(depth)*rewardScale;

  gainLumen(lumenGain);
  state.shards += shardGain;
  summary.lumenGained += lumenGain;
  summary.shardGained += shardGain;

  if(wasLuminous){
    var moteGain = Math.max(1,Math.round(motesDropFor(depth)*(1+supportMoteBonus())));
    state.motes += moteGain;
    summary.motesGained += moteGain;
    summary.luminousKills++;
    trackDaily('luminousKills');
  }
  if(wasBoss){
    var sigilGain = sigilsFromBoss(depth);
    state.sigils += sigilGain;
    summary.sigilsGained += sigilGain;
    summary.bossKills++;
    trackDaily('bossKills');
  }

  state.totalKills++;
  summary.kills++;
  trackDaily('kills');

  if(state.riftMode==='farm'){
    state.depth = state.farmDepth;
    spawnEnemy();
  } else {
    state.depth++;
    state.maxDepthEver = Math.max(state.maxDepthEver,state.depth);
    spawnEnemy();
  }

  simulationRecordAchievements(summary);
  simulationApplyAutoAscend(summary);
}
function simulationBatchFarmKills(count,policy,summary){
  count = Math.max(0,Math.floor(count));
  if(!count) return;
  var depth = state.farmDepth||state.depth;
  var rewardScale = simulationRewardScale(policy);
  var lumenGain = enemyRewardFor(depth)*rewardScale*count;
  var shardGain = shardRewardFor(depth)*rewardScale*count;
  var startAccum = Math.max(0,Math.min(0.999999999999,state.luminousAccum||0));
  var chance = eliteChance(depth);
  var luminousKills = state.enemyIsLuminous ? 1 : 0;

  if(count>1){
    luminousKills += Math.floor(startAccum+(count-1)*chance+1e-12);
  }

  var afterSpawns = startAccum+count*chance;
  var completedCrossings = Math.floor(afterSpawns+1e-12);
  var finalAccum = afterSpawns-completedCrossings;
  if(finalAccum<0 && finalAccum>-SIM_EPS) finalAccum=0;
  if(finalAccum>=1 && finalAccum<1+SIM_EPS) finalAccum=0;
  var beforeFinalSpawn = startAccum+Math.max(0,count-1)*chance;
  var finalLuminous = Math.floor(afterSpawns+1e-12)>Math.floor(beforeFinalSpawn+1e-12);

  gainLumen(lumenGain);
  state.shards += shardGain;
  summary.lumenGained += lumenGain;
  summary.shardGained += shardGain;

  if(luminousKills>0){
    var motePer = Math.max(1,Math.round(motesDropFor(depth)*(1+supportMoteBonus())));
    var moteGain = motePer*luminousKills;
    state.motes += moteGain;
    summary.motesGained += moteGain;
    summary.luminousKills += luminousKills;
    trackDaily('luminousKills',luminousKills);
  }

  state.totalKills += count;
  summary.kills += count;
  if(count>1) summary.fastForwardedKills += count-1;
  trackDaily('kills',count);

  state.depth = state.farmDepth;
  state.enemyDepth = state.depth;
  state.enemyMaxHp = enemyHpFor(state.depth);
  state.enemyHp = state.enemyMaxHp;
  state.luminousAccum = Math.max(0,Math.min(0.999999999999,finalAccum));
  state.enemyIsLuminous = finalLuminous;
  simulationRecordAchievements(summary);
}
function simulationApplyFarmPassive(elapsedSec,dps,policy,summary){
  if(elapsedSec<=0 || dps<=0) return;
  var damage = dps*elapsedSec;
  if(damage+SIM_EPS < state.enemyHp){
    state.enemyHp -= damage;
    return;
  }

  var maxHp = state.enemyMaxHp>0 ? state.enemyMaxHp : enemyHpFor(state.depth);
  // Decompose damage before subtracting the partially damaged enemy. This
  // avoids both a rounded quotient/modulo counting the same boundary twice
  // and cancellation of a small current HP from a huge damage value.
  var remainder = damage%maxHp;
  var kills = simulationWholeHpUnits(damage,maxHp);
  // Retain the existing 1e-12 quotient and SIM_EPS HP boundary tolerances,
  // applying a carry once to this shared decomposition, never twice.
  if(remainder>=maxHp-SIM_EPS || remainder/maxHp+1e-12>=1){
    kills++;
    remainder=0;
  }
  var difference = remainder-state.enemyHp;
  var leftover;
  if(difference>=-SIM_EPS || difference/maxHp>=-1e-12){
    kills++;
    leftover=Math.max(0,difference);
  } else {
    leftover=maxHp+ difference;
  }
  if(leftover<SIM_EPS) leftover=0;

  simulationBatchFarmKills(kills,policy,summary);
  if(leftover>0) state.enemyHp = Math.max(SIM_EPS,state.enemyMaxHp-leftover);
}
function simulationWholeHpUnits(damage,maxHp){
  // A rounded division/subtraction cannot recover an exact integer quotient
  // near 2^53. Divide the represented values exactly, without a per-kill loop.
  // Game maximum HP is integral; floor(D)/H has the same floor as D/H.
  if(!Number.isFinite(damage) || !Number.isFinite(maxHp)) return Math.floor(damage/maxHp);
  if(Number.isInteger(maxHp)) return Number(BigInt(Math.floor(damage))/BigInt(maxHp));
  // Fractional finite HP uses its binary significand and exponent. The shifts
  // are bounded by the IEEE double exponent range, independent of kill count.
  var view = new DataView(new ArrayBuffer(16));
  view.setFloat64(0,damage);
  view.setFloat64(8,maxHp);
  var dhi=view.getUint32(0),hhi=view.getUint32(8);
  var de=(dhi>>>20)&2047,he=(hhi>>>20)&2047;
  var dn=(BigInt(dhi&1048575)<<32n)|BigInt(view.getUint32(4));
  var hn=(BigInt(hhi&1048575)<<32n)|BigInt(view.getUint32(12));
  if(de) dn+=1n<<52n;
  if(he) hn+=1n<<52n;
  var shift=(de?de-1075:-1074)-(he?he-1075:-1074);
  return Number(shift>=0 ? (dn<<BigInt(shift))/hn : dn/(hn<<BigInt(-shift)));
}
function simulationPassiveKillSeconds(dps){
  if(state.riftMode==='farm') return Infinity;
  if(isBoss(state.depth)){
    var net = dps-state.enemyMaxHp*bossRegenRate(state.depth);
    return net>0 ? Math.max(0,state.enemyHp/net) : Infinity;
  }
  return dps>0 ? Math.max(0,state.enemyHp/dps) : Infinity;
}
function simulationApplyPushPassive(elapsedSec,dps,policy,summary){
  if(elapsedSec<=0) return;
  if(isBoss(state.depth)){
    var net = dps-state.enemyMaxHp*bossRegenRate(state.depth);
    state.enemyHp = Math.min(state.enemyMaxHp,state.enemyHp-net*elapsedSec);
  } else if(dps>0){
    state.enemyHp -= dps*elapsedSec;
  }
  if(state.enemyHp<=SIM_EPS) simulationDefeatEnemy(policy,summary);
}
function simulationDealDiscreteDamage(amount,policy,summary){
  if(amount<=0) return false;
  state.enemyHp -= amount;
  if(state.enemyHp<=SIM_EPS){
    simulationDefeatEnemy(policy,summary);
    return true;
  }
  return false;
}
function simulationTriggerAbility(sp,level,nowMs,policy,summary,clock){
  var burst = abilityRawBurst(sp,level);
  var rewards = abilityRewardPerCast(sp,level);
  var rewardScale = simulationRewardScale(policy);

  if(rewards.shards>0){
    var shardGain = rewards.shards*rewardScale;
    state.shards += shardGain;
    summary.shardGained += shardGain;
  }
  if(rewards.lumen>0){
    var lumenGain = rewards.lumen*rewardScale;
    gainLumen(lumenGain);
    summary.lumenGained += lumenGain;
  }
  if(sp.abilityType==='support'){
    applySupportCast(sp,nowMs,clock);
  }

  if(policy.visual){
    emitCombatVfx(sp.abilityType==='support' ? 'support' : 'ability',sp.color,sp.id);
    flashBattleStage(sp.abilityType==='support' ? 'support' : 'ability');
  }
  if(burst>0){
    simulationDealDiscreteDamage(
      burst*formationContextDamageMult(state.depth)*bossAbilityDamageMult(state.depth),
      policy,
      summary
    );
  }
}
function simulationProcessAbilities(nowMs,policy,summary,clock){
  var fired = 0;
  var ids = state.activeParty.slice();
  for(var i=0;i<ids.length;i++){
    var id = ids[i];
    if((state.spirits[id]||0)<=0 || (state.heroResource[id]||0)<100-1e-7) continue;
    var sp = SPIRITS.find(function(s){ return s.id===id; });
    if(!sp) continue;
    state.heroResource[id] = 0;
    simulationTriggerAbility(sp,state.spirits[id],nowMs,policy,summary,clock);
    fired++;
  }
  return fired;
}
function simulationProcessAutoTap(nowMs,policy,summary,clock){
  var processed = 0;
  while(state.achieved.autotap && (state._autoTapAccum||0)>=1000-1e-7){
    var tapResidual = (state._autoTapAccum||0)-1000;
    state._autoTapAccum = Math.abs(tapResidual)<1e-7 ? 0 : Math.max(0,tapResidual);
    state.totalTaps++;
    summary.autoTaps++;
    trackDaily('taps');
    var damage = guardianTapDamageAt(state.depth,simulationBuffMult(nowMs,clock));
    if(policy.visual) spawnFloatNum('+'+formatNum(damage),els['enemy-stage']);
    simulationDealDiscreteDamage(damage,policy,summary);
    processed++;
    if(processed>10) throw new Error('Authoritative simulation Auto-Tap guard exceeded');
  }
  return processed;
}
function simulationProcessAutoEmpower(summary){
  var processed = 0;
  while(state.achieved.labmaster && (state._autoEmpowerAccum||0)>=1000-1e-7){
    var empowerResidual = (state._autoEmpowerAccum||0)-1000;
    state._autoEmpowerAccum = Math.abs(empowerResidual)<1e-7 ? 0 : Math.max(0,empowerResidual);
    if(autoEmpowerTick()) summary.empowers++;
    processed++;
    if(processed>10) throw new Error('Authoritative simulation Auto-Empower guard exceeded');
  }
  return processed;
}
function simulationNextBossRetreatSeconds(nowMs,policy){
  if(!policy.allowBossRetreat || state.riftMode==='farm' || !isBoss(state.depth)) return Infinity;
  if(isFinite(estimatedBossKillSeconds(state.depth))) return Infinity;
  return Math.max(0,(policy.bossRetreatNotBeforeMs-nowMs)/1000);
}
function simulationMaybeRetreatFromBoss(policy,summary,nowMs){
  if(!policy.allowBossRetreat || state.riftMode==='farm' || !isBoss(state.depth)) return false;
  // Background intent contract: a brief screen lock keeps the selected Push
  // Boss. Only an impossible sustained-DPS wall that survives a full 5-minute
  // uninterrupted offline grace period may switch to Farm.
  if(nowMs+SIM_EPS*1000 < policy.bossRetreatNotBeforeMs) return false;
  if(isFinite(estimatedBossKillSeconds(state.depth))) return false;
  if(state.depth<=1) return false;
  state.farmReturnDepth = state.depth;
  state.farmDepth = highestFarmableDepth(state.farmReturnDepth);
  state.riftMode = 'farm';
  state.depth = state.farmDepth;
  spawnEnemy(false);
  summary.retreated = true;
  summary.retreats++;
  return true;
}
function simulationMaybeRetryBoss(policy,summary){
  if(!policy.allowBossRetreat || state.riftMode!=='farm' || !state.farmReturnDepth || !isBoss(state.farmReturnDepth)) return false;
  var retryDepth = state.farmReturnDepth;
  if(!isFinite(estimatedBossKillSeconds(retryDepth))) return false;
  state.depth = retryDepth;
  state.riftMode = 'push';
  state.farmDepth = 0;
  state.farmReturnDepth = 0;
  spawnEnemy(false);
  summary.retries++;
  return true;
}
function simulationResolveTimestamp(nowMs,elapsedSec,policy,summary,clock){
  var actions = 0;
  var ascendsBefore;

  if(simulationExpireBuff(nowMs,clock)){
    simulationTimelinePush(summary,elapsedSec,'buffExpire');
    actions++;
  }

  ascendsBefore = summary.ascends;
  var abilities = simulationProcessAbilities(nowMs,policy,summary,clock);
  if(abilities){
    simulationTimelinePush(summary,elapsedSec,'ability',{count:abilities});
    actions += abilities;
  }
  if(summary.ascends>ascendsBefore){
    simulationTimelinePush(summary,elapsedSec,'autoAscend',{count:summary.ascends-ascendsBefore});
  }

  ascendsBefore = summary.ascends;
  var taps = simulationProcessAutoTap(nowMs,policy,summary,clock);
  if(taps){
    simulationTimelinePush(summary,elapsedSec,'autoTap',{count:taps});
    actions += taps;
  }
  if(summary.ascends>ascendsBefore){
    simulationTimelinePush(summary,elapsedSec,'autoAscend',{count:summary.ascends-ascendsBefore});
  }

  var spiritBefore = {};
  SPIRITS.forEach(function(sp){ spiritBefore[sp.id]=state.spirits[sp.id]||0; });
  var empowersBefore = summary.empowers;
  var empowerChecks = simulationProcessAutoEmpower(summary);
  var empowerPurchases = summary.empowers-empowersBefore;
  if(empowerPurchases){
    var empowered = [];
    SPIRITS.forEach(function(sp){
      var id=sp.id;
      var delta = (state.spirits[id]||0)-(spiritBefore[id]||0);
      if(delta>0) empowered.push({id:id,levels:delta});
    });
    simulationTimelinePush(summary,elapsedSec,'autoEmpower',{count:empowerPurchases,wisps:empowered});
  }
  actions += empowerChecks;

  var researchBefore = {};
  RESEARCH.forEach(function(node){ researchBefore[node.id]=state.research[node.id]||0; });
  var researchBought = simulationDrainResearchQueue(summary);
  if(researchBought){
    var researchChanges = [];
    RESEARCH.forEach(function(node){
      var delta = (state.research[node.id]||0)-(researchBefore[node.id]||0);
      if(delta>0) researchChanges.push({id:node.id,levels:delta});
    });
    simulationTimelinePush(summary,elapsedSec,'research',{count:researchBought,nodes:researchChanges});
    actions += researchBought;
  }

  var completedBefore = summary.completedStudies.length;
  var closedBefore = summary.closedStudies.length;
  var handledStudies = simulationCompleteDueStudies(summary);
  var earnedStudies = summary.completedStudies.length-completedBefore;
  if(earnedStudies){
    simulationTimelinePush(summary,elapsedSec,'studyComplete',{
      count:earnedStudies,
      names:summary.completedStudies.slice(completedBefore)
    });
  }
  if(summary.closedStudies.length>closedBefore) simulationTimelinePush(summary,elapsedSec,'studyClose',{
    count:summary.closedStudies.length-closedBefore,names:summary.closedStudies.slice(closedBefore)
  });
  actions += handledStudies;

  var activeBefore = {};
  state.activeStudies.forEach(function(active){ activeBefore[active.id]=true; });
  var studiesStarted = simulationStartQueuedStudies(summary);
  if(studiesStarted){
    var startedIds = state.activeStudies
      .filter(function(active){ return !activeBefore[active.id]; })
      .map(function(active){ return active.id; });
    simulationTimelinePush(summary,elapsedSec,'studyStart',{count:studiesStarted,ids:startedIds});
    actions += studiesStarted;
  }

  actions += simulationBuyStudySpeeds(summary,elapsedSec);
  actions += simulationRecordAchievements(summary);

  if(simulationMaybeRetryBoss(policy,summary)){
    simulationTimelinePush(summary,elapsedSec,'bossRetry',{depth:state.depth});
    actions++;
  } else if(simulationMaybeRetreatFromBoss(policy,summary,nowMs)){
    simulationTimelinePush(summary,elapsedSec,'bossRetreat',{
      farmDepth:state.farmDepth,
      returnDepth:state.farmReturnDepth
    });
    actions++;
  }

  return actions;
}
function advanceAuthoritativeTime(elapsedSec,options){
  options = options || {};
  elapsedSec = Math.max(0,Number(elapsedSec)||0);
  var policy = simulationPolicy(options.kind||'live',options);
  var summary = simulationSummary(elapsedSec);
  var clockStartMs = Number.isFinite(options.clockStartMs) ? options.clockStartMs : Date.now();
  var clockStartWholeSec = Math.floor(clockStartMs/1000);
  var elapsedWholeSec = 0;
  var elapsedFractionSec = 0;
  var targetWholeSec = Math.floor(elapsedSec);
  var targetFractionSec = elapsedSec-targetWholeSec;

  function currentElapsedSec(){
    return elapsedWholeSec+elapsedFractionSec;
  }
  function simulationRemainingSec(){
    // Window-end time is represented in the same one-second grid coordinate as
    // Farm scheduling. When a window end and Farm grid are the same logical
    // instant, both candidates therefore use the exact same residual value.
    var crossingDelta = targetFarmGridCrossings-farmGridCrossings;
    if(crossingDelta<0) return 0;
    if(crossingDelta===0){
      return Math.max(0,farmGridRemainingSec-targetFarmGridRemainingSec);
    }
    return farmGridRemainingSec + Math.max(0,crossingDelta-1) + (1-targetFarmGridRemainingSec);
  }
  function simulationClockPosition(){
    return {wholeSec:clockStartWholeSec+farmGridCrossings,remainingSec:farmGridRemainingSec};
  }
  function simulationNowMs(){
    // Compose absolute event time from the same canonical one-second scheduler
    // on every call. This avoids call-boundary-dependent grouping such as
    // (base + 203.157s) versus ((base + 180s) + 23.157s).
    var absoluteWholeSec = clockStartWholeSec + farmGridCrossings;
    var absolutePhaseSec = farmGridRemainingSec===1 ? 0 : 1-farmGridRemainingSec;
    return absoluteWholeSec*1000 + absolutePhaseSec*1000;
  }

  var elapsedInRun = 0;
  var remaining = elapsedSec;

  // Authoritative simulation time is carried as whole + fractional seconds.
  // Absolute epoch milliseconds are derived only from that split clock when
  // gameplay semantics require them (for example support-buff expiry).
  var startPhaseSec = (((clockStartMs%1000)+1000)%1000)/1000;
  var firstFarmGridSec = startPhaseSec===0 ? 1 : 1-startPhaseSec;
  var farmGridRemainingSec = firstFarmGridSec;
  var farmGridCrossings = 0;
  var targetGridPositionSec = startPhaseSec+elapsedSec;
  var targetFarmGridCrossings = Math.floor(targetGridPositionSec);
  var targetGridPhaseSec = targetGridPositionSec-targetFarmGridCrossings;
  var targetFarmGridRemainingSec = targetGridPhaseSec===0 ? 1 : 1-targetGridPhaseSec;

  function advanceFarmGridClock(stepSec){
    if(stepSec<=0) return 0;
    if(stepSec<farmGridRemainingSec){
      farmGridRemainingSec -= stepSec;
      return 0;
    }
    var afterFirst = stepSec-farmGridRemainingSec;
    var wholeAfter = Math.floor(afterFirst);
    var fractionalAfter = afterFirst-wholeAfter;
    var crossed = 1+wholeAfter;
    farmGridCrossings += crossed;
    farmGridRemainingSec = fractionalAfter===0 ? 1 : 1-fractionalAfter;
    return crossed;
  }
  function syncElapsedClockFromFarmGrid(){
    // The grid countdown is the canonical sub-second clock. Derive logical
    // elapsed from it after every segment instead of independently summing the
    // same floating-point steps in a second clock.
    if(farmGridCrossings===0){
      elapsedWholeSec = 0;
      elapsedFractionSec = firstFarmGridSec-farmGridRemainingSec;
      return;
    }

    elapsedWholeSec = farmGridCrossings-1;
    elapsedFractionSec = firstFarmGridSec+(1-farmGridRemainingSec);
    if(elapsedFractionSec>=1){
      var carry = Math.floor(elapsedFractionSec);
      elapsedWholeSec += carry;
      elapsedFractionSec -= carry;
    }
  }

  var traceEverySec = Math.max(0,Number(options.traceEverySec)||0);
  var nextTraceElapsedSec = traceEverySec>0 ? traceEverySec : Infinity;
  if(traceEverySec>0) summary.trace = [];
  if(options.captureTimeline) summary.timeline = [];
  var traceEventsFromSec = Number.isFinite(options.traceEventsFromSec) ? options.traceEventsFromSec : Infinity;
  var traceEventsToSec = Number.isFinite(options.traceEventsToSec) ? options.traceEventsToSec : -Infinity;
  var traceOffsetSec = Number(options.traceOffsetSec)||0;
  if(traceEventsFromSec<=traceEventsToSec) summary.eventTrace = [];

  function captureSimulationTrace(){
    var traceNowMs = simulationNowMs();
    var traceDps = simulationPassiveDps(traceNowMs,simulationClockPosition());
    var traceRewardScale = simulationRewardScale(policy);
    var traceFarmGrid = state.riftMode==='farm'
      ? farmGridRemainingSec
      : Infinity;
    summary.trace.push({
      elapsedSec:elapsedInRun,
      enemyHp:state.enemyHp,
      enemyMaxHp:state.enemyMaxHp,
      totalKills:state.totalKills,
      luminousAccum:state.luminousAccum,
      enemyIsLuminous:!!state.enemyIsLuminous,
      autoTapAccum:state._autoTapAccum||0,
      autoEmpowerAccum:state._autoEmpowerAccum||0,
      heroResource:JSON.parse(JSON.stringify(state.heroResource||{})),
      lumen:state.lumen,
      shards:state.shards,
      spirits:JSON.parse(JSON.stringify(state.spirits||{})),
      passiveDps:traceDps,
      nextEvents:{
        ability:simulationNextAbilitySeconds(),
        autoTap:simulationNextAutoTapSeconds(),
        autoEmpower:simulationNextAutoEmpowerSeconds(),
        study:simulationNextStudySeconds(),
        farmGrid:traceFarmGrid,
        economy:state.riftMode==='farm'
          ? simulationFarmEconomyBoundarySeconds(traceDps,traceRewardScale)
          : Infinity
      }
    });
  }

  // Resolve time-zero state with exactly the same ordering as every later
  // timestamp. This is critical for compositional offline simulation: a caller
  // boundary cannot give Research/Studies priority over due automation.
  var initialNowMs = simulationNowMs();
  var initialAscends = summary.ascends;
  if(state.enemyHp<=SIM_EPS){
    var initialKills = summary.kills;
    simulationDefeatEnemy(policy,summary);
    simulationTimelinePush(summary,0,'enemyDeath',{count:summary.kills-initialKills});
    if(summary.ascends>initialAscends){
      simulationTimelinePush(summary,0,'autoAscend',{count:summary.ascends-initialAscends});
      initialAscends = summary.ascends;
    }
  }
  if(simulationApplyAutoAscend(summary) && summary.ascends>initialAscends){
    simulationTimelinePush(summary,0,'autoAscend',{count:summary.ascends-initialAscends});
  }
  simulationResolveTimestamp(initialNowMs,0,policy,summary,simulationClockPosition());

  while(remaining>0){
    summary.iterations++;
    if(summary.iterations>SIM_EVENT_LIMIT){
      throw new Error('Authoritative simulation event limit exceeded after '+summary.iterations+' iterations');
    }

    var nowMs = simulationNowMs();

    if(state.enemyHp<=SIM_EPS){
      var topKillsBefore = summary.kills;
      var topAscendsBefore = summary.ascends;
      simulationDefeatEnemy(policy,summary);
      simulationTimelinePush(summary,currentElapsedSec(),'enemyDeath',{count:summary.kills-topKillsBefore});
      if(summary.ascends>topAscendsBefore){
        simulationTimelinePush(summary,currentElapsedSec(),'autoAscend',{count:summary.ascends-topAscendsBefore});
      }
      simulationResolveTimestamp(nowMs,currentElapsedSec(),policy,summary,simulationClockPosition());
      continue;
    }
    var explicitAscendsBefore = summary.ascends;
    if(simulationApplyAutoAscend(summary)){
      simulationTimelinePush(summary,currentElapsedSec(),'autoAscend',{count:summary.ascends-explicitAscendsBefore});
      simulationResolveTimestamp(nowMs,currentElapsedSec(),policy,summary,simulationClockPosition());
      continue;
    }

    var dps = simulationPassiveDps(nowMs,simulationClockPosition());
    var rewardScale = simulationRewardScale(policy);
    var next = remaining;
    var abilityStep = simulationNextAbilitySeconds();
    var autoTapStep = simulationNextAutoTapSeconds();
    var autoEmpowerStep = simulationNextAutoEmpowerSeconds();
    var studyStep = simulationNextStudySeconds();
    var buffStep = simulationNextBuffSeconds(nowMs,simulationClockPosition());
    var bossRetreatStep = simulationNextBossRetreatSeconds(nowMs,policy);

    next = Math.min(next,abilityStep);
    next = Math.min(next,autoTapStep);
    next = Math.min(next,autoEmpowerStep);
    next = Math.min(next,studyStep);
    next = Math.min(next,buffStep);
    next = Math.min(next,bossRetreatStep);

    var farmGridStep = Infinity;
    var economyStep = Infinity;
    if(state.riftMode==='farm'){
      farmGridStep = farmGridRemainingSec;
      economyStep = simulationFarmEconomyBoundarySeconds(dps,rewardScale);
      next = Math.min(next,farmGridStep);
      next = Math.min(next,economyStep);
    } else {
      next = Math.min(next,simulationPassiveKillSeconds(dps));
    }

    if(!Number.isFinite(next)) next = remaining;
    next = Math.max(0,Math.min(remaining,next));
    var hitsFarmGrid = state.riftMode==='farm' && next===farmGridStep;
    var hitsWindowEnd = next===remaining;
    var diagnosticEventKinds = [];
    if(next===abilityStep) diagnosticEventKinds.push('ability');
    if(next===autoTapStep) diagnosticEventKinds.push('autoTap');
    if(next===autoEmpowerStep) diagnosticEventKinds.push('autoEmpower');
    if(next===studyStep) diagnosticEventKinds.push('study');
    if(next===buffStep) diagnosticEventKinds.push('buff');
    if(next===bossRetreatStep) diagnosticEventKinds.push('bossRetreatGrace');
    if(next===farmGridStep) diagnosticEventKinds.push('farmGrid');
    if(next===economyStep) diagnosticEventKinds.push('economy');
    if(next===remaining) diagnosticEventKinds.push('windowEnd');
    var diagnosticCandidates = {
      ability:abilityStep,
      autoTap:autoTapStep,
      autoEmpower:autoEmpowerStep,
      study:studyStep,
      bossRetreatGrace:bossRetreatStep,
      farmGrid:farmGridStep,
      economy:economyStep
    };

    var killsBefore = summary.kills;
    var ascendsBeforeAdvance = summary.ascends;
    var elapsedWholeBefore = elapsedWholeSec;
    var elapsedFractionBefore = elapsedFractionSec;
    // Sub-nanosecond elapsed time can still carry material damage at mature
    // power. Never discard it merely because it is below a generic time
    // epsilon; only treat the simulator as stalled if floating-point
    // subtraction literally cannot advance the remaining clock and no state
    // event fires.
    if(next>0){
      if(policy.visual && policy.kind==='live' && dps>0)presentPassiveWispAttack();
      var ascendsBeforePassive = state.ascendCount;
      if(state.riftMode==='farm') simulationApplyFarmPassive(next,dps,policy,summary);
      else simulationApplyPushPassive(next,dps,policy,summary);
      // A kill can Ascend at this endpoint. The preceding interval belongs to
      // the old run; do not credit its time to reset resources/purchase timers.
      if(state.ascendCount===ascendsBeforePassive){
        simulationAdvanceAbilityResources(next);
        simulationAdvanceAutomationTimers(next);
      }
      simulationAdvanceStudyProgress(next);
      var crossedFarmGrids = advanceFarmGridClock(next);
      if(hitsFarmGrid && crossedFarmGrids!==1){
        throw new Error('Authoritative Farm grid clock crossed an unexpected boundary count');
      }
      // One scheduler, one notion of elapsed time. A processed grid event
      // resets farmGridRemainingSec exactly to 1, and logical elapsed is then
      // reconstructed from that canonical scheduler state.
      syncElapsedClockFromFarmGrid();
      if(hitsWindowEnd){
        // The caller's requested endpoint is itself an authoritative event
        // boundary. Canonicalize both logical elapsed and the analytical grid
        // phase so the next call starts from exactly the same scheduler state.
        elapsedWholeSec = targetWholeSec;
        elapsedFractionSec = targetFractionSec;

        farmGridCrossings = targetFarmGridCrossings;
        farmGridRemainingSec = targetFarmGridRemainingSec;
      }
      elapsedInRun = currentElapsedSec();
      remaining = hitsWindowEnd ? 0 : simulationRemainingSec();
    }

    nowMs = simulationNowMs();
    var actions = summary.kills-killsBefore;
    if(summary.kills>killsBefore){
      simulationTimelinePush(summary,elapsedInRun,'enemyDeath',{count:summary.kills-killsBefore});
    }
    if(summary.ascends>ascendsBeforeAdvance){
      simulationTimelinePush(summary,elapsedInRun,'autoAscend',{count:summary.ascends-ascendsBeforeAdvance});
    }
    actions += simulationResolveTimestamp(nowMs,elapsedInRun,policy,summary,simulationClockPosition());

    if(traceEverySec>0 && elapsedInRun===nextTraceElapsedSec){
      captureSimulationTrace();
      nextTraceElapsedSec += traceEverySec;
    }

    var diagnosticLogicalElapsed = traceOffsetSec + elapsedInRun;
    if(summary.eventTrace && diagnosticLogicalElapsed>=traceEventsFromSec && diagnosticLogicalElapsed<=traceEventsToSec){
      summary.eventTrace.push({
        logicalElapsedSec:diagnosticLogicalElapsed,
        clockMs:nowMs,
        stepSec:next,
        kinds:diagnosticEventKinds,
        candidates:diagnosticCandidates,
        farmGridRemainingSec:farmGridRemainingSec,
        enemyHp:state.enemyHp,
        enemyMaxHp:state.enemyMaxHp,
        totalKills:state.totalKills,
        luminousAccum:state.luminousAccum,
        enemyIsLuminous:!!state.enemyIsLuminous,
        autoTapAccum:state._autoTapAccum||0,
        autoEmpowerAccum:state._autoEmpowerAccum||0,
        heroResource:JSON.parse(JSON.stringify(state.heroResource||{})),
        lumen:state.lumen,
        shards:state.shards,
        spirits:JSON.parse(JSON.stringify(state.spirits||{})),
        buffUntil:state.buffUntil||0,
        buffMult:state.buffMult||1,
        supportBuffs:state.supportBuffs ? JSON.parse(JSON.stringify(state.supportBuffs)) : null,
        activeStudies:JSON.parse(JSON.stringify(state.activeStudies||[])),
        passiveDps:simulationPassiveDps(nowMs,simulationClockPosition())
      });
    }

    if(elapsedWholeSec===elapsedWholeBefore && elapsedFractionSec===elapsedFractionBefore && actions===0){
      throw new Error('Authoritative simulation stalled without elapsed-time or state progress | '+JSON.stringify({
        elapsedInRun:elapsedInRun,
        elapsedWholeSec:elapsedWholeSec,
        elapsedFractionSec:elapsedFractionSec,
        elapsedSec:elapsedSec,
        remaining:remaining,
        stepSec:next,
        farmGridRemainingSec:farmGridRemainingSec,
        farmGridCrossings:farmGridCrossings,
        riftMode:state.riftMode,
        candidates:diagnosticCandidates,
        kinds:diagnosticEventKinds
      }));
    }
  }

  summary.endDepth = state.depth;
  summary.pushDepth = progressionDepth();
  summary.clockEndMs = clockStartMs + elapsedSec*1000;
  return summary;
}
function advanceStudyOnlyTime(elapsedSec,clockStartMs,summary){
  var remaining = Math.max(0,Number(elapsedSec)||0);
  var nowMs = Number.isFinite(clockStartMs) ? clockStartMs : Date.now();
  simulationCompleteDueStudies(summary);
  simulationStartQueuedStudies(summary);
  simulationBuyStudySpeeds(summary,0);
  while(remaining>SIM_EPS){
    var next = Math.min(remaining,simulationNextStudySeconds());
    if(!Number.isFinite(next)) break;
    if(next>SIM_EPS){
      simulationAdvanceStudyProgress(next);
      remaining -= next;
      nowMs += next*1000;
    }
    var actions = simulationCompleteDueStudies(summary)+simulationStartQueuedStudies(summary);
    actions += simulationBuyStudySpeeds(summary,Math.max(0,Number(elapsedSec)||0)-remaining);
    if(next<=SIM_EPS && actions===0) break;
  }
  return nowMs;
}

// Presentation observes only this tick's committed result. No event queue or
// persisted marker: suppressed/rapid/offline events are deliberately discarded.
var liveRiftFeedbackAt = -Infinity;
function presentLiveRiftResult(before,sim){
  if(!sim.kills || sim.ascends || document.hidden || startupIntroPlaying ||
      !document.getElementById('tab-battle').classList.contains('active') ||
      Array.from(document.querySelectorAll('.overlay')).some(overlayVisible)) return;
  var now = Date.now();
  if(now-liveRiftFeedbackAt<1850 || document.querySelector('.rift-milestone')) return;
  var milestone = 0;
  if(before.mode==='push' && state.maxDepthEver>before.maxDepth){
    // Keep the latest newly reached Wisp, otherwise the latest region. A boss
    // entrance is relevant only if it is still the current encounter.
    SPIRITS.forEach(function(sp){
      if(sp.unlockDepth>before.maxDepth && sp.unlockDepth<=state.maxDepthEver) milestone=sp.unlockDepth;
    });
    if(!milestone){
      var regionStart = Math.floor((state.maxDepthEver-1)/RIFT_ZONE_SPAN)*RIFT_ZONE_SPAN+1;
      if(regionStart>before.maxDepth) milestone=regionStart;
      else if(isBoss(state.depth) && state.depth>before.maxDepth) milestone=state.depth;
      else if(before.maxDepth<16 && state.maxDepthEver>=16 && state.ascendCount===0) milestone=16;
    }
  }
  if(!milestone && !sim.bossKills) return;
  liveRiftFeedbackAt = now;
  var reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if(sim.bossKills && !reduced){
    emitCombatVfx('boss-death','#ef5b6b');
    flashBattleStage('victory');
  }
  if(milestone){
    announceDepthMilestone(milestone,before.maxDepth);
  } else if(before.mode==='push'){
    var defeatedDepth = Math.floor((state.depth-1)/10)*10;
    showRiftMilestone('BOSS DEFEATED',sim.bossKills===1 ? 'Rift '+defeatedDepth+' conquered' : sim.bossKills+' Bosses defeated','+'+formatNum(sim.sigilsGained)+' Sigils','#ff8552');
  }
}
function tick(){
  if(document.hidden || resetInProgress || reloadInProgress) return;
  var feedbackBefore = {mode:state.riftMode,maxDepth:state.maxDepthEver};
  var sim = advanceAuthoritativeTime(TICK_MS/1000,{kind:'live',visual:true,clockStartMs:Date.now()-TICK_MS});

  if(sim.ascends>0){
    saveState();
    showAscendFlash(sim.ascendGains[sim.ascendGains.length-1]||0,true);
  }
  if(sim.completedStudies.length || sim.closedStudies.length){
    saveState();
    sim.completedStudies.forEach(function(name){ showToast('Study complete: '+name+' advanced a level!'); });
    sim.closedStudies.forEach(function(name){ showToast('Study finished: '+name+' — level cap already reached.'); });
  }
  if(sim.achievements.length){
    renderAchievements();
    renderNodes();
  }
  if(sim.empowers>0) renderSpirits();
  if(sim.researchBought>0) renderResearch();
  if(sim.studySpeedPurchases>0) saveState();
  if(sim.completedStudies.length || sim.closedStudies.length || sim.studiesStarted>0 || sim.studySpeedPurchases>0) renderLongStudies();
  else updateStudyProgress();

  if(sim.kills>0 || sim.ascends>0){
    renderDynamic();
    renderSideStats();
  }
  updateBattleFast();
  checkAffordability();
  presentLiveRiftResult(feedbackBefore,sim);
}

// Research-only: round up so a positive remainder never reads as zero.
// Keep fmtDuration's shared Deed, boss and offline wording unchanged.
function fmtStudyDuration(sec){
  if(!Number.isFinite(sec) || sec<0 || !Number.isSafeInteger(Math.ceil(sec))) return 'Time unavailable';
  sec = Math.ceil(sec);
  var d = Math.floor(sec/86400), h = Math.floor(sec%86400/3600);
  var m = Math.floor(sec%3600/60), s = sec%60;
  function pad(n){ return String(n).padStart(2,'0'); }
  if(d>0) return d+'d '+pad(h)+'h '+pad(m)+'m '+pad(s)+'s';
  if(h>0) return h+'h '+pad(m)+'m '+pad(s)+'s';
  if(m>0) return m+'m '+pad(s)+'s';
  return s+'s';
}
function studyRemainingText(active){
  if(!active || !Number.isFinite(active.remainingSec) || active.remainingSec<0 ||
      !Number.isFinite(active.speedMult) || active.speedMult<=0) return 'Time unavailable';
  // Membership in activeStudies still means pending authoritative completion.
  if(active.remainingSec===0) return 'Finishing…';
  var duration = fmtStudyDuration(Math.max(Number.MIN_VALUE,active.remainingSec/active.speedMult));
  return duration==='Time unavailable' ? duration : duration+' remaining · '+active.speedMult+'x';
}
function updateStudyProgress(){
  state.activeStudies.forEach(function(active){
    var fillEl = els['study-list'].querySelector('[data-study-bar="'+active.id+'"]');
    var textEl = els['study-list'].querySelector('[data-study-text="'+active.id+'"]');
    if(!fillEl || !textEl) return;
    var pct = Math.max(0, Math.min(100, 100 - (active.remainingSec/active.totalDurationSec*100)));
    fillEl.style.width = pct+'%';
    var text = studyRemainingText(active);
    if(textEl.textContent!==text) textEl.textContent = text;
  });
}

var AFFORDABILITY_REFRESH_MS = 500;
var lastAffordabilityAt = 0;
function checkAffordability(){
  var now = Date.now();
  if(now-lastAffordabilityAt < AFFORDABILITY_REFRESH_MS) return;
  lastAffordabilityAt = now;
  els['spirit-list'].querySelectorAll('[data-empower]').forEach(function(btn){
    var sp = SPIRITS.find(function(s){ return s.id===btn.getAttribute('data-empower'); });
    if(sp) btn.disabled = state.lumen < spiritCost(sp);
  });
  els['spirit-list'].querySelectorAll('[data-rarity]').forEach(function(btn){
    var id = btn.getAttribute('data-rarity');
    var sp = SPIRITS.find(function(s){ return s.id===id; });
    if(!sp) return;
    var tier = state.heroRarity[id]||0;
    if(tier>=5){ btn.disabled = true; return; }
    var level = state.spirits[id];
    var req = rarityReq(tier);
    var cost = rarityCost(sp, tier);
    btn.disabled = !(level>=req && state.shards>=cost.shard && state.lumen>=cost.lumen);
  });
  els['spirit-list'].querySelectorAll('[data-module]').forEach(function(btn){
    var sp = SPIRITS.find(function(s){ return s.id===btn.getAttribute('data-module'); });
    if(!sp) return;
    var level = moduleLevel(sp.id);
    if(level>=MODULE_MAX_LEVEL) return;
    var cost = moduleCost(sp, level);
    btn.disabled = state.lumen<cost.lumen || state.shards<cost.shard;
  });
  els['spirit-list'].querySelectorAll('[data-ultimate]').forEach(function(btn){
    var sp = SPIRITS.find(function(s){ return s.id===btn.getAttribute('data-ultimate'); });
    if(!sp) return;
    btn.disabled = state.sigils<ultimateSigilCost(sp);
  });
  els['research-list'].querySelectorAll('[data-research]').forEach(function(btn){
    var node = RESEARCH.find(function(n){ return n.id===btn.getAttribute('data-research'); });
    if(!node) return;
    updateResearchCard(node,btn.closest('[data-forge-card]'));
  });
  var openStudySlots = studySlotCount() - state.activeStudies.length;
  els['study-list'].querySelectorAll('[data-study]').forEach(function(btn){
    var lnode = LONG_STUDIES.find(function(n){ return n.id===btn.getAttribute('data-study'); });
    if(!lnode) return;
    btn.disabled = !getStudyStartPlan(lnode).affordable;
  });
  els['study-list'].querySelectorAll('[data-speed-study]').forEach(function(btn){
    var active = findActiveStudy(btn.getAttribute('data-speed-study'));
    if(!active) return;
    var mult = parseFloat(btn.getAttribute('data-speed'));
    var acquired = active.speedMult>=mult;
    var node=LONG_STUDIES.find(function(n){return n.id===active.id;});
    var maxed=node && node.levelCap!==undefined && longStudyLevel(active.id)>=node.levelCap;
    btn.disabled = acquired || maxed || state.motes<speedTierCost(mult);
  });
  ['spirit-list','research-list','study-list','node-list','shop-list'].forEach(function(id){presentControlStates(els[id]);});
  var autoTarget=els['shop-list'].querySelector('[data-autoascend-target]');
  if(autoTarget && state.owned.autoascend) renderAutoAscendTarget(autoTarget);
}

// ---------------------------------------------------------------
// Starfield
// ---------------------------------------------------------------
function setupStars(){
  var canvas = document.getElementById('stars');
  var ctx = canvas.getContext('2d');
  var stars = [];
  var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  function resize(){
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    var count = Math.floor((canvas.width*canvas.height)/9000);
    stars = [];
    for(var i=0;i<count;i++){
      stars.push({
        x: Math.random()*canvas.width,
        y: Math.random()*canvas.height,
        r: Math.random()*1.4+0.3,
        phase: Math.random()*Math.PI*2,
        speed: 0.4+Math.random()*0.8
      });
    }
  }
  function isDark(){
    var t = document.documentElement.getAttribute('data-theme');
    if(t==='dark') return true;
    if(t==='light') return false;
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  }
  var lastStarDraw = 0;
  var STAR_FRAME_MS = 50;
  function draw(t){
    if(!reduceMotion && t-lastStarDraw<STAR_FRAME_MS){
      requestAnimationFrame(draw);
      return;
    }
    lastStarDraw = t;
    ctx.clearRect(0,0,canvas.width,canvas.height);
    var dark = isDark();
    var base = dark ? [230,228,245] : [90,80,140];
    stars.forEach(function(s){
      var tw = reduceMotion ? 0.7 : (0.5 + 0.5*Math.sin(t*0.001*s.speed + s.phase));
      ctx.beginPath();
      ctx.arc(s.x, s.y, s.r, 0, Math.PI*2);
      ctx.fillStyle = 'rgba('+base[0]+','+base[1]+','+base[2]+','+(dark ? 0.15+tw*0.5 : 0.10+tw*0.25)+')';
      ctx.fill();
    });
    if(!reduceMotion) requestAnimationFrame(draw);
  }
  window.addEventListener('resize', resize);
  resize();
  requestAnimationFrame(draw);
}

// ---------------------------------------------------------------
// Init
// ---------------------------------------------------------------
function simulateOfflineRun(effectiveSec,options){
  options = options || {};
  var clockStartMs = Number.isFinite(options.clockStartMs) ? options.clockStartMs : Date.now()-effectiveSec*1000;
  var offlineWindowStartMs = Number.isFinite(options.offlineWindowStartMs) ? options.offlineWindowStartMs : clockStartMs;
  return advanceAuthoritativeTime(effectiveSec,{
    kind:'offline',
    visual:false,
    clockStartMs:clockStartMs,
    offlineWindowStartMs:offlineWindowStartMs
  });
}

function applyOfflineProgress(){
  var now = Date.now();
  var lastSeen = state.lastSeen||now;
  var elapsedSec = Math.max(0,(now-lastSeen)/1000);
  if(elapsedSec < 5) return null;

  var capSec = offlineCapHours()*3600;
  var effectiveSec = Math.min(elapsedSec,capSec);
  var sim = simulateOfflineRun(effectiveSec,{clockStartMs:lastSeen});

  // Long Studies are real-time progression and intentionally continue past the
  // combat earning cap. Combat, Auto-Tap, Auto-Empower and Research do not.
  if(elapsedSec>effectiveSec){
    advanceStudyOnlyTime(elapsedSec-effectiveSec,lastSeen+effectiveSec*1000,sim);
  }

  state.totalOfflineSeconds += effectiveSec;
  checkAchievements();

  return {
    elapsedSec:elapsedSec,
    effectiveSec:effectiveSec,
    earned:sim.lumenGained,
    shardEarned:sim.shardGained,
    sigilsEarned:sim.sigilsGained,
    motesEarned:sim.motesGained,
    studySpeedPurchases:sim.studySpeedPurchases,
    studyMotesSpent:sim.studyMotesSpent,
    ascends:sim.ascends,
    completedStudies:sim.completedStudies,
    closedStudies:sim.closedStudies,
    retreated:sim.retreated,
    endDepth:state.depth,
    pushDepth:progressionDepth(),
    kills:sim.kills,
    iterations:sim.iterations,
    fastForwardedKills:sim.fastForwardedKills
  };
}

function fmtDuration(sec){
  sec = Math.floor(sec);
  var h = Math.floor(sec/3600), m = Math.floor((sec%3600)/60);
  if(h>0) return h+'h '+m+'m';
  if(m>0) return m+'m';
  return Math.max(1,sec)+'s';
}

var STARTUP_INTRO_KEY = 'lumenfall_startup_intro_last';
var STARTUP_INTRO_COOLDOWN_MS = 3 * 60 * 60 * 1000;
var startupIntroTimers = [];
var startupIntroPlaying = false;
var startupIntroFinish = null;

function clearStartupIntroTimers(){
  startupIntroTimers.forEach(function(timer){ clearTimeout(timer); });
  startupIntroTimers = [];
}
function shouldShowStartupIntro(){
  if(isNewGame) return true;
  try{
    var last = parseInt(localStorage.getItem(STARTUP_INTRO_KEY)||'0',10);
    return !last || (Date.now()-last)>=STARTUP_INTRO_COOLDOWN_MS;
  }catch(e){
    return true;
  }
}
function markStartupIntroShown(){
  try{ localStorage.setItem(STARTUP_INTRO_KEY,String(Date.now())); }catch(e){}
}
function playStartupIntro(done){
  var intro = document.getElementById('startup-intro');
  if(!intro || !shouldShowStartupIntro()){
    if(done) done();
    return;
  }

  clearStartupIntroTimers();
  startupIntroPlaying = true;
  var finished = false;

  function finish(){
    if(finished) return;
    finished = true;
    startupIntroPlaying = false;
    startupIntroFinish = null;
    intro.onpointerdown = null;
    document.getElementById('startup-skip').onclick = null;
    clearStartupIntroTimers();
    markStartupIntroShown();
    intro.classList.add('is-leaving');
    intro.setAttribute('aria-hidden','true');
    setTimeout(function(){
      intro.className = 'startup-intro';
      closeOverlay(intro);
      if(done) done();
    },430);
  }

  intro.className = 'startup-intro is-visible phase-brand';
  intro.setAttribute('aria-hidden','false');
  startupIntroFinish = finish;

  intro.onpointerdown = finish;
  document.getElementById('startup-skip').onclick = finish;
  openOverlay(intro,finish);

  var reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if(reduced){
    startupIntroTimers.push(setTimeout(function(){
      intro.className = 'startup-intro is-visible phase-game';
    },220));
    startupIntroTimers.push(setTimeout(finish,1050));
    return;
  }

  startupIntroTimers.push(setTimeout(function(){
    intro.className = 'startup-intro is-visible phase-rift';
  },1320));
  startupIntroTimers.push(setTimeout(function(){
    intro.className = 'startup-intro is-visible phase-game';
  },1640));
  startupIntroTimers.push(setTimeout(finish,3250));
}

function hasMeaningfulOfflineProgress(offline){
  return !!(offline && (offline.earned>1 || offline.completedStudies.length || offline.closedStudies.length || offline.ascends>0 || offline.shardEarned>1 || offline.sigilsEarned>0 || offline.motesEarned>0));
}
function offlineReturnMessage(offline){
  var msg = 'You were away for ' + fmtDuration(offline.elapsedSec) + '. Your Wisps kept the Rift lit and gathered ' + formatNum(offline.earned) + ' Lumen' +
    (offline.shardEarned>1 ? ' and ' + formatNum(offline.shardEarned) + ' Shards' : '') +
    (offline.sigilsEarned>0 ? ' and ' + formatNum(offline.sigilsEarned) + ' Sigils' : '') +
    (offline.motesEarned>0 ? ' and ' + formatNum(offline.motesEarned) + ' Motes' : '') + ' while you were gone.';
  if(offline.ascends>0){ msg += ' They ascended ' + offline.ascends + ' time' + (offline.ascends===1?'':'s') + ' on their own!'; }
  if(offline.retreated){ msg += ' After the Boss remained an impossible wall for 5 minutes offline, they switched to Farm at Rift ' + offline.endDepth + '. Your Push point at Rift ' + offline.pushDepth + ' is still saved.'; }
  if(offline.completedStudies.length===1){ msg += ' Your Long Study "' + offline.completedStudies[0] + '" finished while you were away!'; }
  else if(offline.completedStudies.length>1){ msg += ' Your Long Studies "' + offline.completedStudies.join('", "') + '" finished while you were away!'; }
  if(offline.closedStudies.length){ msg += ' Paid work for "'+offline.closedStudies.join('", "')+'" finished with the level cap already reached; no additional levels were earned.'; }
  return msg;
}
function showReturnFlow(offline,dailyWasRolled){
  function maybeShowDaily(){
    if(dailyWasRolled && pendingDailyReward){ showDailyOverlay(pendingDailyReward); }
  }

  if(hasMeaningfulOfflineProgress(offline)){
    var welcomeOverlay = document.getElementById('welcome-overlay');
    document.getElementById('welcome-text').textContent = offlineReturnMessage(offline);
    document.getElementById('welcome-claim').onclick = function(){
      closeOverlay(welcomeOverlay);
      renderAll();
      maybeShowDaily();
    };
    openOverlay(welcomeOverlay,function(){ document.getElementById('welcome-claim').click(); });
  } else {
    maybeShowDaily();
  }
}

function init(){
  cacheEls();
  try{ riftGuidanceHidden=localStorage.getItem(RIFT_GUIDANCE_HIDDEN_KEY)==='1'; }catch(e){ riftGuidanceHidden=false; }
  state = loadState();
  if(state.owned.rememberbulk && state.savedLabMultiplier!==undefined){ labMultiplier = state.savedLabMultiplier; }
  var dailyRolled = ensureDaily();
  restoreEnemyOrSpawn();
  setupTabs();
  setupOverlayFocus();
  syncMainScrollMode();
  setupStars();

  var stageEl = document.getElementById('enemy-stage');
  var recentTapTimes = [];
  var MAX_TAPS_PER_SEC = 20;
  function guardianInput(e){
    if(!e.isTrusted) return;
    var now = Date.now();
    recentTapTimes.push(now);
    while(recentTapTimes.length && now - recentTapTimes[0] > 1000) recentTapTimes.shift();
    if(recentTapTimes.length > MAX_TAPS_PER_SEC) return;
    doTap(stageEl);
  }
  stageEl.addEventListener('pointerdown',function(e){ e.preventDefault(); guardianInput(e); });
  stageEl.addEventListener('click',function(e){ if(e.detail===0) guardianInput(e); });
  stageEl.addEventListener('keydown',function(e){ if(e.repeat && (e.key==='Enter' || e.key===' ')) e.preventDefault(); });

  document.getElementById('rift-push-btn').addEventListener('click', enterPushMode);
  document.getElementById('rift-farm-btn').addEventListener('click', enterFarmMode);
  document.getElementById('rift-objective').addEventListener('keydown',function(e){
    if(this.getAttribute('role')==='button' && (e.key==='Enter' || e.key===' ')){
      e.preventDefault(); if(!e.repeat) this.click();
    }
  });
  document.getElementById('rift-objective').addEventListener('click', function(){
    var target = this.getAttribute('data-target-tab');
    if(target) activateTab(target);
  });
  document.getElementById('rift-objective-dismiss').addEventListener('click',function(){ setRiftGuidanceHidden(true); });
  document.getElementById('rift-guidance-toggle').addEventListener('click',function(){ setRiftGuidanceHidden(!riftGuidanceHidden); });
  document.getElementById('ascend-btn').addEventListener('click', function(){ doAscend(false); });

  document.getElementById('settings-btn').addEventListener('click', openSettings);
  document.getElementById('settings-close').addEventListener('click', closeSettings);
  document.getElementById('settings-back').addEventListener('click', function(){ showSettingsView('home'); });
  document.getElementById('encyclopedia-btn').addEventListener('click', function(){ showSettingsView('encyclopedia'); });
  document.getElementById('save-backup-btn').addEventListener('click', function(){ showSettingsView('backup'); });
  document.getElementById('copy-save-backup').addEventListener('click', copyCurrentSaveBackup);
  document.getElementById('restore-save-backup').addEventListener('click', restoreSaveBackup);
  document.getElementById('settings-overlay').addEventListener('click', function(e){ if(e.target===this) closeSettings(); });
  document.getElementById('howtoplay-btn').addEventListener('click', function(){ closeSettings(); showTutorial(); });
  document.getElementById('reset-btn').addEventListener('click', function(){
    document.getElementById('reset-row').style.display = 'none';
    document.getElementById('reset-confirm-row').style.display = 'block';
    document.getElementById('reset-cancel-btn').focus();
  });
  document.getElementById('reset-cancel-btn').addEventListener('click', function(){
    document.getElementById('reset-row').style.display = 'block';
    document.getElementById('reset-btn').focus();
    document.getElementById('reset-confirm-row').style.display = 'none';
    document.getElementById('reset-row').style.display = 'block';
  });
  document.getElementById('reset-confirm-btn').addEventListener('click', function(){
    performReset();
    document.getElementById('reset-confirm-row').style.display = 'none';
    document.getElementById('reset-row').style.display = 'block';
  });

  applyRiftTheme();
  renderAll();
  announcePersistenceStatus();

  var welcomeOverlay = document.getElementById('welcome-overlay');

  if(isNewGame){
    playStartupIntro(function(){
      isNewGame = false;
      state.lastSeen = Date.now();
      saveState();
      if(pendingDailyReward && pendingDailyReward.reward){
        var welcomeComets = pendingDailyReward.reward.comets||0;
        if(welcomeComets>0) showToast('Welcome gift — +'+welcomeComets+' Comets');
      }
      showRiftMilestone('FIRST GOAL','Reach Rift 3','Awaken Tide Sprite','#3aa0c9');
    });
  } else {

    // Apply offline progress before any startup save can advance lastSeen.
    var offline = applyOfflineProgress();
    saveState();

    renderAll();
    playStartupIntro(function(){
      showReturnFlow(offline,dailyRolled);
    });
  }

  setInterval(tick, TICK_MS);
  setInterval(function(){
    if(!document.hidden) saveState();
  }, 5000);

  var appHiddenAt = 0;
  var resumeFlowBusy = false;
  document.addEventListener('visibilitychange', function(){
    if(document.hidden){
      // Do not resume an interrupted milestone animation/banner on return.
      document.querySelectorAll('.rift-milestone,.vfx-boss-death').forEach(function(el){ el.remove(); });
      document.querySelector('#tab-battle .stage').classList.remove('impact-victory','impact-milestone','impact-boss');
      appHiddenAt = Date.now();
      saveState();
      return;
    }

    if(isNewGame || resumeFlowBusy || !appHiddenAt) return;
    var awayMs = Date.now()-appHiddenAt;
    appHiddenAt = 0;
    if(awayMs < 1000) return;

    resumeFlowBusy = true;
    var rolledOnResume = ensureDaily();
    var resumeOffline = applyOfflineProgress();
    saveState();
    renderAll();

    var settingsOverlay = document.getElementById('settings-overlay');
    if(settingsOverlay && settingsOverlay.style.display!=='none') closeSettings();

    playStartupIntro(function(){
      showReturnFlow(resumeOffline,rolledOnResume);
      resumeFlowBusy = false;
    });
  });
  window.addEventListener('beforeunload', function(){
    if(!resetInProgress && !reloadInProgress) saveState();
  });
  document.addEventListener('visibilitychange', function(){ document.body.classList.toggle('app-paused', document.hidden); });
  document.addEventListener('keydown', function(e){
    if(startupIntroPlaying && (e.key==='Escape' || e.key==='Enter' || e.key===' ')){
      if(startupIntroFinish) startupIntroFinish();
      return;
    }
    if(e.key==='Escape' && document.getElementById('settings-overlay').style.display!=='none') closeSettings();
  });
}

if(document.readyState==='loading'){
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
})();
