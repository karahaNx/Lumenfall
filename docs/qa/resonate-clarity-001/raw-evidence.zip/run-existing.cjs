/* Runs unchanged repo scenarios through the explicitly recorded CDP adapter. */
const fs=require('node:fs'),path=require('node:path'),{spawnSync}=require('node:child_process');
const root=path.resolve(process.argv[2]),out=path.resolve(__dirname);
const cases=[
 ['p2-endgame-currency-utility',0],['chronology-simultaneous-order',0],
 ['parity-short',0],['parity-auto-ascend',0],['restore-roundtrip',0],
 ['recovery-offline-once',0],['p2-03b-auto-ascend-integrity',0],
 ['self-test-endgame-currency-regression',1],['self-test-parity-regression',1],
 ['self-test-chronology-regression',1]
];
const records=[];
for(const [scenario,expectedExit] of cases){
 const log=path.join(out,scenario+'.log'),fd=fs.openSync(log,'w');
 const result=spawnSync(process.execPath,['tests/behavioral/run.cjs','--web-root','.','--scenario',scenario,'--raw-artifacts',path.join(out,'failed-processes')],{
  cwd:root,env:{...process.env,PATH:path.join(out,'cdp-bin')+path.delimiter+process.env.PATH,RESONATE_CDP_RAW:path.join(out,'raw-dom')},stdio:['ignore',fd,fd],timeout:45000
 });fs.closeSync(fd);
 const text=fs.readFileSync(log,'utf8'),marker=expectedExit===0?'PASS '+scenario:'FAIL '+scenario;
 const ok=result.status===expectedExit&&text.includes(marker);
 records.push({scenario,expectedExit,exit:result.status,signal:result.signal,error:result.error?.message,ok,log:path.basename(log)});
 console.log(JSON.stringify(records.at(-1)));
 if(!ok)process.exitCode=1;
}
fs.writeFileSync(path.join(out,'existing-results.json'),JSON.stringify({adapter:'chromium-cdp.cjs',status:records.every(x=>x.ok)?'pass':'fail',records},null,2)+'\n');
