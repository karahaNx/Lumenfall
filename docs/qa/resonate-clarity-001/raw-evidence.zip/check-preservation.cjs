const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{execFileSync}=require('node:child_process');
const root=path.resolve(process.argv[2]),cwd={cwd:root},base='0bcce84d0b5c3c47daa2b16235311f48b1ab0bfd';
const original=execFileSync('git',['show',base+':index.html'],cwd).toString(),candidate=fs.readFileSync(path.join(root,'index.html'),'utf8');
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
const names=['canSigilResonate','useSigilResonance','allUltimatesOwned','applyAscendMutation','normalizeCurrentSave','loadState','saveState','currentSaveBackup','decodeSaveBackup','restoreSaveBackup','motesDropFor','sigilsFromBoss','advanceAuthoritativeTime'];
const functions=names.map(name=>{const re=new RegExp('function '+name+'\\([^]*?\\n\\}');const before=original.match(re)?.[0],after=candidate.match(re)?.[0];if(!before||before!==after)throw Error('Changed/missing mechanic '+name);return {name,sha256:hash(before),unchanged:true};});
const tracked=execFileSync('git',['ls-files','mobile','tests','scripts','.github','fonts','branding'],cwd).toString().trim().split('\n');
// Comparing Git blobs includes all existing tracked files; the new JS test is
// excluded because it did not exist in the baseline.
const requests=tracked.map(file=>base+':'+file).join('\n')+'\n';
const git=execFileSync('git',['cat-file','--batch-check=%(objectname)'],{...cwd,input:requests}).toString().trim().split('\n');
const now=execFileSync('git',['hash-object','--stdin-paths'],{...cwd,input:tracked.join('\n')+'\n'}).toString().trim().split('\n');
const changed=tracked.filter((file,i)=>now[i]!==git[i]);if(changed.length)throw Error('Changed preserved files: '+changed.join(', '));
const result={status:'pass',baseline:base,baselineIndex:{blob:execFileSync('git',['rev-parse',base+':index.html'],cwd).toString().trim(),sha256:hash(original)},candidateIndex:{blob:execFileSync('git',['hash-object','index.html'],cwd).toString().trim(),sha256:hash(candidate)},functions,existingFilesCompared:tracked.length,changedPreservedFiles:changed};
fs.writeFileSync(path.join(__dirname,'preservation.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
