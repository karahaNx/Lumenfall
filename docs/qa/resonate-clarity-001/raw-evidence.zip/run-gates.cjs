const fs=require('node:fs'),path=require('node:path'),{spawnSync}=require('node:child_process');
const root=path.resolve(process.argv[2]),out=__dirname,records=[];
for(const [name,args] of [['source',['scripts/ci/validate_source.cjs']],['context',['scripts/codex/check_context.cjs']],['apk-self-test',['scripts/verify_apk_identity.cjs','--self-test']],['tooling',['tests/tooling/run.cjs']]]){
 const result=spawnSync(process.execPath,args,{cwd:root,encoding:'utf8',timeout:60000,stdio:['ignore','pipe','pipe']});
 fs.writeFileSync(path.join(out,name+'.log'),result.stdout+result.stderr);
 records.push({name,command:['node',...args],exit:result.status,signal:result.signal,error:result.error?.message});
 if(result.status!==0)process.exitCode=1;
}
fs.writeFileSync(path.join(out,'gate-results.json'),JSON.stringify(records,null,2)+'\n');console.log(JSON.stringify(records));
