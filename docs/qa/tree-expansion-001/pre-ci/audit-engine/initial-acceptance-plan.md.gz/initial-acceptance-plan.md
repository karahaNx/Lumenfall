# Tree expansion — CI and evidence acceptance plan

Audit date: 2026-10-10. Baseline: `2d01049393e3bb45a90d80e07af52ae0484b0ec5`.
This audit first inspected GitHub and the immutable baseline. Root then authorized exactly two workflow edits: the new Tree workflow and raw negative-control capture in Full. No gameplay test, CI rerun, commit, remote write or APK action was performed by this audit.

## 1. Actual workflow coverage

The anticipated Lab/Forge head-branch restriction is absent at this baseline. Their GitHub workflow blobs are `d5e5778bc4819fa5bc1d162a9c9362ed68051199` and `5e4fe1d5bdaee84a811f4e9339f695fa5a9c3196`; neither contains a job `if` or a path filter. A new `feature/tree-expansion-001` PR targeting `feature/progression-expansion-2026-10-09` therefore runs both without any filter edits.

| Workflow | Tree PR to dev | Required disposition |
|---|---|---|
| Pre-merge validation | Runs; target-branch filter matches | All existing gates and all 22 negatives complete successfully |
| Research Lab expansion validation | Runs; no head filter | Complete core, boundary, stress, Prism state, mobile and actual V8 |
| Rift Forge expansion validation | Runs; no head filter | Complete core, calibration, offline, mobile and actual V8 |
| New `tree-focused-qa.yml` | Runs; no head/path filter | Tree-specific tests plus specialized Prism coverage below |
| Prism feature / Prism closeout | Their jobs skip: `head_ref == feature/prism-earning-001` | Do not count these skipped jobs as executed coverage; their relevant specialized checks are carried into Tree |
| Lab scroll diagnostic / Prism integration recheck | Their push-branch/path conditions do not match | Existing full-suite scroll and purchase cases remain mandatory; no diagnostic rerun is requested |
| Android build/release | Main push or manual dispatch only | Held; no main update or dispatch |

GitHub's [pull-request branch filters](https://docs.github.com/en/actions/reference/workflows-and-actions/workflow-syntax) match the target branch. A [conditionally skipped job](https://docs.github.com/en/actions/how-tos/write-workflows/choose-when-workflows-run/control-jobs-with-conditions) can report success, so acceptance checks job and step execution, not only a green aggregate badge. This plan defines project gates; it does not claim repository branch-protection settings were inspected.

## 2. Verified GitHub baseline

PR102 is open and draft, with head `2d01049393e3bb45a90d80e07af52ae0484b0ec5` and main/base `67373faa531f0bb791c883210ee623320861e380`. Dev and PR102 synthetic merge `23536cf0588e95fd40b254e6413de402d74d4664` share tree `dd9e503000291554af6e93c294d99d475a09612f`. Baseline source SHA256 is `05742431ab6bffefce09d0bebefa754190ed836cc51f4aeeb81e8a9d769419ac`.

| Baseline run | Job | Terminal API result | Every reported step |
|---|---:|---|---|
| [Full 38049484284](https://github.com/karahaNx/Lumenfall/actions/runs/38049484284) | 114205552099 | completed / success | 18 / 18 success |
| [Lab 38049484492](https://github.com/karahaNx/Lumenfall/actions/runs/38049484492) | 114205552749 | completed / success | 11 / 11 success |
| [Forge 38049484322](https://github.com/karahaNx/Lumenfall/actions/runs/38049484322) | 114205552303 | completed / success | 13 / 13 success |

All three are first-attempt `pull_request` runs on the exact dev head above. Their raw API responses are adjacent to this plan. No artifacts from these three baseline runs were downloaded in this audit. The independently saved positive inventory comes from the previously accepted, equal-tree Forge run `38047024745`: **182 scenarios, 212 distinct PASS rows, zero FAIL**. Its preserved log is 10,378,834 bytes, SHA256 `1b2aa9d95f37aa213d3b78a9912fefe58d5b8d3ccf2fda773da06eedaad51f02`. This historical raw receipt is kept distinct from the newer API-only observations.

## 3. Minimal implemented Tree workflow

`Lumenfall-tree/.github/workflows/tree-focused-qa.yml` contains one Node 20 job, a 35-minute ceiling, read-only token permissions, per-PR concurrency, default synthetic-merge checkout and no head/path filter. It records commit, tree, parents, source/fixture hashes and source blob inventory. It validates source and `TREE_EXPANSION_001.md` context, then directly invokes these forthcoming entry points:

| Tree entry point | Required acceptance contract |
|---|---|
| `tree-expansion-core.cjs index.html --negative` | At least 20 meaningful exclusive tracks; independent prices, unlocks and caps; real one-time purchase/debit; rejection of unaffordable/capped/invalid purchases; every new effect; paid-value retention; save/backup/recovery/Resonate/Ascend; causal mutants |
| `tree-expansion-offline.cjs index.html` | New-owned and zero-new behavior through actual online/offline chronology, queues, active Lab snapshots, Forge effects and Auto-Ascend; independent boundaries and split/catch-up checks; frozen old fixtures retained |
| `tree-expansion-mobile.cjs index.html tree-validation/mobile` | All tracks and actual touch/keyboard purchases; 320/390/430 widths × normal/double text × both motion preferences; correct currency prices/colors, eligibility, locks/caps, focus/scroll stability, persistence, no clipping/runtime errors |
| `tree-expansion-v8.cjs index.html` | Full product parsing and actual Tree/save/Ascend behavior on verified Node 8.3.0 / V8 6.0; no modern-engine substitute or product BigInt dependency |

Missing entry points are intentional development blockers and fail the job; there is no optional execution fallback. Implementation owners must finalize the CLI contracts and test files before publishing the candidate. Zero-new differential checks must compare actual baseline production behavior with the new source; observer wrappers may observe original calls but must not replace production economics or timing.

The same job runs existing `prism-closeout-data.cjs`, `prism-earning-focused.cjs`, `prism-acceptance.cjs` and `prism-legacy-runtime.cjs`. One checksum-verified old-runtime installation serves Tree and Prism. This covers the specialized Prism jobs that skip Tree without duplicating the complete Lab/Forge suites. UI/V8 evidence and upload use `if: always()`; this does not turn an earlier failure into success.

**Swift follow-through:** the existing ROI matrix measures actual next/bundle prices and reward gains at Clear20/50/119/250/1000, Lab0/10/20 and Swift levels through50. It does not assert an agreed late-price/ROI target, and its current scope text says “no price changes.” If Tree changes Swift prices, update the narrow matrix/source adapter and scope accurately, while adding an independent Tree price/ROI oracle for the new policy. Keep marginal and first-useful-bundle payback explicit; do not present fixed-depth Ascend counts as elapsed campaign time. Preserve all five payout mutation controls and real purchase/save checks.

## 4. Complete mandatory gate set on the final Tree candidate

| Gate | Required executed content |
|---|---|
| Full | APK identity **tooling self-test only**; Node tooling suite; source validation; staged web assets; Rift cosmetics with negatives; exact Prism earning; Prism/progression context; collection-price UI with negatives; complete default stateful suite; exactly all 22 named negative controls; installed runtime guard and real browser smoke |
| Lab | `lab-expansion.cjs --negative`, `lab-expansion-boundary.cjs --negative`, `lab-expansion-stress.cjs`, `prism-earning-state.cjs`, complete `lab-expansion-ui.cjs`, actual V8 `lab-expansion-legacy.cjs` |
| Forge | `forge-expansion.cjs --negative`, `forge-expansion-calibration.cjs --negative`, full `offline-catchup.cjs`, complete `forge-expansion-ui.cjs`, actual V8 `forge-expansion-legacy.cjs` |
| Tree | All four new entry points and all four specialized Prism checks above, source/context identity, always-preserved raw evidence |

All tests execute against the same final candidate checkout; historical green runs cannot substitute. Retain the exact existing 182-scenario/212-positive-row inventory in `baseline-positive-inventory.json`. Explicit additional cases may increase it; any deliberate assertion adaptation must preserve the underlying causal contract and be reviewed, rather than using counts as a replacement for coverage. Require zero FAIL rows and no timeout, missing receipt, unexpected negative success or skipped required step. Maintain the three historical native-scroll cases (`rift-status-stacking-mobile`, `rift-status-stacking-reduced-motion`, `rift-status-reduced-motion`) and their actual exit/timeout observations. Do not lower their proven scenario timeouts or substitute synthetic scrolling.

Keep frozen `fixtures.json` unchanged (baseline SHA256 recorded in `baseline-audit.json`). Preserve old paid identifiers/levels and effects, absent-new-key defaults, active work, wallets, progression, actual Auto-Ascend and save formats. New feature-level causal tests are additional to the 22 global negatives, Lab/Forge mutants and Prism controls.

## 5. Raw evidence and strict negative capture

The sole Full-workflow change wraps its unchanged 22-name loop in `2>&1 | tee validation-evidence/negative-self-tests.log`, retaining `set -euo pipefail`, the existing `if` and fatal `exit 1`. Each negative also writes existing harness raw records below `validation-evidence/negative-raw`; the existing always-uploaded artifact already includes this directory. Names and order are frozen in `required-negative-controls.json`.

For acceptance, require all 22 caught messages, no unexpected success, and the expected defect evidence for every control. The deliberately uncaught-error/unhandled-rejection tests are allowed their declared injected error; other failures must not be explained by an unrelated crash, missing mutation anchor or transport timeout. The five focused Prism negatives already require completed in-page assertion evidence and reject those false positives. Preserve controller exit, browser process exit, timeout status, QA payload, stderr and screenshots where produced.

Pin the **new** immutable Full-workflow blob for the final head; the historical `5cddd8599a23ba2fb823b75f471df3e16e721e86` no longer describes the edited workflow. The local verified candidate blob is `4c67564c7d30a51f618eb76f286cc34a4bf4f6d0`. Verify the published blob independently before trusting a later raw-count audit.

For every final workflow, retain run/job/artifact API metadata and completed job/step states. Download only the new completed artifacts; verify API ZIP byte count and SHA256, CRC, commit/source identity, tree/parents and required file inventory before interpreting results. Save failed runs as explicitly FAILED history. Preserve original log/text/JSON bytes using lossless gzip with original/stored lengths and SHA256; do not silently trim whitespace. Keep screenshots and safe QA payloads. Exclude full product HTML/DOM copies and private saves from the durable repository package, recording omitted original hashes and the provenance of any extracted QA JSON. Raw ZIPs may remain in scratch. Record actual UTC from `clock__curr_time`, not the executor wall clock.

## 6. Integration and practical limits

Before integration, root rechecks actual PR head/base, synthetic merge commit/tree/parents, all four completed candidate gates, reviews/requested changes, mergeability and unchanged main. Merge only the tested tree into dev; then bind bounded post-merge checks to the actual merge source and inspect the resulting PR102 statuses. Source/base movement invalidates acceptance unless the new combined candidate is verified. Device update, native Android WebView60, TalkBack, signing, APK creation and release remain outside this development acceptance.

The workflow edits passed YAML parsing, bash syntax, structural preservation checks and three isolated negative-loop shell probes: all22 expected failures succeed, an unexpected success fails and stops the loop, and an evidence sink failure fails. These are **76 workflow checks**, not gameplay regression results. See `workflow-verification.json` and its JavaScript verifier for exact hashes and limits.
