import ast
import contextlib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import yaml

HERE = Path(__file__).parent
OUTPUT = HERE.parent/'actions-metadata-evidence'/'local-validation'
payload = (HERE/'diagnose_payload.py').read_text()
compile(payload, 'embedded_metadata_payload.py', 'exec')
header = '''name: Signing metadata diagnose 131

# Temporary metadata-only workflow. Retain the branch until Lead decides cleanup.
'on':
  push:
    branches: ['01/signing-metadata-diagnose-131']
    paths: ['.github/workflows/signing-metadata-diagnose.yml']

permissions:
  contents: write
  actions: write

concurrency:
  group: lumenfall-signing-metadata-diagnose-131
  cancel-in-progress: false

jobs:
  signing-metadata:
    runs-on: ubuntu-latest
    timeout-minutes: 5
    env:
      GH_TOKEN: ${{ github.token }}
      GH_PROMPT_DISABLED: '1'
    steps:
      - name: Read and verify signing metadata in three rounds
        shell: bash
        run: |
          set -euo pipefail
          python3 - <<'PY'
'''
workflow = header + ''.join('          '+line+'\n' for line in payload.splitlines()) + '          PY\n'
path = HERE/'.github/workflows/signing-metadata-diagnose.yml'
path.write_text(workflow)
parsed = yaml.safe_load(workflow)
assert set(parsed) == {'name','on','permissions','concurrency','jobs'}
assert parsed['on'] == {'push': {'branches':['01/signing-metadata-diagnose-131'], 'paths':['.github/workflows/signing-metadata-diagnose.yml']}}
assert parsed['permissions'] == {'contents':'write','actions':'write'}
assert parsed['concurrency'] == {'group':'lumenfall-signing-metadata-diagnose-131','cancel-in-progress':False}
assert set(parsed['jobs']) == {'signing-metadata'}
job = parsed['jobs']['signing-metadata']
assert job['runs-on'] == 'ubuntu-latest' and job['timeout-minutes'] == 5
assert job['env'] == {'GH_TOKEN':'${{ github.token }}','GH_PROMPT_DISABLED':'1'}
assert len(job['steps']) == 1 and 'uses' not in job['steps'][0]
script = job['steps'][0]['run']
subprocess.run(['bash','-n'],input=script,text=True,check=True,capture_output=True)
embedded = script.split("python3 - <<'PY'\n",1)[1].rsplit('PY\n',1)[0]
assert embedded == payload
compile(embedded,'extracted_metadata_payload.py','exec')
tree = ast.parse(embedded)
assert '"mutation' not in embedded and 'application/octet-stream' not in embedded
assert 'gh", "release", "download' not in embedded
assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id in ('eval','exec','open') for n in ast.walk(tree))
spec = importlib.util.spec_from_file_location('metadata_payload',HERE/'diagnose_payload.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
assert module.REQUEST_TIMEOUT == 6 and module.CLI_TIMEOUT == 20
assert module.QUERY.startswith('query LumenfallSigningMetadataV1') and 'mutation' not in module.QUERY
assert module.NoRedirect().redirect_request(None,None,302,'',{},'https://forbidden.invalid/key') is None

# One positive fixture, containing all expected response shapes and hostile unused fields.
markers = ['PRIVATE_URL_MARKER','SECRET_TOKEN_MARKER','PRIVATE_BODY_MARKER','PRIVATE_COOKIE_MARKER']
private_url = 'https://private.invalid/key?sig=PRIVATE_URL_MARKER'
headers = {'X-GitHub-Request-Id':'A1B2:C3:D4:E5','Authorization':'Bearer SECRET_TOKEN_MARKER','Location':private_url,'Set-Cookie':'PRIVATE_COOKIE_MARKER'}
release = {'id':module.RELEASE_ID,'draft':True,'tag_name':module.TAG,'body':'PRIVATE_BODY_MARKER','html_url':private_url}
asset = {**module.expected_asset(),'url':private_url,'browser_download_url':private_url,'uploader':{'token':'SECRET_TOKEN_MARKER'}}
graphql_release = {'databaseId':module.RELEASE_ID,'isDraft':True,'tagName':module.TAG,'body':'PRIVATE_BODY_MARKER'}
positive = {
    'release':module.filter_response('release',200,headers,release),
    'asset':module.filter_response('asset',200,headers,asset),
    'assets':module.filter_response('assets',200,headers,[asset]),
    'graphql':module.filter_response('graphql',200,headers,{'data':{'repository':{'release':graphql_release}}}),
}
assert positive['release']['data'] == module.expected_release()
assert positive['graphql']['data'] == module.expected_release()
assert positive['asset']['data'] == module.expected_asset()
assert positive['assets']['data'] == {'count':1,'assets':[module.expected_asset()]}
assert all(module.good_response(x) for x in positive.values())

# One access/GraphQL-error fixture: HTTP200 must fail when GraphQL errors exist.
negative_graphql = {'data':{'repository':{'release':None}},'errors':[{'type':'FORBIDDEN','message':'Resource not accessible SECRET_TOKEN_MARKER '+private_url,'path':[private_url],'extensions':{'code':'FORBIDDEN','private':'PRIVATE_BODY_MARKER'}}]}
negative = {
    'graphql':module.filter_response('graphql',200,headers,negative_graphql),
    'access':module.filter_response('release',403,headers,{'message':'Bad credentials SECRET_TOKEN_MARKER','documentation_url':private_url}),
    'redirect':module.filter_response('asset',302,headers,{'location':private_url}),
    'extra_asset':module.filter_response('assets',200,{**headers,'Link':'<'+private_url+'>; rel="next"'},[asset,{'id':42,'name':private_url,'url':private_url}]),
}
assert negative['graphql']['errors_count'] == 1 and not module.good_response(negative['graphql'])
assert not module.good_response(negative['access']) and not module.good_response(negative['redirect'])
assert negative['extra_asset']['has_next_page'] and not module.good_response(negative['extra_asset'])
assert negative['extra_asset']['data'] != {'count':1,'assets':[module.expected_asset()]}
captured = io.StringIO()
with contextlib.redirect_stdout(captured):
    module.emit('fixture_positive',0,positive)
    module.emit('fixture_negative',0,negative)
output = captured.getvalue()
for marker in markers:
    assert marker not in output,marker
for field in ['Authorization','Location','Cookie','Set-Cookie','browser_download_url','documentation_url','PRIVATE_URL_MARKER']:
    assert field not in output,field
report = {
    'yaml':'PASS','bash_syntax':'PASS','embedded_python':'PASS','embedded_bytes_match':'PASS',
    'single_branch_path_push_only':'PASS','single_job_timeout_5':'PASS','permissions':'PASS',
    'no_checkout_build_key_download_artifact_upload':'PASS','no_redirect_following':'PASS',
    'positive_fixture':'PASS','access_graphql_error_fixture':'PASS','output_whitelist':'PASS',
    'request_timeout_seconds':6,'cli_timeout_seconds':20,
    'theoretical_operation_timeout_budget_seconds':185,
    'workflow_sha256':hashlib.sha256(workflow.encode()).hexdigest(),
    'payload_sha256':hashlib.sha256(payload.encode()).hexdigest(),
    'graphql_query_sha256':hashlib.sha256(module.QUERY.encode()).hexdigest(),
}
OUTPUT.mkdir(parents=True,exist_ok=True)
(OUTPUT/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
(OUTPUT/'filter-fixtures.log').write_text(output)
print(json.dumps(report,indent=2))
