# Kildepakke og evidensniveau

source/candidate indeholder alle seks ændrede filer ved exact kandidat.
source/base indeholder de fire tilsvarende ændrede basefiler. De to nye filer
findes ikke på base. Alle ti kildeblobs er valideret mod GitHubs Git-SHA1.
PR41_exact.patch er lokalt genereret af disse eksakte bytes og dækker seks filer.
Dette er en kildepakke, ikke et fuldt checkout og ikke workerens lokale workspace.

SOURCE_INDEX.tsv giver hele immutable base-/candidate-træets blobindeks til
målrettet opslag. evidence/live_complete.json er rå GitHub-receipt inkl. trees,
compare, PR-files og CI/jobs. evidence/live_final.json er en senere genkontrol
af main/head/Draft/CI. Udtræk relevante felter lokalt; læs ikke hele JSON i chatten.
references/pre-merge-validation.yml er uændret workflow fra exact base, valideret
mod både base og kandidat. Lokale testkommandoer følger den reference; ingen
manuel workflow-kørsel eller Android-build er en del af mandatet.

CI-grøn er observeret, ikke uafhængigt reproduceret af 00_09. Workerens egen
PR-beskrivelse og docs er ikke et autoritativt reviewresultat. Et uforanderligt
Git-commit beviser ikke, at workerens chat er stoppet, at dens lokale arbejde er
reddet, eller at writerlease er frigivet. Kandidaten er endnu ikke accepteret.

SHA256SUMS.json dækker alle ZIP-payloads undtagen manifestet selv; ZIP CRC og
hashdækning er verificeret. Integritet beviser ikke semantisk fuldstændighed.
