from pathlib import Path
import subprocess,os,json,time,hashlib,shutil,sys
R=Path(__file__).resolve().parent;O=R/'finish/pr40-evidence';stage=R/'finish/pr40-stage/index.html'
node=os.environ['CODEX_PRIMARY_RUNTIME_NODE'];driver=O/'review.cjs'
def run(name,label,expected_code,field=None,value=None):
 env=os.environ.copy();env['CORE40_ONLY']=name;t=time.monotonic();timed=False
 try:
  p=subprocess.run([node,str(driver)],env=env,capture_output=True,timeout=60);code=p.returncode;stdout=p.stdout;stderr=p.stderr
 except subprocess.TimeoutExpired as e:
  timed=True;code=None;stdout=e.stdout or b'';stderr=e.stderr or b''
 (O/(label+'.stdout.txt')).write_bytes(stdout);(O/(label+'.stderr.txt')).write_bytes(stderr)
 receipt={'exit_code':code,'process_timed_out':timed,'process_timeout_seconds':60,'elapsed_seconds':time.monotonic()-t,'argv':[node,str(driver)],'scenario':name,'label':label,'oracle':'REVIDERET ORACLE','driver_sha256':hashlib.sha256(driver.read_bytes()).hexdigest(),'stage_sha256':hashlib.sha256(stage.read_bytes()).hexdigest()}
 (O/(label+'.process.json')).write_text(json.dumps(receipt,indent=2))
 assert not timed and code==expected_code,receipt
 result=json.loads((O/(name+'.json')).read_text());shutil.copyfile(O/(name+'.json'),O/(label+'.json'))
 if expected_code==0:assert result['status']=='pass',result
 else:
  assert result['status']=='fail' and result['error'].startswith('Error: REVISED ORACLE full repeat state actual='),result
  assert result['snapshot']['state'][field]==value,(field,result['snapshot']['state'][field])
 print(label,'PASS' if code==0 else 'EXPECTED ASSERTION FAIL',round(receipt['elapsed_seconds'],3),flush=True)
 return receipt
baseline=stage.read_bytes();cases=['07-cross-'+str(c)+'-'+route for c in [43,55] for route in ['cold','visibility']]
receipts=[]
for name in cases:receipts.append(run(name,name+'.revised',0))
line=b'state.enemyHp = Math.max(0.0001,expectedMax*hpRatio);';assert baseline.count(line)==1
for label,statement,field,value in [
 ('extra-hp',b'state.enemyHp=6.400000000000002;','enemyHp',6.400000000000002),
 ('extra-target',b'state.autoAscendTargetDepth+=1;','autoAscendTargetDepth',45),
 ('extra-reward',b'state.prisms+=1;','prisms',24)]:
 injected=line+b'\n    if(savedHp===6.4&&savedMax===11&&sameDepth&&state.depth===1){'+statement+b'}'
 mutated=baseline.replace(line,injected);stage.write_bytes(mutated)
 shutil.copyfile(stage,O/(label+'.negative.html'))
 (O/(label+'.mutation.diff')).write_text(__import__('difflib').unified_diff if False else ''.join(__import__('difflib').unified_diff(baseline.decode().splitlines(True),mutated.decode().splitlines(True),fromfile='positive-stage',tofile=label+'-negative-stage')))
 try:receipts.append(run(cases[0],label+'.negative',1,field,value))
 finally:stage.write_bytes(baseline)
 assert stage.read_bytes()==baseline
 receipts.append(run(cases[0],label+'.source-restored-undo',0))
(O/'run-summary.json').write_text(json.dumps(receipts,indent=2))
assert stage.read_bytes()==baseline
print('All four revised cases and three negative/source-restored undo pairs completed.',flush=True)
