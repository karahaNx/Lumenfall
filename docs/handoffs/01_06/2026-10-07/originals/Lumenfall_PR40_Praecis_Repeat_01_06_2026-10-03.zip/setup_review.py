from pathlib import Path
import shutil,json,hashlib,difflib
root=Path(__file__).resolve().parent
out=root/'finish'/'pr40-evidence';out.mkdir(parents=True,exist_ok=True)
old=root/'prior/startup-own19/pr40-evidence'
shutil.copytree(root/'handoff/candidate/source',root/'startup-source',dirs_exist_ok=True)
prepare=(old/'prepare.py').read_text()
(out/'prepare.py').write_text(prepare)
original=(old/'review.cjs').read_text()
needle="const again=await cold(page);eq(again.boot.state,r.state,'repeat cold cannot repay study/Ascend');return {oracle:{clear,internal:clear+1,reward,kills:1,ascends:1,studyLevels:1,comets:15},input,snapshots:[r,again.boot]};"
replacement="""ok(r.state.enemyHp===6.4&&r.state.enemyMaxHp===11&&r.state.enemyDepth===1&&r.state.depth===1,'exact authorized HP fixture before repeat');
const expected=JSON.parse(JSON.stringify(r.state));expected.enemyHp=6.400000000000001;
const again=await cold(page);eq(again.boot.state,expected,'REVISED ORACLE full repeat state');eq(JSON.parse(again.boot.primary),expected,'REVISED ORACLE full repeat primary');eq(JSON.parse(again.boot.recovery),expected,'REVISED ORACLE full repeat recovery');
const stable=await cold(page);eq(stable.boot.state,expected,'projected state stable on additional zero-time reload');eq(JSON.parse(stable.boot.primary),expected,'stable full primary');eq(JSON.parse(stable.boot.recovery),expected,'stable full recovery');
return {oracleLabel:'REVIDERET ORACLE',oracle:{clear,internal:clear+1,reward,kills:1,ascends:1,studyLevels:1,comets:15,onlyAuthorizedProjection:{before:6.4,expected:6.400000000000001}},input,beforeRepeat:r,expected,repeat:again,additionalRepeat:stable,snapshots:[r,again.boot,stable.boot]};"""
assert original.count(needle)==1
driver=original.replace(needle,replacement)
(out/'review.cjs').write_text(driver)
(root/'finish/review-driver.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True),driver.splitlines(True),fromfile='prior/review.cjs',tofile='revised/review.cjs')))
tree=json.loads(json.loads((root/'finish/checkpoint-before/tree.json').read_text())['structuredContent']['content'])
rows=[]
for e in tree['tree']:
 if e['type']!='blob':continue
 p=root/'handoff/candidate/source'/e['path'];b=p.read_bytes();sha=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();assert sha==e['sha'],e['path']
 rows.append({'path':e['path'],'git_blob':sha,'sha256':hashlib.sha256(b).hexdigest()})
(root/'finish/source-identity.json').write_text(json.dumps(rows,indent=2))
print('Verified',len(rows),'live HEAD blobs; prepared local oracle-only diff.')
