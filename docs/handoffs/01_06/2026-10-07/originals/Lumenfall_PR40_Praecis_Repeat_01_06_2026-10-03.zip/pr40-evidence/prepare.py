from pathlib import Path
import importlib.util,sys,json,hashlib,shutil
R=Path(__file__).resolve().parent.parent;src=R.parent/'startup-source';sys.path.insert(0,str(src/'tests/behavioral'));sp=importlib.util.spec_from_file_location('runner40',src/'tests/behavioral/run.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
pre=m.build_prelude(json.load(open(src/'tests/behavioral/fixtures.json')))
extra=r'''
window.__core40={
 snapshot:function(){return {state:JSON.parse(JSON.stringify(state)),primary:localStorage.getItem(SAVE_KEY),recovery:localStorage.getItem(RECOVERY_SAVE_KEY),events:JSON.parse(JSON.stringify(qaLifecycleEvents)),status:persistenceStatus(),flags:{reloadInProgress:reloadInProgress,resetInProgress:resetInProgress},errors:window.__lumenfallQaContext.errors.slice(),select:els['shop-list']?Array.from(els['shop-list'].querySelectorAll('[data-autoascend-target]')).map(function(s){return {value:s.value,options:Array.from(s.options).map(function(o){return {value:o.value,text:o.textContent};})};}):[]};},
 canonical:function(s){return acceptPersistedState(s,'core40');},
 input:setAutoAscendClearedTarget,check:checkAutoAscend,manual:function(){return doAscend(false);},
 backup:currentSaveBackup,decode:decodeSaveBackup,
 render:function(){renderShop();checkAffordability();renderAll();},
 save:saveState,tick:tick,
 ready:function(){return !startupIntroPlaying&&!isNewGame;},
 achievementIds:function(){return ACHIEVEMENTS.map(function(a){return a.id;});},
 timeline:function(seconds,kind,start){var r=advanceAuthoritativeTime(seconds,{kind:kind,visual:false,clockStartMs:start,captureTimeline:true});return {summary:r,state:JSON.parse(JSON.stringify(state))};}
};
document.addEventListener('DOMContentLoaded',function(){window.__core40.boot=window.__core40.snapshot();});
'''
source=(src/'index.html').read_text();mark='\n})();\n</script>\n<script>\nif(window.Capacitor';assert source.count(mark)==1
page=source.replace('<head>','<head>\n'+pre,1).replace(mark,'\n'+m.build_bridge()+extra+mark,1)
mut=r'''var core40OriginalLoader=loadState;
loadState=function(){var result=core40OriginalLoader();if(result.owned.autoascend)result.autoAscendTargetDepth=16;return result;};
'''
negative=page.replace('window.__core40={',mut+'window.__core40={',1)
s=R/'pr40-stage';s.mkdir(exist_ok=True);(s/'index.html').write_text(page);(s/'negative.html').write_text(negative)
for folder in ['fonts','branding']:shutil.copytree(src/folder,s/folder,dirs_exist_ok=True)
(R/'pr40-evidence/instrumentation-hashes.json').write_text(json.dumps({'source':hashlib.sha256(source.encode()).hexdigest(),'positive_stage':hashlib.sha256(page.encode()).hexdigest(),'negative_stage':hashlib.sha256(negative.encode()).hexdigest(),'mutation':mut,'measurement':'No automatic interval pause. Boot snapshot at DOMContentLoaded immediately after genuine init; cold/visibility reads are unmodified handler results.'},indent=2))
print('staged')
