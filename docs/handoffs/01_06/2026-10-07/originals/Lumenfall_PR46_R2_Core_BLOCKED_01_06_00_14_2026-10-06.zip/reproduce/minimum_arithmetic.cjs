const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync(process.argv[2]||(__dirname+'/head/index.html'),'utf8');
const body=source.slice(source.indexOf('function simulationApplyFarmPassive('),source.indexOf('function simulationPassiveKillSeconds('));
const D=2**55+16,H=11,expected=Number(BigInt(D)/11n),state={enemyMaxHp:H,enemyHp:H,depth:1};let kills=0;
const context={state,SIM_EPS:1e-9,enemyHpFor:()=>H,simulationBatchFarmKills:n=>{kills=n;state.enemyHp=H}};
vm.createContext(context);vm.runInContext(body,context);context.simulationApplyFarmPassive(1,D,{},{});
console.log(JSON.stringify({scope:'Exact farm function with reward/spawn side effects stubbed; supplemental arithmetic only.',sourceDamageExpression:'2 ** 55 + 16',representedDamageExact:String(BigInt(D)),remainder:D%H,expectedKills:expected,actualKills:kills,hp:state.enemyHp,safe:Number.isSafeInteger(expected)&&Number.isSafeInteger(kills)}));
assert.strictEqual(kills,expected,'safe-count conservation');
