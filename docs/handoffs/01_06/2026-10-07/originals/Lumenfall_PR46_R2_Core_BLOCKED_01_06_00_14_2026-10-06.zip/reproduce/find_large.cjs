const fs=require('fs'),vm=require('vm');const src=fs.readFileSync(__dirname+'/head/index.html','utf8'),body=src.slice(src.indexOf('function simulationApplyFarmPassive('),src.indexOf('function simulationPassiveKillSeconds('));
const ctx={SIM_EPS:1e-9,state:null,enemyHpFor:()=>ctx.state.enemyMaxHp,simulationBatchFarmKills:n=>{ctx.kills=n;ctx.state.enemyHp=ctx.state.enemyMaxHp}};vm.createContext(ctx);vm.runInContext(body,ctx);
// H=11 integer, represented damage at this scale is an integer. Independent
// threshold count uses BigInt integer division after subtracting ceil(currentHP).
let rows=[];for(const p of [50,51,52])for(let j=1;j<10000;j++){const count=2**p+j*137,D=11*count,hp=.33;ctx.state={enemyMaxHp:11,enemyHp:hp,depth:1};ctx.kills=0;ctx.simulationApplyFarmPassive(1,D,{},{});const exact=1+Number((BigInt(D)-1n)/11n);if(ctx.kills!==exact){rows.push({power:p,count,D,hp,actual:ctx.kills,expected:exact,hpAfter:ctx.state.enemyHp,actualSafe:Number.isSafeInteger(ctx.kills)});break;}}
fs.writeFileSync(__dirname+'/evidence/large_counterexamples.json',JSON.stringify(rows,null,2));console.log(rows);
