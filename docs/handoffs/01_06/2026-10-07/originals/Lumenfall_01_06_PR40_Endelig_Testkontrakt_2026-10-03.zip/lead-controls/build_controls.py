from pathlib import Path
import ast,importlib.util,sys,json,hashlib,shutil,difflib
R=Path('/workspace/scratch/1c251eaaeb62');qa=R/'current-reviews/qa';atomic=R/'current-reviews/atomic'
sys.path.insert(0,str(qa/'source/tests/behavioral'));sp=importlib.util.spec_from_file_location('lead40runner',qa/'source/tests/behavioral/run.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
pre=m.build_prelude(json.loads((qa/'source/tests/behavioral/fixtures.json').read_text()))
parsed=ast.parse((R/'current-reviews/core/pr40-evidence/prepare.py').read_text());extra=next(ast.literal_eval(n.value) for n in parsed.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='extra' for t in n.targets))
# Unused input binding is absent on main; same null-safe binding on all variants.
extra=extra.replace('input:setAutoAscendClearedTarget,','input:typeof setAutoAscendClearedTarget===\'function\'?setAutoAscendClearedTarget:null,')
original=(atomic/'pr40-evidence/atomic-observer.js').read_text()
observer=original.replace('r.state.enemyHp===6.4','r.state.enemyHp===6.5').replace('proof.expected.enemyHp=6.400000000000001;','')
assert original.count('r.state.enemyHp===6.4')==1
assert original.count('proof.expected.enemyHp=6.400000000000001;')==1
needle="document.addEventListener('DOMContentLoaded',function(){window.__core40.boot=window.__core40.snapshot();});"
extra=extra.replace(needle,observer+"\n"+needle.replace('snapshot();','snapshot();window.__core40.atomicBootObserver();'))
(R/'lead-atomic-controls/oracle-revision.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True),observer.splitlines(True),fromfile='delivered/observer',tofile='lead-control/observer')))
identities={}
for label,folder in [('main','main-source'),('parent','parent-source'),('head','source')]:
 root=R/'lead-atomic-controls'/label;stage=root/'pr40-stage';out=root/'pr40-evidence';stage.mkdir(parents=True,exist_ok=True);out.mkdir(exist_ok=True)
 source=(qa/folder/'index.html').read_text();mark='\n})();\n</script>\n<script>\nif(window.Capacitor';assert source.count(mark)==1
 page=source.replace('<head>','<head>\n'+pre,1).replace(mark,'\n'+m.build_bridge()+extra+mark,1);(stage/'index.html').write_text(page)
 for asset in ['fonts','branding']:(stage/asset).symlink_to(qa/'source'/asset,target_is_directory=True)
 driver=(atomic/'pr40-evidence/review.cjs').read_bytes();(out/'review.cjs').write_bytes(driver)
 identities[label]={'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'stage_sha256':hashlib.sha256(page.encode()).hexdigest(),'driver_sha256':hashlib.sha256(driver).hexdigest()}
(R/'lead-atomic-controls/construction.json').write_text(json.dumps(identities,indent=2))
print('Three source stages constructed; fixtures/driver unchanged; before6.5, full expected copy unchanged.')
