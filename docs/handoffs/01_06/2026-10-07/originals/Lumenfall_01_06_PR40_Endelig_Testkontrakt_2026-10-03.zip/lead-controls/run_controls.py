from pathlib import Path
import subprocess,os,time,json,hashlib
R=Path(__file__).resolve().parent;binary=Path('/workspace/scratch/f5911b1189e0/startup-runtime/chrome-headless-shell-linux64/chrome-headless-shell');assert hashlib.sha256(binary.read_bytes()).hexdigest()=='1346545781835e04ece3434a16d656ad5cbe60a6a179a43dff43f79a21f9a4ad'
rows=[]
for label in ['main','parent','head']:
 out=R/label/'pr40-evidence';env=os.environ.copy();env['CORE40_ONLY']='07-cross-43-cold';start=time.monotonic()
 with (out/'stdout.txt').open('w') as stdout,(out/'stderr.txt').open('w') as stderr:
  p=subprocess.run([os.environ['CODEX_PRIMARY_RUNTIME_NODE'],str(out/'review.cjs')],env=env,stdout=stdout,stderr=stderr,timeout=60)
 row={'label':label,'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-start,'timeout_seconds':60,'timed_out':False};rows.append(row);(out/'lead-process.json').write_text(json.dumps(row,indent=2));print(row,flush=True)
 if p.returncode:break
(R/'results.json').write_text(json.dumps(rows,indent=2))
