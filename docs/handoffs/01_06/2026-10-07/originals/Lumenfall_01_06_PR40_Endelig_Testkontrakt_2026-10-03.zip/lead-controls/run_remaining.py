from pathlib import Path
import os,subprocess,json,time
R=Path(__file__).resolve().parent;out=R/'head/pr40-evidence';rows=[]
for name in ['07-cross-43-visibility','07-cross-55-cold','07-cross-55-visibility']:
 env=os.environ.copy();env['CORE40_ONLY']=name;start=time.monotonic()
 with (out/(name+'.stdout.txt')).open('w') as stdout,(out/(name+'.stderr.txt')).open('w') as stderr:p=subprocess.run([os.environ['CODEX_PRIMARY_RUNTIME_NODE'],str(out/'review.cjs')],env=env,stdout=stdout,stderr=stderr,timeout=60)
 row={'scenario':name,'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-start,'timeout_seconds':60,'timed_out':False};rows.append(row);(out/(name+'.lead-process.json')).write_text(json.dumps(row,indent=2));print(row,flush=True)
 if p.returncode:break
(R/'remaining-results.json').write_text(json.dumps(rows,indent=2))
