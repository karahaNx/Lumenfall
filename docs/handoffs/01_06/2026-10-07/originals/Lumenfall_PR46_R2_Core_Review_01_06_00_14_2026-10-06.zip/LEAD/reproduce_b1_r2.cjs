const fs = require('node:fs');
const vm = require('node:vm');
const crypto = require('node:crypto');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const files = {
  R1: path.join(root, 'ORIGINALS/B1_INPUT/SOURCE/index.html'),
  R2: path.join(root, 'SOURCE/index.html'),
};
function extract(source) {
  const start = source.indexOf('function simulationApplyFarmPassive(');
  const end = source.indexOf('function simulationPassiveKillSeconds(', start);
  if (start < 0 || end < 0) throw Error('Missing exact function boundaries');
  return source.slice(start, end).trim();
}
function ledger(parts) {
  let hp = 8.03, kills = 0;
  for (const seconds of parts) {
    let damage = 1100 * seconds;
    while (damage >= hp - 1e-9) {
      damage -= hp;
      kills++;
      hp = 11;
    }
    hp -= damage;
  }
  return {kills, enemyHp: hp};
}
const parts = {
  before: [0.01729999], boundary: [0.0173], after: [0.01730001],
  whole: [0.9], split: [0.0173, 0.9 - 0.0173],
};
const result = {
  scope: 'Lead isolated exact source-function execution. Farm batch side effects stubbed; not a full-engine, economy, browser, or Android acceptance.',
  oracle: 'Independent per-enemy HP consumption loop; no quotient/modulo calculation.',
  variants: {},
};
for (const [name, file] of Object.entries(files)) {
  const source = fs.readFileSync(file, 'utf8');
  const eps = Number(source.match(/var SIM_EPS\s*=\s*([\d.eE+-]+)/)?.[1]);
  if (eps !== 1e-9) throw Error('Changed SIM_EPS');
  const body = extract(source);
  const output = {source_sha256: crypto.createHash('sha256').update(source).digest('hex'), SIM_EPS:eps, cases:{}};
  for (const [key, split] of Object.entries(parts)) {
    const state = {enemyHp: 8.03, enemyMaxHp: 11, depth:1};
    const calls = [];
    const context = {state, SIM_EPS:eps, enemyHpFor:()=>11, simulationBatchFarmKills(count){calls.push(count);state.enemyHp=11;}};
    vm.createContext(context);
    vm.runInContext(body, context);
    for (const seconds of split) context.simulationApplyFarmPassive(seconds,1100,{},{});
    const actual={kills:calls.reduce((a,b)=>a+b,0),enemyHp:state.enemyHp,batchCalls:calls};
    const expected=ledger(split);
    const match=actual.kills===expected.kills && Math.abs(actual.enemyHp-expected.enemyHp)<1e-7;
    output.cases[key]={parts:split,actual,expected,match};
    if(name==='R2'&&!match) throw Error('R2 conservation mismatch: '+key);
  }
  result.variants[name]=output;
}
if(result.variants.R1.cases.boundary.actual.kills!==3 || result.variants.R1.cases.split.actual.kills!==91) throw Error('Missing old B1 causal failure');
if(result.variants.R2.cases.boundary.actual.kills!==2 || result.variants.R2.cases.split.actual.kills!==90) throw Error('Missing R2 correction');
fs.writeFileSync(path.join(__dirname,'reproduce_b1_r2.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result));
