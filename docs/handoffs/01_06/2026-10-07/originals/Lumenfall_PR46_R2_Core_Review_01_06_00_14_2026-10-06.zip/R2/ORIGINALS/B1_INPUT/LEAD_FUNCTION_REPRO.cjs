const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');

const root = __dirname;
const candidate = fs.readFileSync(process.argv[2] || path.join(root, 'SOURCE/index.html'), 'utf8');
const baseline = fs.readFileSync(process.argv[3] || path.join(root, '../pr46-core/source/base/index.html'), 'utf8');
function extract(source) {
  const start = source.indexOf('function simulationApplyFarmPassive(');
  const end = source.indexOf('function simulationPassiveKillSeconds(', start);
  if (start < 0 || end < 0) throw Error('Expected function boundaries missing');
  return source.slice(start, end).trim();
}
const body = extract(candidate);
const eps = Number(candidate.match(/var SIM_EPS\s*=\s*([\d.eE+-]+)/)?.[1]);
if (!Number.isFinite(eps) || eps !== 1e-9) throw Error('Unexpected SIM_EPS');
const sha256 = s => crypto.createHash('sha256').update(s).digest('hex');
function run(parts) {
  const state = { enemyHp: 8.03, enemyMaxHp: 11, depth: 1 };
  const batchCalls = [];
  const context = {
    state, SIM_EPS: eps, enemyHpFor: () => 11,
    simulationBatchFarmKills(count) {
      batchCalls.push(count);
      state.enemyHp = state.enemyMaxHp;
    },
  };
  vm.createContext(context);
  vm.runInContext(body, context);
  for (const part of parts) context.simulationApplyFarmPassive(part, 1100, {}, {});
  return { parts, batchCalls, kills: batchCalls.reduce((a, b) => a + b, 0), enemyHp: state.enemyHp };
}
const result = {
  scope: 'Lead isolated execution of exact source function; batch side effects stubbed. Not a full-engine/browser replay.',
  candidate_source_sha256: sha256(candidate),
  baseline_source_sha256: sha256(baseline),
  function_sha256: sha256(body),
  function_identical_on_base: body === extract(baseline),
  SIM_EPS: eps,
  whole: run([0.9]),
  first_boundary: run([0.0173]),
  split: run([0.0173, 0.9 - 0.0173]),
  expected_by_damage_conservation: { wholeKills: 90, firstBoundaryKills: 2, splitKills: 90, finalHp: 8.03 },
};
if (result.whole.kills !== 90 || result.first_boundary.kills !== 3 || result.split.kills !== 91 || !result.function_identical_on_base) throw Error('B1 not reproduced as expected');
fs.writeFileSync(process.argv[4] || path.join(root, 'LEAD_FUNCTION_REPRO.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result));
