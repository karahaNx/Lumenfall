const fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const root=__dirname,stage=path.join(root,'own-www'),records=[],errors=[];
const server=http.createServer((req,res)=>{let p=path.join(stage,new URL(req.url,'http://localhost').pathname);fs.readFile(p,(err,data)=>{if(err){res.statusCode=404;return res.end();}res.setHeader('Content-Type',p.endsWith('.html')?'text/html':p.endsWith('.woff2')?'font/woff2':p.endsWith('.svg')?'image/svg+xml':'application/octet-stream');res.end(data);});});
(async()=>{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));let browser;
 try{
  browser=await chromium.launch({executablePath:path.join(root,'../pr46_runtime/bin/google-chrome'),headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
  const context=await browser.newContext({viewport:{width:390,height:844}}),page=await context.newPage();page.on('pageerror',e=>errors.push(e.message));
  const url=`http://127.0.0.1:${server.address().port}/index.html?qaScenario=lab-motes-native&qaFixture=fresh`;
  async function ready(){await page.waitForFunction(()=>!!window.ownQA&&!!window.__lumenfallQaContext);await page.evaluate(()=>{localStorage.setItem('lumenfall_qa_phase_lab-motes-native','own');return document.fonts.ready;});}
  await page.goto(url);await ready();let motor=await page.evaluate('('+fs.readFileSync(path.join(root,'own_motor.js'),'utf8')+')()');fs.writeFileSync(path.join(root,'own-motor-results.json'),JSON.stringify(motor,null,2));fs.writeFileSync(path.join(root,'own-conservation.json'),JSON.stringify(await page.evaluate(()=>window.ownConservation),null,2));fs.writeFileSync(path.join(root,'own-scan.json'),JSON.stringify(await page.evaluate(()=>window.ownScan),null,2));
  const projection=s=>({use:s.studyUseMotes,target:s.studySpeedTargets,queue:s.studyQueue,active:s.activeStudies,motes:s.motes,levels:s.longStudyLevels});
  let expected=await page.evaluate(()=>{let b=ownQA,s=b.fresh();s.depth=s.enemyDepth=33;s.maxDepthEver=130;s.enemyMaxHp=s.enemyHp=b.hp(33);s.activeStudies=[{id:'shardstudy',remainingSec:123.25,totalDurationSec:200,speedMult:5},{id:'guardmastery',remainingSec:87.75,totalDurationSec:150,speedMult:4}];s.studyUseMotes.shardstudy=true;s.studySpeedTargets.shardstudy=3;s.studyUseMotes.guardmastery=false;s.studySpeedTargets.guardmastery=8;s.studyQueue.shardstudy=true;s.motes=17;b.set(s);b.save();return b.get();});
  expected=projection(expected);
  const verify=async name=>{let state=await page.evaluate(()=>ownQA.get()),raw=await page.evaluate(()=>ownQA.raw()),observed=projection(state);if(JSON.stringify(observed)!==JSON.stringify(expected))throw Error(name+' actual snapshot differs');if(raw.primary!==raw.recovery)throw Error(name+' primary/recovery differ');records.push({name,status:'pass',observed,raw});};
  await page.reload();await ready();await verify('own-actual-reload');
  const code=await page.evaluate(()=>ownQA.export());await page.evaluate(()=>{ownQA.set(ownQA.fresh());ownQA.save();});
  await Promise.all([page.waitForEvent('load'),page.evaluate(code=>ownQA.restore(code),code)]);await ready();await verify('own-valid-backup-restore-real-reload');
  await page.evaluate(()=>localStorage.setItem('lumenfall_save_v2','{broken-own-qa'));await page.reload();await ready();await verify('own-corrupt-primary-real-recovery');
  await page.evaluate(()=>ownQA.ascend());await verify('own-manual-Ascend-real-save');
  await Promise.all([page.waitForEvent('load'),page.evaluate(()=>ownQA.reset())]);await ready();let fresh=await page.evaluate(()=>ownQA.get()),freshProjection=projection(fresh);if(Object.values(fresh.studyUseMotes).some(x=>x!==false)||Object.values(fresh.studySpeedTargets).some(x=>x!==1.5)||fresh.activeStudies.length||fresh.motes)throw Error('Reset must clear repeat intent and paid snapshot');records.push({name:'own-Reset-real-reload',status:'pass',observed:freshProjection});
  fs.writeFileSync(path.join(root,'own-persistence-results.json'),JSON.stringify({status:'pass',records},null,2));
  console.log(JSON.stringify({motor:motor.status,motorCases:motor.records.length,motorChecks:motor.checks,failures:motor.records.filter(x=>x.status!=='pass').map(x=>({name:x.name,message:x.message})),persistenceCases:records.length,errors}));
  if(motor.status!=='pass'||errors.length)process.exitCode=1;
  await context.close();
 }catch(e){console.error(e.stack);fs.writeFileSync(path.join(root,'own-driver-failure.json'),JSON.stringify({message:e.message,records,errors},null,2));process.exitCode=1;}
 finally{if(browser)await browser.close();await new Promise(r=>server.close(r));console.log('Owned browser and HTTP server closed.');}
})();
