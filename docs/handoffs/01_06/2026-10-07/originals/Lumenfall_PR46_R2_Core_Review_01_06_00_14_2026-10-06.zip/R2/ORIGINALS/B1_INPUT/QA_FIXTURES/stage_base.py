"""Rebuild the private base control; no checkout/reset or remote writes."""
import pathlib,subprocess,json,hashlib
root=pathlib.Path(__file__).resolve().parent
stage=root/'own-www'/'base';stage.mkdir(exist_ok=True)
for name in ['fonts','branding']:
    link=stage/name
    if not link.exists():link.symlink_to(pathlib.Path('..')/name)
base=subprocess.check_output(['git','-C',str(root.parent/'pr46_repo'),'show','1ddc246eb62782a61ec5c486cd5f51ea170bb338:index.html'],text=True)
head=(root/'own-www/index.html').read_text()
at=head.index('<script id="qa-behavior-prelude">');prelude=head[at:head.index('</script>',at)+9]
marker='\n})();\n</script>\n<script>\nif(window.Capacitor'
assert base.count(marker)==1
out=base.replace('<head>','<head>\n'+prelude+'<script>__qaUiMeasurementPause(true);localStorage.setItem("lumenfall_startup_intro_last",String(Date.now()))</script>',1).replace(marker,'\n'+(root/'own_bridge.js').read_text()+marker,1)
(stage/'index.html').write_text(out)
(root/'base-source.json').write_text(json.dumps({'commit':'1ddc246eb62782a61ec5c486cd5f51ea170bb338','index_sha256':hashlib.sha256(base.encode()).hexdigest(),'instrumented_sha256':hashlib.sha256(out.encode()).hexdigest()},indent=2))
