import importlib.util,pathlib,sys,shutil,hashlib,json
root=pathlib.Path(__file__).resolve().parent; repo=root.parent/'pr46_repo'
sys.path.insert(0,str(repo/'tests/behavioral'))
spec=importlib.util.spec_from_file_location('candidate_runner',repo/'tests/behavioral/run.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
stage=root/'own-www';stage.mkdir(exist_ok=True)
for p in ['fonts','branding']:shutil.copytree(repo/p,stage/p,dirs_exist_ok=True)
source=(repo/'index.html').read_text(); marker='\n})();\n</script>\n<script>\nif(window.Capacitor'
bridge=(root/'own_bridge.js').read_text();assert source.count(marker)==1
out=source.replace('<head>','<head>\n'+m.build_prelude({'fresh':{'save':None}})+'<script>__qaUiMeasurementPause(true);localStorage.setItem("lumenfall_startup_intro_last",String(Date.now()))</script>',1).replace(marker,'\n'+bridge+marker,1)
(stage/'index.html').write_text(out)
(root/'own-source.json').write_text(json.dumps({'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'instrumented_sha256':hashlib.sha256(out.encode()).hexdigest(),'instrumentation':'candidate prelude clock/interval pause only; own bridge, no worker test scripts or oracles'},indent=2))
