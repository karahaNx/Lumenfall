window.ownQA={
 fresh:()=>JSON.parse(JSON.stringify(freshState())),
 normalize:input=>normalizeCurrentSave(input),
 set:input=>{state=acceptPersistedState(JSON.parse(JSON.stringify(input)),'own-qa');restoreEnemyOrSpawn();return JSON.parse(JSON.stringify(state));},
 get:()=>JSON.parse(JSON.stringify(state)),
 hp:enemyHpFor,
 render:()=>renderAll(),
 prepareUI:()=>{if(startupIntroFinish)startupIntroFinish();document.querySelectorAll('.overlay,#startup-intro').forEach(el=>el.style.display='none');document.querySelectorAll('.rift-milestone,.combat-vfx').forEach(el=>el.remove());},
 manual:applySpeedTier,
 start:id=>startStudy(LONG_STUDIES.find(n=>n.id===id)),
 save:()=>saveState(),
 raw:()=>({primary:localStorage.getItem(SAVE_KEY),recovery:localStorage.getItem(RECOVERY_SAVE_KEY)}),
 export:currentSaveBackup,
 restore:code=>{document.querySelector('#save-backup-code').value=code;restoreSaveBackup();},
 reset:performReset,
 ascend:()=>doAscend(false),
 offline:applyOfflineProgress,
 run:(seconds,dps=0,kind='live',start=Date.now())=>{let original=simulationPassiveDps;simulationPassiveDps=()=>dps;try{let summary=advanceAuthoritativeTime(seconds,{kind,visual:false,clockStartMs:start,offlineWindowStartMs:start,captureTimeline:true});return window.ownLastRun={state:JSON.parse(JSON.stringify(state)),summary};}finally{simulationPassiveDps=original;}},
 tail:seconds=>{let summary=simulationSummary(seconds);summary.timeline=[];summary.captureTimeline=true;advanceStudyOnlyTime(seconds,Date.now(),summary);return {state:JSON.parse(JSON.stringify(state)),summary};},
 offlineZero:()=>{let original=simulationPassiveDps;simulationPassiveDps=()=>0;try{return applyOfflineProgress();}finally{simulationPassiveDps=original;}},
 mutate:kind=>{
  let start=commitStudyStart,plan=studyMotesPlan,boundary=simulationKillsUntilStudyMotes;
  if(kind==='free-carry')commitStudyStart=node=>{let result=start(node);if(result&&state.studyUseMotes[node.id])findActiveStudy(node.id).speedMult=state.studySpeedTargets[node.id];return result;};
  if(kind==='fallback')studyMotesPlan=node=>{let result=plan(node);if(result&&state.motes<result.cost){result.target=1.5;result.cost=14;}return result;};
  if(kind==='batch-end')simulationKillsUntilStudyMotes=()=>Infinity;
  return ()=>{commitStudyStart=start;studyMotesPlan=plan;simulationKillsUntilStudyMotes=boundary;};
 }
};
