import subprocess, pathlib, os, json, time, datetime
root=pathlib.Path(__file__).resolve().parent
repo=root.parent/'pr46_repo'
env=dict(os.environ, PATH=str(root.parent/'pr46_runtime/bin')+':'+os.environ['PATH'], PYTHONPATH=str(root), LUMENFALL_QA_EVIDENCE_DIR=str(root/'screens'))
records=[]
for gate in sorted(root.glob('gate-*')):
    env['QA_PROCESS_ROOT']=str(gate/'processes')
    start=time.monotonic(); at=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (gate/'stdout.txt').open('w') as stdout, (gate/'stderr.txt').open('w') as stderr:
        result=subprocess.run(['bash',str(gate/'command.sh')], cwd=repo,env=env,stdout=stdout,stderr=stderr)
    record={'gate':gate.name,'name':(gate/'name.txt').read_text(),'started_utc':at,'exitcode':result.returncode,'elapsed_seconds':time.monotonic()-start,'command_file':str(gate/'command.sh')}
    records.append(record); (root/'execution.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(record),flush=True)
    if result.returncode: raise SystemExit(result.returncode)
