const fs=require('fs'),vm=require('vm'),assert=require('assert'),source=fs.readFileSync('pr46_repo/index.html','utf8');const a=source.indexOf('function simulationApplyFarmPassive('),body=source.slice(a,source.indexOf('function simulationPassiveKillSeconds(',a)),rows=[];
function run(H,parts){let state={enemyHp:H*.73,enemyMaxHp:H,depth:1},kills=0,ctx={state,SIM_EPS:1e-9,enemyHpFor:()=>H,simulationBatchFarmKills:n=>{kills+=n;state.enemyHp=H;}};vm.createContext(ctx);vm.runInContext(body,ctx);for(const dt of parts)ctx.simulationApplyFarmPassive(dt,H*100,{},{});return {parts,kills,hpFraction:state.enemyHp/H};}
for(const H of [11,13,1000,1e12,1e50,1e150,1e250])for(const seconds of [.02729999,.0273,.02730001,.9])for(const split of [.01,.0173]){
 let whole=run(H,[seconds]),parts=run(H,[split,seconds-split]),expected=seconds<.0273?2:seconds<.9?3:90,hp=seconds<.0273?2.73-seconds*100:seconds<.9?3.73-seconds*100:.73;
 assert.equal(whole.kills,expected);assert.equal(parts.kills,expected);assert(Math.abs(whole.hpFraction-hp)<1e-7);assert(Math.abs(parts.hpFraction-hp)<1e-7);rows.push({H,seconds,split,expected,hp,whole,parts});
}
fs.writeFileSync('evidence/arithmetic-splits.json',JSON.stringify(rows,null,2));console.log(JSON.stringify({fixtures:rows.length,status:'pass',oracle:'explicit per-enemy thresholds and remaining HP; existing 1e-7 normalized comparison'}));
