const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync('pr46_repo/index.html','utf8'),start=source.indexOf('function simulationApplyFarmPassive('),end=source.indexOf('function simulationPassiveKillSeconds(',start),body=source.slice(start,end),rows=[];
function rational(x){let b=new ArrayBuffer(8),v=new DataView(b);v.setFloat64(0,x);let bits=v.getBigUint64(0),exp=Number((bits>>52n)&2047n),mant=(bits&((1n<<52n)-1n))+(exp?1n<<52n:0n),power=(exp||1)-1023-52;return power>=0?{n:mant<<BigInt(power),d:1n}:{n:mant,d:1n<<BigInt(-power)};}
function expected(damage,hp,H){let a=rational(damage),b=rational(hp),h=rational(H),rd=a.n*b.d-b.n*a.d;return rd<0n?0:1+Number(rd*h.d/(a.d*b.d*h.n));}
for(const H of [11,1e3,1e12,1e50,1e150,1e250])for(const count of [2,90,10000,1e12,2**50])for(const frac of [.13,.73,.89]){
 let hp=H*frac,damage=H*count,state={enemyHp:hp,enemyMaxHp:H,depth:1},kills=0,ctx={state,SIM_EPS:1e-9,enemyHpFor:()=>H,simulationBatchFarmKills:n=>{kills+=n;state.enemyHp=H;}};vm.createContext(ctx);vm.runInContext(body,ctx);ctx.simulationApplyFarmPassive(1,damage,{},{});let oracle=expected(damage,hp,H);rows.push({H,count,frac,damage,initialHp:hp,kills,oracle,remainingHp:state.enemyHp,pass:kills===oracle});
}
fs.writeFileSync('evidence/arithmetic-scales.json',JSON.stringify(rows,null,2));console.log(JSON.stringify({tested:rows.length,bad:rows.filter(x=>!x.pass)}));if(rows.some(x=>!x.pass))process.exitCode=1;
