from pathlib import Path
import difflib
R=Path(__file__).resolve().parent;F=R/'atomic-finish';O=F/'pr40-evidence'
prior=(R/'finish/pr40-evidence/review.cjs').read_text()
start=prior.index("for(const clear of [43,55])for(const route of ['cold','visibility'])await run('07-cross-'")
end=prior.index("await run('08-independent-cycles-before-and-farm'",start)
replacement=r'''for(const clear of [43,55])for(const route of ['cold','visibility'])await run('07-cross-'+clear+'-'+route,async page=>{
 let proof=await page.evaluate(({clear,route})=>__core40.atomicStart(clear,route),{clear,route});
 function retain(){fs.writeFileSync(path.join(OUT,'07-cross-'+clear+'-'+route+'.atomic-proof.json'),JSON.stringify(proof,null,2));}
 function requireValid(){retain();if(proof.status==='fail')throw Error(proof.failure.replace(/^Error: /,''));}
 requireValid();
 for(let navigation=0;navigation<(route==='cold'?3:2);navigation++){
  await page.goto(url());await page.waitForFunction(()=>window.__core40?.boot,{timeout:5000});
  proof=await page.evaluate(()=>__core40.atomicFailure||__core40.atomicComplete||JSON.parse(sessionStorage.getItem('core40-atomic-proof')));
  requireValid();
 }
 ok(proof.status==='pass','atomic observer completed both genuine zero-time reloads');return proof;
});
'''
driver=prior[:start]+replacement+prior[end:]
(O/'review.cjs').write_text(driver)
(F/'atomic-review-driver.diff').write_text(''.join(difflib.unified_diff(prior.splitlines(True),driver.splitlines(True),fromfile='previous/review.cjs',tofile='atomic/review.cjs')))
print('Driver changes confined to four cross cases; original filter/deadlines unchanged.')
