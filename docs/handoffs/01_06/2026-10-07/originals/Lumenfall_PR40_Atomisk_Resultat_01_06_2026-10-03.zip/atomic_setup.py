from pathlib import Path
import json,hashlib,shutil,difflib
R=Path(__file__).resolve().parent;F=R/'atomic-finish';O=F/'diagnostic/pr40-evidence';O.mkdir(parents=True,exist_ok=True)
for n,h in json.loads((R/'atomic-task/SHA256SUMS.json').read_text()).items():assert hashlib.sha256((R/'atomic-task'/n).read_bytes()).hexdigest()==h,n
original=(R/'finish/pr40-evidence/review.cjs').read_text()
needle=' const reward=clear===43?13:14;';assert original.count(needle)==1
diagnostic=original.replace(needle," fs.writeFileSync(path.join(OUT,'assertion-observation.json'),JSON.stringify({input,before,r,timing:'Captured original local r before the exact fixture assertion; later collector is separate.'},null,2));"+needle)
(O/'review.cjs').write_text(diagnostic)
(F/'diagnostic-observer.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True),diagnostic.splitlines(True),fromfile='prior/review.cjs',tofile='diagnostic/review.cjs')))
shutil.copytree(R/'finish/pr40-stage',F/'diagnostic/pr40-stage',dirs_exist_ok=True)
print('Lead manifest5/5 verified; original orchestration diagnostic prepared.')
