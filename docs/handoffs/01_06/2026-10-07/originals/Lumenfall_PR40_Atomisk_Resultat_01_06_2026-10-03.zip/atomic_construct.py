from pathlib import Path
import json,hashlib,shutil,difflib
R=Path(__file__).resolve().parent;F=R/'atomic-finish';S=F/'pr40-stage';O=F/'pr40-evidence';S.mkdir(exist_ok=True);O.mkdir(exist_ok=True)
original=(R/'finish/pr40-evidence/review.cjs').read_text()
seed=original.split('async function seed(page,opts={}){return page.evaluate(({T,opts})=>{',1)[1].split('},{T,opts});}',1)[0]
checks=original.split(' const reward=clear===43?13:14;',1)[1].split('const expected=JSON.parse(JSON.stringify(r.state));',1)[0]
checks='const reward=clear===43?13:14;'+checks
helper=r'''
(function(){
const c=window.__core40,b=window.__lumenfallQaBridge,ctx=window.__lumenfallQaContext,T=2000000000000;
const K='core40-atomic-proof',P='core40-atomic-phase';
function ok(v,m){if(!v)throw Error(m);}
function eq(a,b,m){ok(JSON.stringify(a)===JSON.stringify(b),m+' actual='+JSON.stringify(a)+' expected='+JSON.stringify(b));}
function seedNow(opts){SEED_BODY}
function crossChecks(r,input,clear){CHECKS_BODY}
function prepare(advance,next,proof){
 const before=c.snapshot(),raw=b.rawSave(),clockBefore=ctx.clockNow();
 localStorage.setItem(ctx.phaseKey,'1');ctx.advanceTime(advance);b.suppressUnloadSave();
 const after=c.snapshot();ok(before.flags.reloadInProgress===false&&before.flags.resetInProgress===false,'normal flags before genuine unload preparation');
 ok(after.flags.reloadInProgress===true&&after.flags.resetInProgress===false,'original suppressUnloadSave sets only reload guard');
 eq(after.state,before.state,'unload preparation does not repair actual state');eq(after.primary,before.primary,'unload preparation does not repair primary');eq(after.recovery,before.recovery,'unload preparation does not repair recovery');
 proof.unloadPreparations.push({advance,next,before,after,request:{diskBeforeUnload:raw,flags:b.getFlags()},clockBefore,clockAfter:ctx.clockNow(),phaseKey:localStorage.getItem(ctx.phaseKey)});
 sessionStorage.setItem(P,next);sessionStorage.setItem(K,JSON.stringify(proof));
}
function measureBefore(r,proof){
 proof.beforeRepeat=r;crossChecks(r,proof.input,proof.clear);
 proof.expected=JSON.parse(JSON.stringify(r.state));proof.expected.enemyHp=6.400000000000001;
 prepare(0,'repeat',proof);
}
function preserveFailure(proof,e){proof.status='fail';proof.failure=e.stack;proof.failureCollector=c.snapshot();sessionStorage.setItem(K,JSON.stringify(proof));c.atomicFailure=proof;}
c.atomicStart=function(clear,route){
 const proof={clear,route,oracleLabel:'REVIDERET ORACLE / ATOMISK ORCHESTRATION',unloadPreparations:[],bootPhases:[]};
 try{
  proof.before=seedNow({autoAscendTargetDepth:clear+1,autoAscendEnabled:true,depth:clear,enemyHp:1,activeStudies:[{id:'guardmastery',totalDurationSec:150,remainingSec:.5,speedMult:2}]});
  const s=b.getState();s.achieved.study1=false;b.setState(s);c.save();proof.input=JSON.parse(b.rawSave());proof.inputSnapshot=c.snapshot();
  if(route==='cold'){prepare(5500,'catchup',proof);}
  else{
   b.clearLifecycleTrace();b.dispatchVisibility(true);b.advanceTime(5500);b.dispatchVisibility(false);
   const first=c.snapshot();proof.beforeRepeat=first;
   b.dispatchVisibility(false);const second=c.snapshot();proof.duplicateVisibility=second;
   if(JSON.stringify(first)!==JSON.stringify(second))throw Error('duplicate visibility changed result');
   measureBefore(first,proof);
  }
 }catch(e){preserveFailure(proof,e);}
 return proof;
};
c.atomicBootObserver=function(){
 const phase=sessionStorage.getItem(P);if(!phase)return;
 const proof=JSON.parse(sessionStorage.getItem(K));if(proof.status==='fail')return;
 const actual=c.boot;proof.bootPhases.push({phase,actual,clock:ctx.clockNow(),phaseKey:localStorage.getItem(ctx.phaseKey)});
 try{
  ok(actual.flags.reloadInProgress===false&&actual.flags.resetInProgress===false,'new genuine init restores normal flags');
  if(phase==='catchup'){measureBefore(actual,proof);}
  else if(phase==='repeat'){
   eq(actual.state,proof.expected,'REVISED ORACLE full repeat state');eq(JSON.parse(actual.primary),proof.expected,'REVISED ORACLE full repeat primary');eq(JSON.parse(actual.recovery),proof.expected,'REVISED ORACLE full repeat recovery');
   prepare(0,'additional',proof);
  }else if(phase==='additional'){
   eq(actual.state,proof.expected,'projected state stable on additional zero-time reload');eq(JSON.parse(actual.primary),proof.expected,'stable full primary');eq(JSON.parse(actual.recovery),proof.expected,'stable full recovery');
   proof.status='pass';sessionStorage.setItem(K,JSON.stringify(proof));c.atomicComplete=proof;
  }else throw Error('unknown atomic observation phase');
 }catch(e){preserveFailure(proof,e);}
};
})();
'''.replace('SEED_BODY',seed).replace('CHECKS_BODY',checks)
(O/'atomic-observer.js').write_text(helper)
base=(R/'finish/pr40-stage/index.html').read_text()
needle="document.addEventListener('DOMContentLoaded',function(){window.__core40.boot=window.__core40.snapshot();});"
assert base.count(needle)==1
page=base.replace(needle,helper+"\ndocument.addEventListener('DOMContentLoaded',function(){window.__core40.boot=window.__core40.snapshot();window.__core40.atomicBootObserver();});")
(S/'index.html').write_text(page)
for folder in ['fonts','branding']:shutil.copytree(R/'startup-source'/folder,S/folder,dirs_exist_ok=True)
(F/'atomic-observer.diff').write_text(''.join(difflib.unified_diff([needle+'\n'],(helper+"\ndocument.addEventListener('DOMContentLoaded',function(){window.__core40.boot=window.__core40.snapshot();window.__core40.atomicBootObserver();});\n").splitlines(True),fromfile='previous/boot-observer',tofile='atomic/boot-observer')))
(O/'construction-hashes.json').write_text(json.dumps({'candidate_index':hashlib.sha256((R/'startup-source/index.html').read_bytes()).hexdigest(),'original_prepared_page':hashlib.sha256(base.encode()).hexdigest(),'atomic_prepared_page':hashlib.sha256(page.encode()).hexdigest(),'atomic_observer':hashlib.sha256(helper.encode()).hexdigest(),'seedBodyUnchanged':True,'centralAssertionsExtractedUnchanged':True,'deadlineChange':False,'fixtureChange':False},indent=2))
print('Atomic fixture body and central assertions extracted unchanged; observer prepared.')
