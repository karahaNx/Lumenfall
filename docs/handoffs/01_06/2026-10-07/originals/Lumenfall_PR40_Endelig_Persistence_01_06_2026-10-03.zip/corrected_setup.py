from pathlib import Path
import json,hashlib,shutil,difflib
R=Path(__file__).resolve().parent;F=R/'corrected-finish';O=F/'pr40-evidence';S=F/'pr40-stage';O.mkdir(exist_ok=True);S.mkdir(exist_ok=True)
def data(key):
 s=json.loads((F/'checkpoint-before'/f'{key}.json').read_text())['structuredContent'];return json.loads(s['content']) if 'content' in s else s
p=data('pr');h=data('head');m=data('main');w=data('run');checks=data('checks')
assert p['head_sha']=='d3daa23d04315ec21776de69b0df960d24cb19b6' and p['base_sha']=='3a89a8cb4084193326daa5dab68cf9a89ef71512' and p['draft'] and not p['merged'] and p['state']=='open'
assert h['tree']['sha']=='d1d128a82f6bc204655dc662a5239f98dca51059' and [x['sha'] for x in h['parents']]==['9348a48364dcd88b77b9d1bc00763b83c6f8e768']
assert m['commit']['sha']==p['base_sha'] and m['commit']['commit']['tree']['sha']=='134b5f21f414f56ecd446220c8ffc54a0621ca3e'
assert w['head_sha']==p['head_sha'] and w['run_number']==121 and w['run_attempt']==1 and w['event']=='pull_request' and w['status']=='completed' and w['conclusion']=='success'
c=[x for x in checks['check_runs'] if x['id']==111074143527][0];assert c['name']=='Lumenfall pre-merge validation' and c['app']['id']==15368 and c['conclusion']=='success'
manifest=json.loads((R/'final-task/SHA256SUMS.json').read_text())
for n,h in manifest.items():assert hashlib.sha256((R/'final-task'/n).read_bytes()).hexdigest()==h,n
source=json.loads((R/'finish/source-identity.json').read_text())
for e in source:
 b=(R/'startup-source'/e['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==e['sha256']
 assert (R/'final-task/source-input/candidate'/e['path']).read_bytes()==b
chrome=Path('/tmp/lumenfall-core01-153-20261003/chrome-headless-shell-linux64/chrome-headless-shell');assert hashlib.sha256(chrome.read_bytes()).hexdigest()=='1346545781835e04ece3434a16d656ad5cbe60a6a179a43dff43f79a21f9a4ad'
old=(R/'atomic-finish/pr40-evidence/atomic-observer.js').read_text();observer=old
assert observer.count('r.state.enemyHp===6.4')==1 and observer.count('proof.expected.enemyHp=6.400000000000001;')==1
observer=observer.replace('r.state.enemyHp===6.4','r.state.enemyHp===6.5').replace('proof.expected.enemyHp=6.400000000000001;','')
needle="'exact authorized HP fixture before repeat');";assert observer.count(needle)==1
observer=observer.replace(needle,needle+"ok(r.state.heroResource.ember===75,'exact Ember resource75 before repeat');")
observer=observer.replace('REVIDERET ORACLE / ATOMISK ORCHESTRATION','KORRIGERET ATOMISK ORACLE / UÆNDRET EXPECTED STATE')
page=(R/'atomic-finish/pr40-stage/index.html').read_text();assert page.count(old)==1
page=page.replace(old,observer)
(O/'atomic-observer.js').write_text(observer);(S/'index.html').write_text(page)
for folder in ['fonts','branding']:shutil.copytree(R/'startup-source'/folder,S/folder,dirs_exist_ok=True)
oldDriver=(R/'atomic-finish/pr40-evidence/review.cjs').read_text();oldPath='/workspace/scratch/f5911b1189e0/startup-runtime/chrome-headless-shell-linux64/chrome-headless-shell';assert oldDriver.count(oldPath)==1
driverText=oldDriver.replace(oldPath,str(chrome));driver=driverText.encode();(O/'review.cjs').write_bytes(driver)
(F/'oracle-observer.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),observer.splitlines(True),fromfile='previous-atomic/observer',tofile='corrected-atomic/observer')))
(F/'review-driver.diff').write_text(''.join(difflib.unified_diff(oldDriver.splitlines(True),driverText.splitlines(True),fromfile='previous-atomic/review.cjs',tofile='corrected-atomic/review.cjs')))
(O/'construction-hashes.json').write_text(json.dumps({'candidate_index':hashlib.sha256((R/'startup-source/index.html').read_bytes()).hexdigest(),'old_atomic_stage':hashlib.sha256((R/'atomic-finish/pr40-stage/index.html').read_bytes()).hexdigest(),'positive_stage':hashlib.sha256(page.encode()).hexdigest(),'observer':hashlib.sha256(observer.encode()).hexdigest(),'driver':hashlib.sha256(driver).hexdigest(),'driver_only_runtime_path_changed':True,'task_manifest_entries_verified':len(manifest),'source_blobs_verified':len(source)},indent=2))
# Validate supplied Lead controls without running them.
lead=R/'final-task/lead-controls';proofs=[]
for variant,names in [('main',['07-cross-43-cold']),('parent',['07-cross-43-cold']),('head',['07-cross-43-cold','07-cross-43-visibility','07-cross-55-cold','07-cross-55-visibility'])]:
 for name in names:
  proof=json.loads((lead/variant/'pr40-evidence'/f'{name}.json').read_text());assert proof['status']=='pass'
  before=proof['beforeRepeat']['state'];assert before['enemyHp']==6.5 and before['heroResource']['ember']==75 and proof['expected']==before
  for phase in proof['bootPhases']:
   if phase['phase'] in ['repeat','additional']:
    actual=phase['actual'];assert actual['state']==before and json.loads(actual['primary'])==before and json.loads(actual['recovery'])==before
  proofs.append((variant,name,proof))
assert proofs[0][2]['input']==proofs[1][2]['input']==proofs[2][2]['input']
assert proofs[0][2]['beforeRepeat']['state']==proofs[1][2]['beforeRepeat']['state']==proofs[2][2]['beforeRepeat']['state']
(F/'supplied-lead-controls-validation.json').write_text(json.dumps({'checks_validated':len(proofs),'source':'supplied Lead evidence, not new execution','main_parent_head_43_inputs_and_whole_before_states_equal':True,'both_whole_state_primary_recovery_reload_checks_validated':True},indent=2))
print('Full checkpoint, runtime and65 source blobs verified; Lead manifest',len(manifest),'verified;6 supplied controls validated; corrected oracle prepared.')
