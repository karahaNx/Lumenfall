from pathlib import Path
import json,hashlib,shutil,zipfile,sys
R=Path(__file__).resolve().parent;F=R/'corrected-finish';O=F/'pr40-evidence';D=R/'deliverables'
def data(phase,key):
 s=json.loads((F/f'checkpoint-{phase}/{key}.json').read_text())['structuredContent'];return json.loads(s['content']) if 'content' in s else s
for phase in ['before','after']:
 p=data(phase,'pr');h=data(phase,'head');m=data(phase,'main');w=data(phase,'run');checks=data(phase,'checks')
 assert p['head_sha']=='d3daa23d04315ec21776de69b0df960d24cb19b6' and p['base_sha']=='3a89a8cb4084193326daa5dab68cf9a89ef71512' and p['draft'] and not p['merged'] and p['state']=='open'
 assert h['tree']['sha']=='d1d128a82f6bc204655dc662a5239f98dca51059' and [x['sha'] for x in h['parents']]==['9348a48364dcd88b77b9d1bc00763b83c6f8e768']
 assert m['commit']['sha']==p['base_sha'] and m['commit']['commit']['tree']['sha']=='134b5f21f414f56ecd446220c8ffc54a0621ca3e'
 assert w['head_sha']==p['head_sha'] and w['run_number']==121 and w['run_attempt']==1 and w['event']=='pull_request' and w['status']=='completed' and w['conclusion']=='success'
 c=[x for x in checks['check_runs'] if x['id']==111074143527][0];assert c['name']=='Lumenfall pre-merge validation' and c['app']['id']==15368 and c['conclusion']=='success'
source=json.loads((R/'finish/source-identity.json').read_text())
for e in source:assert hashlib.sha256((R/'startup-source'/e['path']).read_bytes()).hexdigest()==e['sha256']
runtime=json.loads((O/'runtime.json').read_text());assert hashlib.sha256(Path(runtime['executable']).read_bytes()).hexdigest()==runtime['sha256']=='1346545781835e04ece3434a16d656ad5cbe60a6a179a43dff43f79a21f9a4ad'
construction=json.loads((O/'construction-hashes.json').read_text());assert hashlib.sha256((F/'pr40-stage/index.html').read_bytes()).hexdigest()==construction['positive_stage']
receipts=json.loads((O/'run-summary.json').read_text());assert len(receipts)==10 and all(not x['process_timed_out'] for x in receipts)
assert sum(x['exit_code']==0 for x in receipts)==7 and sum(x['exit_code']==1 for x in receipts)==3
summary=[]
for x in receipts:
 proof=json.loads((O/(x['label']+'.atomic-proof.json')).read_text());s=proof['beforeRepeat']['state'];assert s['enemyHp']==6.5 and s['heroResource']['ember']==75 and proof['expected']==s
 summary.append({'label':x['label'],'expected_execution_outcome':'positive PASS' if x['exit_code']==0 else 'negative actual assertion FAIL','exit_code':x['exit_code'],'elapsed_seconds':x['elapsed_seconds'],'fixture_hp':s['enemyHp'],'fixture_resource':s['heroResource']['ember'],'stage_sha256':x['stage_sha256']})
(O/'completion-summary.json').write_text(json.dumps({'conclusion':'ACCEPTABEL','startup_fund1':'LUKKET','scope':'Exact PR40 persistence HEAD/tree/base only; no integration/merge/device acceptance','results':summary},indent=2))
shutil.copyfile(R/'finish/source-identity.json',F/'source-identity.json')
shutil.copytree(R/'final-task',F/'supplied-lead-task',dirs_exist_ok=True)
history=F/'historical';history.mkdir(exist_ok=True)
old=D/'Lumenfall_PR40_Atomisk_Resultat_01_06_2026-10-03.zip';shutil.copyfile(old,history/old.name)
with zipfile.ZipFile(old) as z:
 entries=z.read('SHA256SUMS.txt').decode().splitlines()
 for line in entries:
  h,n=line.split('  ',1);assert hashlib.sha256(z.read(n)).hexdigest()==h
(F/'historical-verification.json').write_text(json.dumps({'archive':old.name,'sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'manifest_entries_verified':len(entries),'original_own19_and_all_intermediate_fail_receipts_retained_in_nested_archives':True},indent=2))
for name in ['corrected_setup.py','corrected_run.py','corrected_package.py']:shutil.copyfile(R/name,F/name)
shutil.copyfile(R/'atomic-finish/pr40-evidence/atomic-observer.js',F/'previous-atomic-observer.js')
shutil.copyfile(R/'atomic-finish/pr40-evidence/review.cjs',F/'previous-atomic-review.cjs')
(F/'runtime-recovery.json').write_text(json.dumps({'previous_binary_missing':True,'same_version_download_required':True,'same_binary_sha256_recovered':runtime['sha256'],'final_executable':runtime['executable'],'earlier_workspace_extraction_truncated_and_not_executed':True,'setup_errors_not_counted_as_product_tests':True},indent=2))
(F/'final-identity.json').write_text(json.dumps({'runtime':runtime,'python':sys.version,'construction':construction,'source_blobs_unchanged':65,'positive_stage_restored_at_completion':True,'checkpoint_drift':False},indent=2))
(F/'REPRODUCE.txt').write_text('Use the verified Chromium Headless Shell153.0.8010.0 binary (SHA256 in runtime.json); adjust only executable/source/stage paths for a new workspace. The current positive page, fonts/branding and driver are supplied directly. A targeted reproduction uses CORE40_ONLY=07-cross-43-cold with the included pr40-evidence/review.cjs. corrected_run.py runs only four candidate cases, then three disposable repeat-phase negative stages with actual positive source-restored undo after each. The positive page is restored by literal bytes, not by repairing loaded state. Full construction is reproducible from previous-atomic-observer.js and the previous atomic stage in historical ZIP, applying oracle-observer.diff. The observer changes only before6.5, Ember75 assertion, unchanged expected deep-copy and result label. Main/parent Lead controls are supplied for evidence reuse and must not be rerun as part of this task.\n')
report='''Til 00_07 — Lead / Architecture
Fra 01_06 — Core / Android / APK
Lumenfall · PR #40 · 2026-10-03
Work · GPT 6.1 Sol · High

KONKLUSION: ACCEPTABEL PÅ PRÆCIS TESTET HEAD/TREE/BASE
Den smalle persistence-afslutning består den endelige Lead-kontrakt.
Startup Fund1: LUKKET. Fire egne nye atomiske candidate-cases består med
bitpræcis whole-state/primary/recovery gennem begge genuine zero-time reloads.
Tre separate actual-mutations afvises ved den tilsigtede whole-state assertion;
tre faktiske source-restored positive undo består. Ingen produktkode ændret.
Dette er persistence-accept, ikke Ready-, integrations-, merge- eller APK-frigivelse.

IMMUTABLE CHECKPOINT — LIVE VERIFICERET FØR OG EFTER
PR: https://github.com/karahaNx/Lumenfall/pull/40
Branch: 02/auto-ascend-target-selector; open/Draft/unmerged.
HEAD: d3daa23d04315ec21776de69b0df960d24cb19b6
Tree: d1d128a82f6bc204655dc662a5239f98dca51059
Eneste parent: 9348a48364dcd88b77b9d1bc00763b83c6f8e768
Main/base: 3a89a8cb4084193326daa5dab68cf9a89ef71512
Main tree: 134b5f21f414f56ecd446220c8ffc54a0621ca3e
Candidate index.html SHA256:
a2797073f985da25803c61e2626ef54f662dfbc5d0dbd240156e47cff76acd96
Alle65 sourceblobs matcher tidligere live Git-blob/SHA256-identity på den
uændrede tree samt de nye vedlagte candidate-inputbytes. Efterkontrol består.
CI121 run37078662885, attempt1/pull_request/completed/success på exact HEAD.
Check111074143527: Lumenfall pre-merge validation/app15368/success.
Ingen checkpoint-drift; remote checks er observeret, ikke manuelt genstartet.

EGNE NYE RESULTATER
Label: KORRIGERET ATOMISK ORACLE / UÆNDRET EXPECTED STATE

Case                         Resultat   Node exit   Processekunder
07-cross-43-cold              PASS       0           3.860
07-cross-43-visibility        PASS       0           2.531
07-cross-55-cold              PASS       0           2.589
07-cross-55-visibility        PASS       0           2.113

Alle fire har præcis before-repeat HP6.5/max11, enemyDepth/depth1 og
Ember-resource75. Expected er en dyb kopi af HELE before-state og forbliver
urørt. Ingen HP-overskrivning eller restorehelper i forventningsoraclen.
Begge efterfølgende genuine zero-time reloads bevarer hele runtime state,
canonical primary og recovery bitpræcist mod den uændrede expected-state.

Uændrede centrale literals og gameplaychecks:
  Clear43 -> target44, Prisms23 fra10; Clear55 -> target56, Prisms24 fra10.
  Comets22 fra7 (+15 én gang); guardmastery1; activeStudies[];
  én kill; én Ascend; benchmark43/55; depth1;
  lastSeen2000000005500; offline5.5s; én faktisk offline-call.
  Ingen duplikeret betaling ved repeat; metadata/save-events er bounded.
Duplicate visibility(false)-kontrollen er uændret og observer-pure.
Fulde input/seed-before/inputSnapshot/beforeRepeat/expected/bootPhases med
state, primary, recovery, events, clocks, fase og flags findes i hver
*.corrected.atomic-proof.json. Positive resultater har ingen pageerrors.

ATOMISK ORCHESTRATION / GUARD
Den allerede godkendte seed/lifecycle/unload/DOMContentLoaded-orchestration
er bevaret. Seed/study/save/input/catchup/unload ligger i synkrone browsertasks.
Bootmålinger og assertions ligger umiddelbart efter normal init, før guard.
Oprindelig suppressUnloadSave bruges kun til den forestående genuine
navigation. Flags er reload=false/reset=false ved hver ny genuine boot;
unloadforberedelse ændrer alene guard til reload=true/reset=false og ændrer
ikke state eller diskbytes. Ny init er den eneste guard-frigivelse.
Ingen intervalpause, clearInterval, tick-mock eller manuel flagfrigivelse.
Dette reload-review bruges ikke som nyt livenessbevis.

KAUSAL NEGATIVE / ACTUAL SOURCE-RESTORED UNDO
Tre disposable lokale stages wrapper den oprindelige restoreEnemyOrSpawn.
Wrapperen kalder først original callback og muterer kun i sessionens
repeat-fase, efter et gyldigt before6.5-snapshot. Produktrepo er urørt.

Mutation                        Actual / expected                 Exit / tid
extra-hp.negative               6.500000000000001 / 6.5           1 / 1.909s
extra-target.negative           target45 / target44              1 / 1.679s
extra-reward.negative           Prisms24 / Prisms23              1 / 3.123s

Alle tre fejler præcis ved "REVISED ORACLE full repeat state actual=...";
det er den eksisterende assertiontekst, mens resultaternes label er korrigeret.
Før-snapshot og expected er gyldige og uændrede. Hele diffen består af netop
det ene muterede field i hver case; alle øvrige statefelter matcher. Begge
canonical saves indeholder samme actual mutation. Ingen fixturefailure,
runtime-pageerror eller timeout bruges som negative-bevis.

Efter hver mutation er de faktiske positive stagebytes skrevet tilbage,
hashkontrolleret og samme43-cold kørt igen med uændret driver:
  extra-hp.source-restored-undo: PASS/exit0,2.179s.
  extra-target.source-restored-undo: PASS/exit0,2.384s.
  extra-reward.source-restored-undo: PASS/exit0,2.169s.
Alle tre undo bevarer hele expected state og begge saves gennem begge reloads.
Original positiv pagehash og hver restored pagehash er identiske:
b9069e40e0d1aa6cc40f640ce23944e598900820615ef00f4506c3d31022c62a
Positive/negative/restored HTML-bytes, tre små mutationdiffs, præcise diffJSON,
process/stdout/stderr og source-restored-receipts.json er vedlagt.
Negative FAIL er kontrolresultater, ikke produkt-PASS.

PRÆCIS DRIVER-/ORACLE-DIFF
oracle-observer.diff ændrer alene before6.4 til6.5, tilføjer exact Ember75,
fjerner expected.enemyHp-overskrivningen og retter resultatlabel.
Alle setup-literals, clocks5500ms, produktcallbacks, heltals-/eventassertions
og whole-state-comparisons er uændrede. review-driver.diff ændrer alene
browserbinary-stien, fordi den gamle scratch-runtime var forsvundet.
Ingen epsilon, rounding, HP-exclusion, dynamisk gættet HP eller general ULP-regel.
Actual state og saves er aldrig repareret i positive tests.

RUNTIME / PROCESS / IDENTITET
Chromium Headless Shell153.0.8010.0 via Playwright; Node24.19.0.
Den tidligere executable manglede. Samme version blev derfor genskabt, og
den faktisk anvendte binary matcher præcis den tidligere SHA256:
1346545781835e04ece3434a16d656ad5cbe60a6a179a43dff43f79a21f9a4ad
En første scratch-extraction blev trunkeret og nåede ikke produktkørsel;
intakt runtime blev verificeret på den endelige path før alle ti tests.
Setupfejl tælles ikke som produktresultater. Path/version/hash/Python står
i runtime.json, final-identity.json og runtime-recovery.json.
Driver SHA256:
bc972d1cdf040b95ded715fbf70b0e1a80ac6d21ee3512ff3be58c6ae6a084ba
Observer SHA256:
cc6c914beb07d443a7c47d9d874c332a146ae2320dd213051621230277b450e1
Ti målrettede Nodeprocesser:7 positive exit0 og3 tilsigtede negative exit1;
alle er under den uændrede60s ydre deadline uden proces-timeout. Driverens
page.goto-/5000ms boot-wait og oprindelige exception/filter-gates er uændrede.
Fuld Node stdout/stderr, exit/elapsed/deadline/argv og stagehash pr.process
er gemt. Browser-pageerrors er observeret; særskilt rå Chromium-stderr/exit
fra Playwright hævdes ikke. Ingen bred suite er kørt.

GENBRUGT LEAD-/EGEN EVIDENS OG HISTORIK
Den nye Lead-taskmanifest121/121 er verificeret. Seks supplied Lead-results
(main/parent/head43-cold samt headens øvrige tre cases) er læst og kontrolleret:
whole before/input er ens på main/parent/head; begge reloads bevarer hele
state/primary/recovery. Ingen main/parent-kørsel er gentaget her.
Parentens separate atomic-proof-fil stopper ved repeat; dens samlede result-
JSON indeholder additional-fasen og PASS. Validation bruger de komplette
result-JSON'er og påstår ikke, at den korte proof-fil alene dækker additional.
Leads støttekontroller er ikke ommærket som mine egne nye executions.

Original own19 forbliver14PASS/5FAIL. Tidligere43-cold revideret PASS,
visibility prerequisite FAIL og atomisk6.4-forudsætning FAIL bevares i
historical ZIP med nested original evidence. Historical manifest144/144
er verificeret igen. De gamle FAIL kvitteringer er ikke rettet eller ommærket.
Tidligere14PASS,11 genuine bootcases,11195 window/nav-assertions i12profiler,
isolated backup purity samt særskilt unpaused-livenessbevis genbruges inden
for deres scope. Backup purity er ikke liveness. Startup Fund1 er LUKKET.
QA Window/UI-accept og P3 Find-backlog er separate Lead-beslutninger.

GRÆNSER / AFLEVERING
ACCEPTABEL betyder den afgrænsede persistence-vurdering på exact HEAD/tree/base.
Ingen fysisk Android/A40/TalkBack, APK/signing/emulator eller deviceaccept.
Ingen repo-edit, branch/commit/push, reviewpublicering, Ready, merge, APK,
manuel CI, nye workers, ny own19-/121-suite, bred audit eller QA-genstart.
00_07 tager selv næste integrationsbeslutning efter kontrol af TXT+ZIP.
Manifest, komplet rå evidens, sourceinputs, stagebytes og reproduktionsstøtte
følger med. Accept overføres ikke til en ændret kandidat.
'''
name='Lumenfall_PR40_Endelig_Persistence_01_06_2026-10-03'
(F/(name+'.txt')).write_text(report);(D/(name+'.txt')).write_text(report)
manifest=[]
for p in sorted(F.rglob('*')):
 if p.is_file() and p.name!='SHA256SUMS.txt':manifest.append(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(F).as_posix())
(F/'SHA256SUMS.txt').write_text('\n'.join(manifest)+'\n')
for line in manifest:
 h,n=line.split('  ',1);assert hashlib.sha256((F/n).read_bytes()).hexdigest()==h
with zipfile.ZipFile(D/(name+'.zip'),'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(F.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(F))
print('ACCEPTABEL; unchanged checkpoint; manifest',len(manifest),'verified; ZIP bytes',(D/(name+'.zip')).stat().st_size)
