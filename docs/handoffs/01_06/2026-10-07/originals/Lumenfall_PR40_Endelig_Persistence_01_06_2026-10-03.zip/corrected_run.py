from pathlib import Path
import subprocess,os,json,time,hashlib,shutil,difflib
R=Path(__file__).resolve().parent;F=R/'corrected-finish';O=F/'pr40-evidence';stage=F/'pr40-stage/index.html';driver=O/'review.cjs';node=os.environ['CODEX_PRIMARY_RUNTIME_NODE'];receipts=[]
cases=['07-cross-'+str(c)+'-'+route for c in [43,55] for route in ['cold','visibility']]
def run(name,label,expected_code,field=None,value=None):
 env=os.environ.copy();env['CORE40_ONLY']=name;t=time.monotonic();timed=False
 try:p=subprocess.run([node,str(driver)],env=env,capture_output=True,timeout=60);code=p.returncode;stdout=p.stdout;stderr=p.stderr
 except subprocess.TimeoutExpired as e:timed=True;code=None;stdout=e.stdout or b'';stderr=e.stderr or b''
 (O/(label+'.stdout.txt')).write_bytes(stdout);(O/(label+'.stderr.txt')).write_bytes(stderr)
 receipt={'exit_code':code,'process_timed_out':timed,'process_timeout_seconds':60,'elapsed_seconds':time.monotonic()-t,'argv':[node,str(driver)],'scenario':name,'label':label,'oracle':'KORRIGERET ATOMISK ORACLE / UÆNDRET EXPECTED STATE','driver_sha256':hashlib.sha256(driver.read_bytes()).hexdigest(),'stage_sha256':hashlib.sha256(stage.read_bytes()).hexdigest()}
 (O/(label+'.process.json')).write_text(json.dumps(receipt,indent=2));receipts.append(receipt)
 for suffix in ['.json','.atomic-proof.json']:
  if (O/(name+suffix)).exists():shutil.copyfile(O/(name+suffix),O/(label+suffix))
 assert not timed and code==expected_code,receipt
 result=json.loads((O/(label+'.json')).read_text());proof=json.loads((O/(label+'.atomic-proof.json')).read_text())
 assert proof['beforeRepeat']['state']['enemyHp']==6.5 and proof['beforeRepeat']['state']['heroResource']['ember']==75
 assert proof['expected']==proof['beforeRepeat']['state'],'whole expected copy must remain unchanged'
 if expected_code==0:
  assert result['status']=='pass' and proof['status']=='pass'
  for phase in proof['bootPhases']:
   assert phase['actual']['flags']=={'reloadInProgress':False,'resetInProgress':False}
   if phase['phase'] in ['repeat','additional']:
    a=phase['actual'];assert a['state']==proof['expected'] and json.loads(a['primary'])==proof['expected'] and json.loads(a['recovery'])==proof['expected']
 else:
  assert result['status']=='fail' and result['error'].startswith('Error: REVISED ORACLE full repeat state actual='),result
  assert proof['bootPhases'][-1]['phase']=='repeat','negative must hit genuine repeat after valid before-state'
  actual=proof['bootPhases'][-1]['actual']['state'];assert actual[field]==value
  expected=proof['expected'];diff={k:{'actual':actual.get(k),'expected':expected.get(k)} for k in actual.keys()|expected.keys() if actual.get(k)!=expected.get(k)}
  assert set(diff)=={field},diff
  for k in ['primary','recovery']:assert json.loads(proof['bootPhases'][-1]['actual'][k])==actual
  (O/(label+'.exact-difference.json')).write_text(json.dumps(diff,indent=2))
 print(label,'PASS' if code==0 else 'EXPECTED WHOLE-STATE ASSERTION FAIL',round(receipt['elapsed_seconds'],3),flush=True)
baseline=stage.read_bytes();baseline_hash=hashlib.sha256(baseline).hexdigest();shutil.copyfile(stage,O/'positive-stage.html')
for name in cases:run(name,name+'.corrected',0)
marker=b'window.__core40={';assert baseline.count(marker)==1
restore=[]
for label,statement,field,value in [('extra-hp','state.enemyHp=6.500000000000001;','enemyHp',6.500000000000001),('extra-target','state.autoAscendTargetDepth=45;','autoAscendTargetDepth',45),('extra-reward','state.prisms=24;','prisms',24)]:
 wrapper=("var core40NegativeOriginalRestore=restoreEnemyOrSpawn;\nrestoreEnemyOrSpawn=function(){core40NegativeOriginalRestore();if(sessionStorage.getItem('core40-atomic-phase')==='repeat'){"+statement+"}};\n").encode()
 mutated=baseline.replace(marker,wrapper+marker);stage.write_bytes(mutated);shutil.copyfile(stage,O/(label+'.negative.html'))
 (O/(label+'.mutation.diff')).write_text(''.join(difflib.unified_diff(baseline.decode().splitlines(True),mutated.decode().splitlines(True),fromfile='positive-stage',tofile=label+'-negative-stage')))
 try:run(cases[0],label+'.negative',1,field,value)
 finally:stage.write_bytes(baseline)
 assert stage.read_bytes()==baseline and hashlib.sha256(stage.read_bytes()).hexdigest()==baseline_hash
 restored=O/(label+'.source-restored-undo.html');shutil.copyfile(stage,restored);assert restored.read_bytes()==baseline
 restore.append({'mutation':label,'positive_stage_sha256':baseline_hash,'restored_stage_sha256':hashlib.sha256(restored.read_bytes()).hexdigest(),'actual_bytes_restored_before_positive_undo':True})
 run(cases[0],label+'.source-restored-undo',0)
(O/'run-summary.json').write_text(json.dumps(receipts,indent=2));(O/'source-restored-receipts.json').write_text(json.dumps(restore,indent=2));assert stage.read_bytes()==baseline
print('Four corrected candidate cases PASS; three precise negatives rejected; three source-restored undos PASS.',flush=True)
