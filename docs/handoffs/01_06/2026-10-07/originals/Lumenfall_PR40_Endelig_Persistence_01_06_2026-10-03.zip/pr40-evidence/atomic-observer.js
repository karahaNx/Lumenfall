
(function(){
const c=window.__core40,b=window.__lumenfallQaBridge,ctx=window.__lumenfallQaContext,T=2000000000000;
const K='core40-atomic-proof',P='core40-atomic-phase';
function ok(v,m){if(!v)throw Error(m);}
function eq(a,b,m){ok(JSON.stringify(a)===JSON.stringify(b),m+' actual='+JSON.stringify(a)+' expected='+JSON.stringify(b));}
function seedNow(opts){const b=__lumenfallQaBridge,c=__core40,ctx=__lumenfallQaContext;ctx.setClock(T);let s=b.freshStateSnapshot();s.questDay=ctx.currentDay();s.loginStreak=1;s.maxDepthEver=101;s.depth=1;s.enemyDepth=1;s.enemyHp=s.enemyMaxHp=b.enemyHpFor(1);s.owned.autoascend=true;s.autoAscendEnabled=false;s.autoAscendTargetDepth=44;s.comets=7;s.prisms=10;s.lumen=11;s.shards=23;s.research.arcanecal=4;s.activeStudies=[{id:'guardmastery',totalDurationSec:150,remainingSec:100,speedMult:2}];c.achievementIds().forEach(id=>s.achieved[id]=true);s.achieved.autotap=false;s.achieved.labmaster=false;s.achieved.labqueue=false;Object.assign(s,opts);if(opts.depth!==undefined){s.enemyDepth=s.depth;s.enemyMaxHp=b.enemyHpFor(s.depth);s.enemyHp=opts.enemyHp===undefined?s.enemyMaxHp:opts.enemyHp;}b.setState(s);c.save();c.render();return c.snapshot();}
function crossChecks(r,input,clear){const reward=clear===43?13:14;ok(r.state.autoAscendTargetDepth===clear+1,'chosen target unchanged through boundary');ok(r.state.ascendCount===input.ascendCount+1&&r.state.prisms===input.prisms+reward,'exactly one independent Ascend reward');ok(r.state.ascendRewardedDepth===clear,'no premature/higher-clear credit');ok(r.state.depth===1&&r.state.totalKills===input.totalKills+1,'exact target defeated once, no second cycle');ok(r.state.longStudyLevels.guardmastery===1&&r.state.activeStudies.length===0,'paid Study completes');ok(r.state.comets===input.comets+15,'FirstDiscovery15 once');ok(r.state.lastSeen===T+5500&&r.state.totalOfflineSeconds===input.totalOfflineSeconds+5.5,'exact lastSeen/catchup');eq(JSON.parse(r.primary),r.state,'full primary canonical');eq(r.recovery,r.primary,'full recovery canonical');ok(r.events.filter(e=>e.type==='offline'&&e.detail.result).length===1,'one actual offline call');ok(r.events.filter(e=>e.type==='save').every(e=>e.detail.beforeLastSeen<=T+5500),'metadata bounded');ok(r.state.enemyHp===6.5&&r.state.enemyMaxHp===11&&r.state.enemyDepth===1&&r.state.depth===1,'exact authorized HP fixture before repeat');ok(r.state.heroResource.ember===75,'exact Ember resource75 before repeat');
}
function prepare(advance,next,proof){
 const before=c.snapshot(),raw=b.rawSave(),clockBefore=ctx.clockNow();
 localStorage.setItem(ctx.phaseKey,'1');ctx.advanceTime(advance);b.suppressUnloadSave();
 const after=c.snapshot();ok(before.flags.reloadInProgress===false&&before.flags.resetInProgress===false,'normal flags before genuine unload preparation');
 ok(after.flags.reloadInProgress===true&&after.flags.resetInProgress===false,'original suppressUnloadSave sets only reload guard');
 eq(after.state,before.state,'unload preparation does not repair actual state');eq(after.primary,before.primary,'unload preparation does not repair primary');eq(after.recovery,before.recovery,'unload preparation does not repair recovery');
 proof.unloadPreparations.push({advance,next,before,after,request:{diskBeforeUnload:raw,flags:b.getFlags()},clockBefore,clockAfter:ctx.clockNow(),phaseKey:localStorage.getItem(ctx.phaseKey)});
 sessionStorage.setItem(P,next);sessionStorage.setItem(K,JSON.stringify(proof));
}
function measureBefore(r,proof){
 proof.beforeRepeat=r;crossChecks(r,proof.input,proof.clear);
 proof.expected=JSON.parse(JSON.stringify(r.state));
 prepare(0,'repeat',proof);
}
function preserveFailure(proof,e){proof.status='fail';proof.failure=e.stack;proof.failureCollector=c.snapshot();sessionStorage.setItem(K,JSON.stringify(proof));c.atomicFailure=proof;}
c.atomicStart=function(clear,route){
 const proof={clear,route,oracleLabel:'KORRIGERET ATOMISK ORACLE / UÆNDRET EXPECTED STATE',unloadPreparations:[],bootPhases:[]};
 try{
  proof.before=seedNow({autoAscendTargetDepth:clear+1,autoAscendEnabled:true,depth:clear,enemyHp:1,activeStudies:[{id:'guardmastery',totalDurationSec:150,remainingSec:.5,speedMult:2}]});
  const s=b.getState();s.achieved.study1=false;b.setState(s);c.save();proof.input=JSON.parse(b.rawSave());proof.inputSnapshot=c.snapshot();
  if(route==='cold'){prepare(5500,'catchup',proof);}
  else{
   b.clearLifecycleTrace();b.dispatchVisibility(true);b.advanceTime(5500);b.dispatchVisibility(false);
   const first=c.snapshot();proof.beforeRepeat=first;
   b.dispatchVisibility(false);const second=c.snapshot();proof.duplicateVisibility=second;
   if(JSON.stringify(first)!==JSON.stringify(second))throw Error('duplicate visibility changed result');
   measureBefore(first,proof);
  }
 }catch(e){preserveFailure(proof,e);}
 return proof;
};
c.atomicBootObserver=function(){
 const phase=sessionStorage.getItem(P);if(!phase)return;
 const proof=JSON.parse(sessionStorage.getItem(K));if(proof.status==='fail')return;
 const actual=c.boot;proof.bootPhases.push({phase,actual,clock:ctx.clockNow(),phaseKey:localStorage.getItem(ctx.phaseKey)});
 try{
  ok(actual.flags.reloadInProgress===false&&actual.flags.resetInProgress===false,'new genuine init restores normal flags');
  if(phase==='catchup'){measureBefore(actual,proof);}
  else if(phase==='repeat'){
   eq(actual.state,proof.expected,'REVISED ORACLE full repeat state');eq(JSON.parse(actual.primary),proof.expected,'REVISED ORACLE full repeat primary');eq(JSON.parse(actual.recovery),proof.expected,'REVISED ORACLE full repeat recovery');
   prepare(0,'additional',proof);
  }else if(phase==='additional'){
   eq(actual.state,proof.expected,'projected state stable on additional zero-time reload');eq(JSON.parse(actual.primary),proof.expected,'stable full primary');eq(JSON.parse(actual.recovery),proof.expected,'stable full recovery');
   proof.status='pass';sessionStorage.setItem(K,JSON.stringify(proof));c.atomicComplete=proof;
  }else throw Error('unknown atomic observation phase');
 }catch(e){preserveFailure(proof,e);}
};
})();
