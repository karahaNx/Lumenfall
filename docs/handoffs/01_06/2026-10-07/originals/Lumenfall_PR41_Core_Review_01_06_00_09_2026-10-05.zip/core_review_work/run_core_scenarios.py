from pathlib import Path
import subprocess,os,json,datetime,time
work=Path(__file__).resolve().parent
root=work/'Lumenfall-10f2ff5facef78a7c1d8293b6a8d07be888f7350'
out=work/'evidence';out.mkdir(exist_ok=True)
env=os.environ.copy();env['PATH']=str(work/'bin')+os.pathsep+env['PATH']
scenarios=['inquiry-contracts','inquiry-chronology','inquiry-save-reload','inquiry-backup-restore','inquiry-recovery','inquiry-reset','inquiry-ui','fresh-load','midgame-load','mature-load','legacy-load','corrupted-load','malformed-daily-load','active-studies-load','reset-roundtrip','restore-roundtrip','malformed-backup-rejection','recovery-from-corrupt-primary','unsupported-future-load','legacy-backup-restore','future-backup-rejection','recovery-offline-once','save-failure-warning','p2-07a-persistence-review','p2-07a-persist-save-reload','p2-07a-persist-backup-restore','p2-07a-persist-recovery','p2-07a-persist-reset','chronology-study-mid-window','chronology-simultaneous-order']
receipts=[]
for name in scenarios:
 cmd=['python',str(root/'tests/behavioral/run.py'),'--web-root',str(root),'--scenario',name,'--raw-artifacts',str(work/'raw')]
 at=datetime.datetime.now(datetime.timezone.utc).isoformat();start=time.monotonic()
 p=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=65)
 (out/(name+'.log')).write_text(p.stdout+p.stderr)
 receipts.append({'scenario':name,'command':cmd,'started_at':at,'elapsed_seconds':round(time.monotonic()-start,3),'exitcode':p.returncode,'pass':p.returncode==0,'log':name+'.log'})
 (out/'scenario_receipts.json').write_text(json.dumps(receipts,indent=2))
 print(('PASS ' if p.returncode==0 else 'FAIL ')+name,flush=True)
 if p.returncode:print((p.stdout+p.stderr)[-2400:],flush=True)
print(json.dumps({'passed':sum(x['pass'] for x in receipts),'total':len(receipts)}),flush=True)
raise SystemExit(any(not x['pass'] for x in receipts))
