from pathlib import Path
import importlib.util,json,shutil,threading,subprocess,os,datetime
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from functools import partial
work=Path(__file__).resolve().parent
root=work/'Lumenfall-10f2ff5facef78a7c1d8293b6a8d07be888f7350'
spec=importlib.util.spec_from_file_location('candidate_harness',root/'tests/behavioral/run.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
stage=work/'independent_stage';shutil.copytree(root,stage,dirs_exist_ok=True)
source=(root/'index.html').read_text()
marker='\n})();\n</script>\n<script>\nif(window.Capacitor'
core='''
window.__coreReview={
 write:function(action){var prior=reloadInProgress;reloadInProgress=false;try{return action();}finally{reloadInProgress=prior;}},
 save:function(){return this.write(function(){return saveState();});},
 queue:function(id){return this.write(function(){document.querySelector('[data-study-queue="'+id+'"]').click();return true;});},
 ascend:function(){return this.write(function(){doAscend(false);return true;});},
 plan:function(id){return getStudyStartPlan(LONG_STUDIES.find(function(n){return n.id===id;}));},
 tail:function(sec){var s=simulationSummary(sec);advanceStudyOnlyTime(sec,Date.now(),s);return s;},
 liveComplete:function(sec){return advanceActiveStudies(sec);},
 authoritative:function(sec,kind){return advanceAuthoritativeTime(sec,{kind:kind,visual:false,clockStartMs:Date.now(),captureTimeline:true});},
 guardFlags:function(){return {reload:reloadInProgress,reset:resetInProgress};},
 parse:function(input){return acceptPersistedState(input,'independent');},
 due:function(){var s=simulationSummary(0);var handled=simulationCompleteDueStudies(s);return {handled:handled,summary:s};}
};
'''
assert source.count(marker)==1
source=source.replace(marker,'\n'+core+marker)
original_runner=h.build_runner
h.build_runner=lambda:'''<script>document.addEventListener('DOMContentLoaded',function(){window.__lumenfallQaBridge.freeze();window.__lumenfallQaBridge.resetFeedback();window.__coreReady=true;});</script>'''
(stage/'index.html').write_text(h.instrument_html(source,h.load_fixtures()))
base=(work.parent/'pr41_review/source/base/index.html').read_text()
assert base.count(marker)==1
(stage/'base.html').write_text(h.instrument_html(base.replace(marker,'\n'+core+marker),h.load_fixtures()))
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(stage)))
thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
env=os.environ.copy();env['CORE_BROWSER']=str(work/'browser/chrome-linux/headless_shell');env['CORE_URL']=f'http://127.0.0.1:{server.server_address[1]}/index.html?qaScenario=core-independent&qaFixture=fresh';env['CORE_OUT']=str(work/'evidence/independent_core.json')
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
try:
 p=subprocess.run(['node',str(work/'independent_core.cjs')],env=env,capture_output=True,text=True,timeout=100)
 (work/'evidence/independent_core.log').write_text(p.stdout+p.stderr)
 (work/'evidence/independent_command.json').write_text(json.dumps({'command':['python',str(Path(__file__).resolve())],'started_at':started,'exitcode':p.returncode,'harness_original':str(root/'tests/behavioral/run.py'),'instrumentation':'Add closure bridge and replace test runner only; candidate source files unchanged; no asserted state reinjection after reload.'},indent=2))
 print(p.stdout+p.stderr);raise SystemExit(p.returncode)
finally:server.shutdown();server.server_close();thread.join(timeout=2)
