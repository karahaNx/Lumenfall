const {chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright');
const fs=require('fs'),assert=require('node:assert/strict');
const records=[];
const clone=x=>JSON.parse(JSON.stringify(x));
(async()=>{
 const browser=await chromium.launch({executablePath:process.env.CORE_BROWSER,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 const context=await browser.newContext({viewport:{width:390,height:844}});const page=await context.newPage();
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 const boot=async()=>{await page.waitForFunction(()=>window.__coreReady===true);await page.evaluate(()=>localStorage.setItem(window.__lumenfallQaContext.phaseKey,'1'));};
 const reload=async()=>{await page.reload();await boot();};
 const state=()=>page.evaluate(()=>window.__lumenfallQaBridge.getState());
 const disk=()=>page.evaluate(()=>({primary:JSON.parse(window.__lumenfallQaBridge.rawSave()),recovery:JSON.parse(window.__lumenfallQaBridge.rawRecovery())}));
 const set=async s=>page.evaluate(s=>{let b=window.__lumenfallQaBridge;b.setState(s);b.renderLayout();},s);
 const seed=async()=>page.evaluate(()=>{let b=window.__lumenfallQaBridge,s=b.freshStateSnapshot();s.depth=16;s.maxDepthEver=130;s.enemyDepth=16;s.enemyMaxHp=b.enemyHpFor(16);s.enemyHp=s.enemyMaxHp;s.lumen=1000000;s.shards=1000000;s.motes=1000000;s.questDay=b.currentDay();s.loginStreak=1;Object.keys(s.empowerQueue).forEach(id=>s.empowerQueue[id]=false);b.forge.deeds().items.forEach(d=>s.achieved[d.id]=true);return s;});
 const save=()=>page.evaluate(()=>window.__coreReview.save());
 const snapshot=s=>({raw:s.longStudyLevels.measuredinquiry,queue:s.studyQueue.measuredinquiry,active:s.activeStudies,lumen:s.lumen,shards:s.shards,motes:s.motes,comets:s.comets});
 async function test(name,fn){try{const detail=await fn();records.push({name,status:'PASS',detail});console.log('PASS '+name);}catch(e){records.push({name,status:'FAIL',error:e.stack});console.log('FAIL '+name+' '+e.message);}}
 await page.goto(process.env.CORE_URL);await boot();
 await test('defaults-current-v0-and-missing-maps',async()=>{
  const values=await page.evaluate(()=>{let b=window.__lumenfallQaBridge,c=window.__coreReview,f=b.freshStateSnapshot(),v=JSON.parse(JSON.stringify(f));delete v.schemaVersion;delete v.studyQueue;delete v.longStudyLevels;v.owned.autostudy=true;let current=JSON.parse(JSON.stringify(f));delete current.studyQueue;delete current.longStudyLevels;return {fresh:f,current:c.parse(current),v0:c.parse(v)};});
  for(const v of Object.values(values)){assert.equal(v.schemaVersion,1);assert.equal(v.longStudyLevels.measuredinquiry,0);assert.equal(v.studyQueue.measuredinquiry,false);assert.equal(Object.keys(v.longStudyLevels).length,9);assert.equal(Object.keys(v.studyQueue).length,9);}
  assert.equal(Object.entries(values.v0.studyQueue).filter(x=>x[1]).length,8);return {freshRaw:0,freshQueue:false,currentRaw:0,currentQueue:false,v0Raw:0,v0Queue:false,v0On:8,mapEntries:9};
 });
 await test('queue-toggle-real-save-and-two-reloads',async()=>{
  let s=await seed();s.longStudyLevels.measuredinquiry=13;s.studyQueue.measuredinquiry=true;s.activeStudies=[{id:'measuredinquiry',remainingSec:531,totalDurationSec:600,speedMult:8},{id:'guardmastery',remainingSec:77,totalDurationSec:120,speedMult:2}];await set(s);assert.equal(await save(),true);
  const before=await state();await page.evaluate(()=>window.__coreReview.queue('measuredinquiry'));let expected=await state();assert.equal(expected.studyQueue.measuredinquiry,false);assert.deepEqual(expected.activeStudies,before.activeStudies);
  let d=await disk();assert.deepEqual(snapshot(d.primary),snapshot(expected));assert.deepEqual(snapshot(d.recovery),snapshot(expected));
  await reload();assert.deepEqual(snapshot(await state()),snapshot(expected));await reload();assert.deepEqual(snapshot(await state()),snapshot(expected));
  return {before:snapshot(before),after:snapshot(expected),reloads:2,noReinjection:true};
 });
 await test('completion-render-save-reload-keeps-existing-work',async()=>{
  let s=await seed();s.longStudyLevels.measuredinquiry=4;s.activeStudies=[{id:'measuredinquiry',remainingSec:0,totalDurationSec:3932,speedMult:1},{id:'guardmastery',remainingSec:77,totalDurationSec:120,speedMult:2}];await set(s);let before=await state();
  await page.evaluate(()=>window.__lumenfallQaBridge.renderLayout());assert.deepEqual(await state(),before);
  const due=await page.evaluate(()=>window.__coreReview.due());assert.equal(due.handled,1);let completed=await state();assert.equal(completed.longStudyLevels.measuredinquiry,5);assert.deepEqual(completed.activeStudies,[s.activeStudies[1]]);assert.equal(await save(),true);
  await reload();assert.deepEqual(snapshot(await state()),snapshot(completed));return {levelBefore:4,levelAfter:5,remainingStudy:(await state()).activeStudies[0],summary:due.summary};
 });
 await test('actual-ascension-save-and-reload',async()=>{
  let s=await seed();s.longStudyLevels.measuredinquiry=13;s.studyQueue.measuredinquiry=true;s.activeStudies=[{id:'measuredinquiry',remainingSec:531,totalDurationSec:600,speedMult:8},{id:'guardmastery',remainingSec:77,totalDurationSec:120,speedMult:2}];await set(s);assert.equal(await save(),true);await page.evaluate(()=>window.__coreReview.ascend());let a=await state();
  assert.equal(a.ascendCount,1);assert.equal(a.lumen,0);assert.equal(a.shards,s.shards);assert.deepEqual(a.activeStudies,s.activeStudies);assert.equal(a.longStudyLevels.measuredinquiry,13);assert.equal(a.studyQueue.measuredinquiry,true);
  let d=await disk();assert.equal(d.primary.ascendCount,1);assert.deepEqual(snapshot(d.primary),snapshot(a));assert.deepEqual(snapshot(d.recovery),snapshot(a));await reload();assert.deepEqual(snapshot(await state()),snapshot(a));return {ascendCount:1,snapshot:snapshot(a),actualSave:true,reloaded:true};
 });
 await test('cap9-complete-save-two-reloads-no-double-reward',async()=>{
  let s=await seed();s.longStudyLevels.measuredinquiry=9;s.studyQueue.measuredinquiry=true;s.activeStudies=[{id:'measuredinquiry',remainingSec:1,totalDurationSec:41232,speedMult:1}];await set(s);let report=await page.evaluate(()=>window.__coreReview.tail(1));let a=await state();assert.equal(a.longStudyLevels.measuredinquiry,10);assert.equal(a.activeStudies.length,0);assert.equal(a.lumen,s.lumen);assert.equal(a.shards,s.shards);assert.deepEqual(report.completedStudies,['Measured Inquiry']);assert.equal(report.studiesStarted,0);assert.equal(await save(),true);
  for(let i=0;i<2;i++){await reload();assert.deepEqual(snapshot(await state()),snapshot(a));let again=await page.evaluate(()=>window.__coreReview.tail(100));assert.deepEqual(again.completedStudies,[]);assert.deepEqual(again.closedStudies,[]);}
  return {raw:10,queue:true,active:[],earned:report.completedStudies,reloads:2,currency:[a.lumen,a.shards]};
 });
 await test('overcap-before-due-save-reload-and-neutral-close',async()=>{
  let s=await seed();s.longStudyLevels.measuredinquiry=13;s.studyQueue.measuredinquiry=true;s.activeStudies=[{id:'measuredinquiry',remainingSec:1,totalDurationSec:600,speedMult:8}];s.achieved.study1=false;s.achieved.study25=false;s.achieved.allstudies=false;await set(s);assert.equal(await save(),true);let paid=await state();await reload();assert.deepEqual(snapshot(await state()),snapshot(paid));
  let report=await page.evaluate(()=>window.__coreReview.tail(.125));let a=await state();assert.equal(a.longStudyLevels.measuredinquiry,13);assert.equal(a.activeStudies.length,0);assert.equal(a.lumen,s.lumen);assert.equal(a.shards,s.shards);assert.equal(a.comets,s.comets);assert.deepEqual(report.completedStudies,[]);assert.deepEqual(report.closedStudies,['Measured Inquiry']);for(const id of ['study1','study25','allstudies'])assert.notEqual(a.achieved[id],true);
  assert.equal(await save(),true);await reload();assert.deepEqual(snapshot(await state()),snapshot(a));return {preservedBeforeDue:paid.activeStudies,raw:13,earned:[],closed:report.closedStudies,comets:a.comets,studyDeeds:false};
 });
 await test('all-start-callers-reject-overflow-without-state-or-boundary-change',async()=>{
  let s=await seed();s.longStudyLevels.guardmastery=2000;s.studyQueue.guardmastery=true;await set(s);let before=await state();const result=await page.evaluate(()=>{const b=window.__lumenfallQaBridge,c=window.__coreReview;return {reason:c.plan('guardmastery').reason,before:b.inquiry.boundary(),manual:b.inquiry.start('guardmastery'),auto:b.inquiry.autoFill(),simulation:b.inquiry.queued(),after:b.inquiry.boundary()};});
  assert.equal(result.reason,'unavailable');assert.equal(result.manual,false);assert.equal(result.auto,false);assert.equal(result.simulation.studiesStarted,0);assert.equal(result.before,Infinity);assert.equal(result.after,Infinity);assert.deepEqual(await state(),before);assert.equal((await state()).longStudyLevels.guardmastery,2000);return {...result,before:'Infinity',after:'Infinity',raw:2000,unchanged:true};
 });
 await test('restore-primary-write-failure-rolls-back-recovery',async()=>{
  let s=await seed();s.longStudyLevels.measuredinquiry=13;s.activeStudies=[{id:'measuredinquiry',remainingSec:531,totalDurationSec:600,speedMult:8}];await set(s);assert.equal(await save(),true);const before=await disk();const observed=await page.evaluate(()=>{const b=window.__lumenfallQaBridge,target=b.freshStateSnapshot(),old=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(k==='lumenfall_save_v2')throw new Error('Core test primary write blocked');return old.call(this,k,v);};try{b.restoreBackup('LUMENFALL1:'+encodeURIComponent(JSON.stringify(target)));}finally{Storage.prototype.setItem=old;}return {primary:JSON.parse(b.rawSave()),recovery:JSON.parse(b.rawRecovery()),state:b.getState(),flags:b.getFlags()};});
  assert.deepEqual(observed.primary,before.primary);assert.deepEqual(observed.recovery,before.recovery);assert.equal(observed.flags.reloadInProgress,false);assert.equal(observed.state.longStudyLevels.measuredinquiry,13);assert.deepEqual(observed.state.activeStudies,s.activeStudies);await page.evaluate(()=>window.__lumenfallQaBridge.freeze());return {primaryUnchanged:true,recoveryRolledBack:true,raw:13,active:observed.state.activeStudies,reloadBlocked:false};
 });
 await test('blocked-start-caller-matrix',async()=>{
  const cases=[['locked',s=>s.maxDepthEver=59],['maxed',s=>s.longStudyLevels.measuredinquiry=10],['missing-lumen',s=>s.lumen=29999],['missing-shards',s=>s.shards=1199],['duplicate',s=>s.activeStudies=[{id:'measuredinquiry',remainingSec:10,totalDurationSec:600,speedMult:1}]],['full-slots',s=>s.activeStudies=['wispascend','guardmastery','riftattune','shardstudy','lumenstudy'].map(id=>({id,remainingSec:10,totalDurationSec:100,speedMult:1}))]];
  const details=[];
  for(const [name,change] of cases){let s=await seed();change(s);s.studyQueue.measuredinquiry=true;await set(s);const before=await state();const r=await page.evaluate(()=>{let b=window.__lumenfallQaBridge,c=window.__coreReview;let before=b.inquiry.boundary();return {reason:c.plan('measuredinquiry').reason,boundaryBefore:String(before),manual:b.inquiry.start('measuredinquiry'),auto:b.inquiry.autoFill(),simulationStarts:b.inquiry.queued().studiesStarted,boundaryAfter:String(b.inquiry.boundary())};});assert.equal(r.manual,false);assert.equal(r.auto,false);assert.equal(r.simulationStarts,0);assert.equal(r.boundaryAfter,r.boundaryBefore);assert.deepEqual(await state(),before);details.push({name,...r,unchanged:true});}
  return details;
 });
 await test('due-entry-completion-order-and-captured-timeline',async()=>{
  let s=await seed();s.longStudyLevels.measuredinquiry=4;s.activeStudies=[{id:'measuredinquiry',remainingSec:0,totalDurationSec:3932,speedMult:1},{id:'wispascend',remainingSec:50,totalDurationSec:180,speedMult:2}];s.studyQueue.guardmastery=true;await set(s);
  const tail=await page.evaluate(()=>window.__coreReview.tail(1)),tailState=await state();assert.equal(tailState.longStudyLevels.measuredinquiry,5);assert.deepEqual(tailState.activeStudies.find(x=>x.id==='guardmastery'),{id:'guardmastery',remainingSec:134,totalDurationSec:135,speedMult:1});assert.deepEqual(tailState.activeStudies.find(x=>x.id==='wispascend'),{id:'wispascend',remainingSec:48,totalDurationSec:180,speedMult:2});
  await set(s);const report=await page.evaluate(()=>window.__coreReview.authoritative(1,'offline'));const events=report.timeline.filter(x=>x.type==='studyComplete'||x.type==='studyStart');assert.deepEqual(events.map(x=>x.type),['studyComplete','studyStart']);assert.equal(events[0].elapsedSec,0);assert.equal(events[1].elapsedSec,0);assert.deepEqual((await state()).activeStudies,tailState.activeStudies);return {tail:tail,events,active:tailState.activeStudies};
 });
 await test('overcap-disposal-split-save-reload-tail-continues',async()=>{
  let s=await seed();s.longStudyLevels.measuredinquiry=13;s.activeStudies=[{id:'measuredinquiry',remainingSec:1,totalDurationSec:600,speedMult:1},{id:'guardmastery',remainingSec:7,totalDurationSec:150,speedMult:1}];await set(s);const first=await page.evaluate(()=>window.__coreReview.tail(1));assert.deepEqual(first.closedStudies,['Measured Inquiry']);assert.deepEqual(first.completedStudies,[]);assert.equal((await state()).activeStudies[0].remainingSec,6);assert.equal(await save(),true);await reload();const second=await page.evaluate(()=>window.__coreReview.tail(9));const split=await state();assert.deepEqual(second.completedStudies,["Guardian's Mastery"]);assert.equal(split.longStudyLevels.measuredinquiry,13);assert.equal(split.longStudyLevels.guardmastery,1);assert.equal(split.activeStudies.length,0);
  await set(s);const whole=await page.evaluate(()=>window.__coreReview.tail(10));const direct=await state();for(const k of ['longStudyLevels','activeStudies','lumen','shards','motes','comets'])assert.deepEqual(split[k],direct[k]);return {firstClosed:first.closedStudies,secondEarned:second.completedStudies,wholeEarned:whole.completedStudies,raw:13,legacyLevel:1,saveReloadParity:true};
 });
 await test('legacy-completion-helper-cap9-and-repeat',async()=>{
  let s=await seed();s.longStudyLevels.measuredinquiry=9;s.activeStudies=[{id:'measuredinquiry',remainingSec:1,totalDurationSec:41232,speedMult:1}];await set(s);let first=await page.evaluate(()=>window.__coreReview.liveComplete(1));assert.deepEqual(first,['Measured Inquiry']);assert.equal((await state()).longStudyLevels.measuredinquiry,10);let second=await page.evaluate(()=>window.__coreReview.liveComplete(1));assert.deepEqual(second,[]);return {raw:10,first,second};
 });
 await test('accepted-downgrade-loses-inquiry-on-real-old-load-save',async()=>{
  let s=await seed();s.longStudyLevels.measuredinquiry=13;s.studyQueue.measuredinquiry=true;s.activeStudies=[{id:'measuredinquiry',remainingSec:531,totalDurationSec:600,speedMult:8},{id:'guardmastery',remainingSec:77,totalDurationSec:120,speedMult:2}];await set(s);assert.equal(await save(),true);const before=await disk();await page.goto(process.env.CORE_URL.replace('/index.html?','/base.html?'));await boot();const oldState=await state();assert.equal(Object.hasOwn(oldState.longStudyLevels,'measuredinquiry'),false);assert.equal(Object.hasOwn(oldState.studyQueue,'measuredinquiry'),false);assert.deepEqual(oldState.activeStudies,[s.activeStudies[1]]);assert.equal(await save(),true);const oldDisk=await disk();assert.equal(Object.hasOwn(oldDisk.primary.longStudyLevels,'measuredinquiry'),false);
  await page.goto(process.env.CORE_URL);await boot();const back=await state();assert.equal(back.longStudyLevels.measuredinquiry,0);assert.equal(back.studyQueue.measuredinquiry,false);assert.deepEqual(back.activeStudies,[s.activeStudies[1]]);return {beforeRaw:before.primary.longStudyLevels.measuredinquiry,oldMapEntries:Object.keys(oldState.longStudyLevels).length,oldInquiryRecord:false,returnRaw:0,returnQueue:false,retainedLegacy:back.activeStudies,acceptedLimitation:true};
 });
 assert.deepEqual(errors,[]);await browser.close();
 const result={candidate:'10f2ff5facef78a7c1d8293b6a8d07be888f7350',browser:'Chromium 141.0.7390.37',runtime:process.version,pageErrors:errors,records,passed:records.filter(r=>r.status==='PASS').length,total:records.length};fs.writeFileSync(process.env.CORE_OUT,JSON.stringify(result,null,2));console.log(JSON.stringify({passed:result.passed,total:result.total}));process.exitCode=result.passed===result.total?0:1;
})().catch(e=>{console.error(e);fs.writeFileSync(process.env.CORE_OUT,JSON.stringify({fatal:e.stack,records},null,2));process.exitCode=1;});
