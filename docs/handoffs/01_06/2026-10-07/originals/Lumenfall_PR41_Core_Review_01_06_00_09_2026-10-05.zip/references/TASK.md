# 01_06 — Core-review af Measured Inquiry / PR41

Fra 00_09 — Lead / Architecture · 2026-10-05
Model: GPT-6.1 Sol · Effort: High
Mandat: read-only Core/persistence-review; ingen Android-/APK-build.
Kandidat: 10f2ff5facef78a7c1d8293b6a8d07be888f7350 · tree d1910132973d117c75c3d4ace4867e86f372110e
Base: df78d51181a59d247bf4fc9abf1c7e05237e9c2b · tree d1d128a82f6bc204655dc662a5239f98dca51059

Formålet er at kontrollere save/load og aktive betalte studies på den præcise
publicerede kandidat, selv om 02_07's chat ikke kan levere sin sluthandoff.
Dette er en afgrænset reviewopgave, ikke en ny bred audit af tidligere PR40.

Læs derefter requirements/ORIGINAL_02_07_MANDATE.txt i sin helhed. Det er
originalkravet, ikke en ny writer-tilladelse. Læs PR41_exact.patch, med særlig
vægt på canonical maps/v0-seeding, start/completion, scheduler og persistence-
tests. Brug source/candidate og source/base til målrettede funktioner/callers;
testharness og produktionskode skal vurderes sammen. Originale krav og konkrete
runtimeobservations har forrang for kandidatens egen docs/MEASURED_INQUIRY.md.

KONTROLLÉR DISSE CORE-KONTRAKTER
1. Schema1, primary/recovery keys, backup-prefix, canonical transaction/
   restore/resetguards og malformed/future-save rejection er bevaret. Fresh,
   current og v0 saves får Inquiry raw0/queueOFF; gammel autostudy migrerer kun
   de originale8 queueflags ON. Alle øvrige stateforventninger består.
2. Raw ejerskab er bevaret, inklusive13; effektiv effekt højst10. Ingen
   load-clamp, refund, ændret legacy-cap eller gratis Inquiry-start. Kravene
   gælder canonical save, faktisk reload, backup/restore og recovery.
3. Aktive betalte remainingSec/totalDurationSec/speedMult bevares ved bonus,
   queue-toggle, render, save/reload, restore/recovery og Ascension. Test
   faktiske paths, så fixture-reinjektion ikke skjuler tab ved reel persistence.
4. Raw9 completion giver10 én gang. Raw>=10 plus allerede betalt aktiv record
   bevares indtil due og lukkes neutralt uden grant, valuta/refund, Deed-credit
   eller falsk earned summary. Både legacy live-completion og simulation skal
   følge kontrakten; gentaget reload/tidsopdeling må ikke give dobbelt reward.
5. Overcap-disposal tæller som schedulerfremskridt selv med earned0, så et
   andet legacy-study senere i SAMME study-only-tail stadig fuldføres. Due
   Inquiry ved remaining0 behandles før queued start ved tail-entry; nye
   legacy starts bruger faktisk completed bonus, allerede aktive work bevares.
6. Kun nye betalte legacy8-starts får præcis dobbelt-rounding-discount; Inquiry
   forkorter aldrig sig selv. Shared startplan og alle callers skal afvise
   ukendt/locked/capped/duplicate/fulde slots/ufinansieret/nonfinite start uden
   currency-, level-, active-record- eller tidsgrænsemutation. Legacy raw levels
   må ikke clamps for at løse overflow. Tilføj relevante negative observationer.
7. Mote-priser/8x473 og næste start1x bevares; Full Reset/Ascension har tidligere
   scope. Original8 for slots/Deeds/v0 må ikke gøre andre canonical maps ufulde.
8. Dokumenteret schema1-downgrade er ikke sikkert: gammel app kan strippe nye
   IDs/active records. Dette er en accepteret begrænsning, ikke et løfte om
   sikker roundtrip og ikke mandat til ny schema-/versionsstrategi.

UAFHÆNGIG VERIFIKATION
Kontrollér først live main/PR-head. Reviewresultatet gælder kun exact SHA/tree
ovenfor. Ved drift rapporteres før/efter; review gerne immutable snapshot, men
accepter ikke den nye PR-head automatisk. Checkpointet er ikke et resetmål.
Rekonstruér et komplet runnable checkout/harness fra exact kandidat i egen
lokal mappe, eller hent de nødvendige uændrede filer på samme immutable ref.
Denne ZIP indeholder kun de seks ændrede filer og fire relevante basefiler,
ikke et komplet repo. SOURCE_INDEX.tsv og rå tree-receipts hjælper målrettet
opslag. Kør ikke en delvis pakke og kald det en fuld regression.

Kør kandidatens inquiry-save-reload, inquiry-backup-restore, inquiry-recovery,
inquiry-reset og relevante cap/chronology-cases. Kør relevante eksisterende
persistence/restore/recovery/transaction/future/malformed-guards på exact
kandidat. Vælg scenarios fra den faktiske harnessliste; opfind ikke navne.
Supplér med isolerede lokale checks, hvor oraklerne ikke dækker kravene. Notér
kommando, runtime, exitcode og konkrete stateværdier. CI-grøn er sekundær
evidens. Hvis browsermiljø blokerer, dokumentér den konkrete fejl og udestående
checks; løs ikke miljøet ved at svække asserts eller ændre remote/workflows.
QA ejer den samlede suite og UI; brug dens mandat til at undgå unødvendig
gentagelse, men behold din selvstændige Core-verifikation.

AFLEVERING
Aflever standalone TXT og kompakt ZIP med START_HER, review, fund/reproduktion,
kommandoer/resultater, udvalgte rå logs og SHA256-manifest med fuld payload-
dækning. Rapportér candidate/base/tree/indexSHA og frisk live receipt. Klassificér
hver kontrakt som egen PASS, FAIL eller IKKE VERIFICERET. Konklusion: scoped
ACCEPT / BLOCK / UFULDSTÆNDIG med konkrete blockers og begrænsninger; undgå
generelt 'alt er sikkert'. Ingen remedieringscommit, remote write eller build.
Stop efter aflevering; 00_09 disponerer eventuelle rettelser/integration.
