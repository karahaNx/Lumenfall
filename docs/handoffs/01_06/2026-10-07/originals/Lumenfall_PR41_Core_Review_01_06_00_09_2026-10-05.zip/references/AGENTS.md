# Lumenfall — regler for denne reviewpakke

Mandat: uafhængigt read-only review af PR41 på den præcise kandidat i TASK.md.
Læs først START_HER.txt, denne fil, PROJECT_STATE.md og TASK.md. Derefter læses
originalkrav, relevant diff og nødvendige kildefunktioner som anvist i opgaven.
ZIP'en er et arkiv til målrettet opslag; læs ikke alle filer ved opstart.

01_06 og 04_05 kan arbejde samtidig i hver sin lokale arbejdsmappe. Lokal
testinstrumentering, isoleret checkout og rapportfiler er tilladt. Ingen remote
write, commit/push/PR, repo-/branchcleanup, merge, workflow-dispatch/rerun,
Android-/APK-build, release eller signing-handling. Ingen subagenter eller
beskedværktøjer. Aflever til brugeren; brugeren overfører resultatet til 00_09.

Det arkiverede implementeringsmandat til 02_07 er original produktkontrakt.
Dets writer-tilladelse gælder ikke dig; TASK.md er dit aktuelle mandat.
Workerens tekniske stop/freeze er uafklaret. Et review af en immutable commit
frigiver ingen writerlease. Ved drift rapporteres de konkrete SHA'er til Lead;
ændr ikke scope, baseline eller kandidat og forsøg ikke at stoppe den anden chat.

Brug præcise kildehenvisninger og reproduktion. Skeln egne checks, observeret CI,
worker-udsagn og ukendte forhold. Claims uden reproduktion mærkes tydeligt.
Læs kode i relevante bidder; dump ikke hele index.html eller rå API-JSON i chatten.
