from pathlib import Path
import importlib.util,json,shutil,threading,subprocess,os,datetime,hashlib
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from functools import partial
w=Path(__file__).resolve().parent;root=w/'candidate';out=w/'evidence'
spec=importlib.util.spec_from_file_location('candidate_harness',root/'tests/behavioral/run.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
stage=w/'independent_stage';stage.mkdir(exist_ok=True)
for name in ('fonts','branding'):shutil.copytree(root/name,stage/name,dirs_exist_ok=True)
source=(root/'index.html').read_text();marker='\n})();\n</script>\n<script>\nif(window.Capacitor'
core='''
window.__navCore={
 withWrites:function(fn){var old=reloadInProgress;reloadInProgress=false;try{return fn();}finally{reloadInProgress=old;}},
 save:function(){return this.withWrites(function(){return saveState();});},
 go:function(name){return this.withWrites(function(){activateTab(name);});},
 click:function(selector){return this.withWrites(function(){document.querySelector(selector).click();});},
 choose:function(name){return this.withWrites(function(){var el=document.getElementById('rift-objective');var old=el.getAttribute('data-target-tab');el.setAttribute('data-target-tab',name);el.click();if(old===null)el.removeAttribute('data-target-tab');else el.setAttribute('data-target-tab',old);});},
 plan:function(id){return getStudyStartPlan(LONG_STUDIES.find(function(n){return n.id===id;}));},
 price:function(id){var p=this.plan(id);return {lumen:formatNum(p.cost.lumen),shards:formatNum(p.cost.shard),cost:p.cost,duration:p.duration,reason:p.reason};},
 render:function(){renderAll();updateBattleFast();},
 badge:function(){renderLabCapacityBadge();},
 speedCost:function(n){return speedTierCost(n);}
};
'''
assert source.count(marker)==1;source=source.replace(marker,'\n'+core+marker)
h.build_runner=lambda:'''<script>document.addEventListener('DOMContentLoaded',function(){window.__lumenfallQaBridge.freeze();window.__lumenfallQaBridge.resetFeedback();window.__navReady=true;});</script>'''
data=h.instrument_html(source,h.load_fixtures());(stage/'index.html').write_text(data)
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(stage)));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
env=os.environ.copy();env['NAV_BROWSER']=str(w/'bin/chromium');env['NAV_URL']=f'http://127.0.0.1:{server.server_address[1]}/index.html?qaScenario=nav-core-independent&qaFixture=fresh';env['NAV_OUT']=str(out/'independent.json')
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
try:
 p=subprocess.run(['node',str(w/'independent.cjs')],env=env,capture_output=True,text=True,timeout=120)
 (out/'independent.log').write_text(p.stdout+p.stderr)
 (out/'independent_command.json').write_text(json.dumps({'command':['python',str(Path(__file__).resolve())],'started_at':started,'exitcode':p.returncode,'source_sha256':hashlib.sha256((root/'index.html').read_bytes()).hexdigest(),'instrumented_sha256':hashlib.sha256(data.encode()).hexdigest(),'instrumentation':'Original prelude/bridge; replace test runner and add closure access only. Writes permitted during tested synchronous navigation/purchase actions. No expected-state reinjection after reload.'},indent=2))
 print(p.stdout+p.stderr);raise SystemExit(p.returncode)
finally:server.shutdown();server.server_close();thread.join(timeout=2)
