const {chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright');
const fs=require('fs'),assert=require('node:assert/strict');const records=[];let checks=0;
const eq=(a,b,m)=>{checks++;assert.deepEqual(a,b,m);};
const ok=(v,m)=>{checks++;assert.ok(v,m);};
(async()=>{
 const browser=await chromium.launch({executablePath:process.env.NAV_BROWSER,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 const context=await browser.newContext({viewport:{width:390,height:844}}),page=await context.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));
 const boot=async()=>{await page.waitForFunction(()=>window.__navReady===true);await page.evaluate(()=>localStorage.setItem(window.__lumenfallQaContext.phaseKey,'1'));};
 const state=()=>page.evaluate(()=>window.__lumenfallQaBridge.getState());
 const snap=()=>page.evaluate(()=>{let b=window.__lumenfallQaBridge;return {state:b.getState(),primary:b.rawSave(),recovery:b.rawRecovery(),events:b.lifecycleTrace(),keys:Object.keys(localStorage).sort()};});
 const seed=()=>page.evaluate(()=>{let b=window.__lumenfallQaBridge,s=b.freshStateSnapshot();s.depth=16;s.maxDepthEver=101;s.enemyDepth=16;s.enemyMaxHp=b.enemyHpFor(16);s.enemyHp=s.enemyMaxHp;s.lumen=1e6;s.shards=1e6;s.motes=1e6;s.questDay=b.currentDay();s.loginStreak=1;Object.keys(s.empowerQueue).forEach(id=>s.empowerQueue[id]=false);b.forge.deeds().items.forEach(d=>s.achieved[d.id]=true);return s;});
 const set=s=>page.evaluate(s=>{let b=window.__lumenfallQaBridge;b.setState(s);b.renderLayout();},s);
 const go=name=>page.evaluate(name=>window.__navCore.go(name),name);
 const click=selector=>page.evaluate(s=>window.__navCore.click(s),selector);
 const save=()=>page.evaluate(()=>window.__navCore.save());
 const chosen=()=>page.evaluate(()=>({panel:document.querySelector('.tab-panel.active').id,main:document.querySelector('nav.tabbar .active').dataset.tab,sub:[...document.querySelectorAll('.workshop-btn')].filter(x=>x.getAttribute('aria-selected')==='true').map(x=>x.dataset.tab)}));
 const ax=async selector=>{const session=await context.newCDPSession(page);const {root}=await session.send('DOM.getDocument');const {nodeId}=await session.send('DOM.querySelector',{nodeId:root.nodeId,selector});const {nodes}=await session.send('Accessibility.getPartialAXTree',{nodeId,fetchRelatives:false});await session.detach();return nodes[0];};
 async function test(name,fn){let begin=checks;try{const detail=await fn();records.push({name,status:'PASS',checks:checks-begin,detail});console.log('PASS '+name+' '+(checks-begin));}catch(e){records.push({name,status:'FAIL',checks:checks-begin,error:e.stack});console.log('FAIL '+name+' '+e.message);}}
 await page.goto(process.env.NAV_URL);await boot();
 await test('navigation-whole-state-saves-events-with-writeguard-open',async()=>{
  let s=await seed();s.longStudyLevels.measuredinquiry=13;s.studyQueue.measuredinquiry=true;s.researchQueue.focus=true;s.activeStudies=[{id:'measuredinquiry',remainingSec:531,totalDurationSec:600,speedMult:8},{id:'guardmastery',remainingSec:77,totalDurationSec:120,speedMult:2}];await set(s);eq(await save(),true);const before=await snap();
  const routes=['workshop','research','battle','workshop','forge','research','spirits','ascend','deeds','battle','not-a-tab'];
  for(const name of routes){await go(name);eq(await snap(),before,'pure navigation '+name);}
  await page.locator('#nav-workshop').click();eq((await chosen()).panel,'tab-research');eq(await snap(),before);
  await page.locator('#nav-research').focus();await page.keyboard.press('ArrowRight');eq((await chosen()).panel,'tab-forge');await page.keyboard.press('ArrowLeft');eq((await chosen()).panel,'tab-research');eq(await snap(),before);
  const payload={routes,raw:13,active:(await state()).activeStudies,primarySha256:require('crypto').createHash('sha256').update(before.primary).digest('hex'),stateAndBothSavesAndEventsUnchanged:true};return payload;
 });
 await test('session-memory-explicit-shortcuts-and-real-reload',async()=>{
  await go('research');await go('battle');await go('workshop');eq((await chosen()).panel,'tab-research');
  await page.evaluate(()=>window.__navCore.choose('forge'));eq((await chosen()).panel,'tab-forge');eq((await chosen()).main,'workshop');
  await page.evaluate(()=>window.__navCore.choose('research'));eq((await chosen()).panel,'tab-research');eq((await chosen()).main,'workshop');
  let before=await state();eq(await save(),true);await page.reload();await boot();eq(await state(),before,'canonical reload retains entire state');await go('workshop');eq((await chosen()).panel,'tab-forge','reload defaults Forge');
  const keys=await page.evaluate(()=>Object.keys(JSON.parse(window.__lumenfallQaBridge.rawSave())).sort());ok(!keys.some(x=>/workshop|selectedTab|navigation/i.test(x)));return {defaultAfterReload:'forge',directForge:true,directLab:true,raw:before.longStudyLevels.measuredinquiry,active:before.activeStudies,noCanonicalNavField:true};
 });
 await test('hidden-main-labels-retain-real-ax-names',async()=>{
  const names={spirits:'Wisps',workshop:'Workshop',battle:'Rift',ascend:'Ascend',deeds:'Deeds'},values=[];
  for(const [name,label] of Object.entries(names)){await go(name);const observed=await ax('#nav-'+name);ok(!observed.ignored);ok(observed.name.value.includes(label));const visibility=await page.locator('#nav-'+name+' .lb').evaluate(el=>getComputedStyle(el).visibility);eq(visibility,'hidden');values.push({destination:name,axRole:observed.role.value,axName:observed.name.value,visualLabel:visibility});}
  return values;
 });
 await test('zero-and-free-capacity-badges-do-not-mutate-or-steal-focus',async()=>{
  const ids=['wispascend','guardmastery','riftattune','shardstudy','lumenstudy'],values=[];
  for(const n of [0,1,5]){let s=await seed();s.activeStudies=ids.slice(0,n).map(id=>({id,remainingSec:90,totalDurationSec:180,speedMult:2}));await set(s);await go('research');await page.locator('#nav-research').focus();const before=await snap();await page.evaluate(()=>window.__navCore.badge());eq(await snap(),before);const observed=await page.evaluate(()=>({mainText:document.querySelector('#lab-capacity-badge').textContent,mainHidden:document.querySelector('#lab-capacity-badge').hidden,subText:document.querySelector('#workshop-lab-badge').textContent,subHidden:document.querySelector('#workshop-lab-badge').hidden,name:document.querySelector('#nav-workshop').getAttribute('aria-label'),focus:document.activeElement.id}));eq(observed.mainText,String(5-n));eq(observed.subText,String(5-n));eq(observed.mainHidden,n===5);eq(observed.subHidden,n===5);eq(observed.focus,'nav-research');ok(observed.name.includes('Lab — '+(5-n)+' Study slot'));values.push(observed);}
  return values;
 });
 await test('lab-disabled-start-prices-real-accessibility-tree',async()=>{
  let s=await seed();s.lumen=0;s.shards=0;s.motes=0;await set(s);await go('research');const ids=await page.locator('[data-study]').evaluateAll(a=>a.map(x=>x.dataset.study));const values=[];
  for(const id of ids){const selector='[data-study="'+id+'"]',plan=await page.evaluate(id=>window.__navCore.price(id),id),before=await snap();const observed=await ax(selector);ok(!observed.ignored);ok(observed.name.value.includes('Begin Study'));ok(observed.description&&observed.description.value.includes('Lumen'));ok(observed.description.value.includes('Shards'));ok(observed.description.value.includes(plan.lumen));ok(observed.description.value.includes(plan.shards));ok(observed.properties.some(x=>x.name==='disabled'&&x.value.value===true));ok(!/Need|Cannot afford|Insufficient resources/i.test(observed.name.value+' '+observed.description.value));await click(selector);eq(await snap(),before);values.push({id,rawCost:plan.cost,displayPrice:[plan.lumen,plan.shards],axName:observed.name.value,axDescription:observed.description.value,nativeDisabled:true});}
  eq(ids.length,9);return values;
 });
 await test('lab-price-updates-affordability-and-both-debits',async()=>{
  let s=await seed();s.longStudyLevels.measuredinquiry=5;s.lumen=600;s.shards=39;await set(s);await go('research');let before=await snap();let button=await ax('[data-study="guardmastery"]');ok(button.properties.some(x=>x.name==='disabled'&&x.value.value===true));await click('[data-study="guardmastery"]');eq(await snap(),before);
  s.shards=40;await set(s);await go('research');let prior=await state();await click('[data-study="guardmastery"]');let a=await state();eq(a.lumen,prior.lumen-600);eq(a.shards,prior.shards-40);eq(a.activeStudies,[{id:'guardmastery',remainingSec:135,totalDurationSec:135,speedMult:1}]);return {blockedAt:{lumen:600,shards:39},paid:{lumen:600,shards:40},active:a.activeStudies[0],actualDisk:JSON.parse((await snap()).primary).activeStudies};
 });
 await test('mote-speed-aria-price-disabled-gate-and-473-debit',async()=>{
  let s=await seed();s.motes=0;s.activeStudies=[{id:'guardmastery',remainingSec:120,totalDurationSec:120,speedMult:1}];await set(s);await go('research');await page.locator('[data-study-details="guardmastery"]').click();let before=await snap();const selector='[data-speed-study="guardmastery"][data-speed="8"]',poor=await ax(selector);ok(poor.name.value.includes('Motes'));ok(poor.name.value.includes('473'));ok(!/Need/.test(poor.name.value));ok(poor.properties.some(x=>x.name==='disabled'&&x.value.value===true));await click(selector);eq(await snap(),before);
  s.motes=473;await set(s);await go('research');await click(selector);let a=await state();eq(a.motes,0);eq(a.activeStudies,[{id:'guardmastery',remainingSec:120,totalDurationSec:120,speedMult:8}]);return {poorAX:poor.name.value,cost:473,after:a.activeStudies[0],motes:0};
 });
 await test('maxed-and-full-slot-reasons-survive',async()=>{
  let s=await seed();s.longStudyLevels.measuredinquiry=13;await set(s);await go('research');let capped=await ax('[data-study="measuredinquiry"]');ok(capped.name.value.includes('Maxed'));ok(!/Need|level 14/.test(capped.name.value));eq(await page.locator('[data-study="measuredinquiry"]').getAttribute('aria-describedby'),null);
  s.activeStudies=['wispascend','guardmastery','riftattune','shardstudy','lumenstudy'].map(id=>({id,remainingSec:90,totalDurationSec:180,speedMult:1}));await set(s);await go('research');let full=await ax('[data-study="motestudy"]');ok(full.name.value.includes('No open slots'));ok(full.description.value.includes('Lumen'));return {overcapRaw:13,cappedName:capped.name.value,cappedPriceRemoved:true,slotsName:full.name.value,slotsPrice:full.description.value};
 });
 eq(errors,[]);await browser.close();const result={candidate:'5be2c0319b9ce11fd8a29f0bb795d7de606858ae',runtime:process.version,browser:'Chromium141.0.7390.37',checks,records,pageErrors:errors,passed:records.filter(x=>x.status==='PASS').length,total:records.length};fs.writeFileSync(process.env.NAV_OUT,JSON.stringify(result,null,2));console.log(JSON.stringify({passed:result.passed,total:result.total,checks}));process.exitCode=result.passed===result.total?0:1;
})().catch(e=>{console.error(e);fs.writeFileSync(process.env.NAV_OUT,JSON.stringify({fatal:e.stack,records},null,2));process.exitCode=1;});
