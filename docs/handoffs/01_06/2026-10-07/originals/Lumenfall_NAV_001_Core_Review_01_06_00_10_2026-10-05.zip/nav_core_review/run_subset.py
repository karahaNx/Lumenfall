from pathlib import Path
import subprocess,os,json,datetime,time
w=Path(__file__).resolve().parent;root=w/'candidate';out=w/'evidence';out.mkdir(exist_ok=True)
env=os.environ.copy();env['PATH']=str(w/'bin')+os.pathsep+env['PATH']
scenarios=['nav-workshop-contract','r3-destinations','r3-save-reload','p1-05-accessibility-contract','p1-05-control-regressions','p1-05-reduced-motion','research-duration','research-duration-reduced-motion','inquiry-contracts','inquiry-chronology','inquiry-save-reload','inquiry-backup-restore','inquiry-recovery','inquiry-reset','inquiry-ui','fresh-load','legacy-load','active-studies-load','reset-roundtrip','restore-roundtrip','malformed-backup-rejection','recovery-from-corrupt-primary','unsupported-future-load','future-backup-rejection','recovery-offline-once','save-failure-warning','forge-contracts','forge-chronology','chronology-study-mid-window','chronology-simultaneous-order','lifecycle-long-study','lifecycle-lab-queue','lifecycle-background-resume','lifecycle-repeated-resume','lifecycle-cold-restart','p2-02a-core-qol']
receipts=[]
for name in scenarios:
 cmd=['python',str(root/'tests/behavioral/run.py'),'--web-root',str(root),'--scenario',name,'--raw-artifacts',str(w/'raw')]
 at=datetime.datetime.now(datetime.timezone.utc).isoformat();start=time.monotonic()
 p=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=100)
 (out/(name+'.log')).write_text(p.stdout+p.stderr)
 receipts.append({'scenario':name,'command':cmd,'started_at':at,'elapsed_seconds':round(time.monotonic()-start,3),'exitcode':p.returncode,'pass':p.returncode==0,'log':name+'.log'})
 (out/'scenario_receipts.json').write_text(json.dumps(receipts,indent=2))
 print(('PASS ' if p.returncode==0 else 'FAIL ')+name,flush=True)
 if p.returncode:print((p.stdout+p.stderr)[-2500:],flush=True)
print(json.dumps({'passed':sum(x['pass'] for x in receipts),'total':len(receipts)}),flush=True)
raise SystemExit(any(not x['pass'] for x in receipts))
